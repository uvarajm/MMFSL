import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { GET_TERM_AND_CONDITION } from "../../store/actions/actions";

const useFetchTermAndConditionContent = () => {
  const dispatch = useDispatch();
  const { termAndConditionPageContent, loading, error } = useSelector(
    (state) => state.termAndCondtionPageData,
  );

  useEffect(() => {
    if (termAndConditionPageContent.length === 0)
      dispatch({
        type: GET_TERM_AND_CONDITION,
        payload: termAndConditionPageContent,
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { termAndConditionPageContent, loading, error };
};

export default useFetchTermAndConditionContent;
