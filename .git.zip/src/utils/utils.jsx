import {
  DirectionsCarFilledOutlined,
  Person2Outlined,
} from "@mui/icons-material";

export const items = [
  {
    title: "Accordion Item 1",
    content: <p>This is the content of accordion item 1.</p>,
  },
  {
    title: "Accordion Item 2",
    content: <p>This is the content of accordion item 2.</p>,
  },
  {
    title: "Accordion Item 3",
    content: <p>This is the content of accordion item 3.</p>,
  },
];

export const headerClass = ``;
export const emi_details = {
  minLoanAmount: "1",
  maxLoanAmount: "25",
  minRateOfInterest: "6",
  maxRateOfInterest: "25",
  minTenure: "12",
  maxTenure: "60",
};

export const profileItems = [
  { item: "Change Your Password", itemLink: "/change-password" },
  { item: "Manage Your Devices", itemLink: "/manage-devices" },
];

export const ForeclosureCardData = [
  {
    id: 1,
    foreclosureProceedBtnActive: false,
    foreclosureCardDetail: true,
    Person2Outlined: Person2Outlined,
    loneType: "Persona Loan",
    loanFor: "Lorem Epsum sibil ko josdvbuasdn",
    middleLeftHeader: "Total Amount",
    middleLeftData: 10000,
    middleRightHeader: "Remaining Amount",
    middleRightData: 5000,
    errorDescription:
      "Foreclosure not allowed within freeze period. Please try after 5th of next month.",
    periodTime: "Locking period ends on - 00 Month 0000",
    buttonText: "Proceed",
  },
  {
    id: 2,
    foreclosureProceedBtnActive: false,
    foreclosureCardDetail: true,
    Person2Outlined: Person2Outlined,
    loanType: "Persona Loan",
    loanFor: "Lorem Epsum sibil ko josdvbuasdn",
    middleLeftHeader: "Total Amount",
    middleLeftData: 10000,
    middleRightHeader: "Remaining Amount",
    middleRightData: 5000,
    errorDescription:
      "Foreclosure not allowed within freeze period. Please try after 5th of next month.",
    periodTime: "Locking period ends on - 00 Month 0000",
    buttonText: "Proceed",
  },
  {
    id: 3,
    foreclosureProceedBtnActive: true,
    foreclosureCardDetail: false,
    Person2Outlined: DirectionsCarFilledOutlined,
    loanType: "Vehicle Loan",
    loanFor: "Mahindra XUV 800 ",
    middleLeftHeader: "Contract Number",
    middleLeftData: 1350050,
    middleRightHeader: "Instalment Amount",
    middleRightData: 15000,
    errorDescription:
      "Foreclosure not allowed within freeze period. Please try after 5th of next month.",
    periodTime: "Locking period ends on - 00 Month 0000",
    middleLeftHeaderMiddle: "Vehicle Registration Number",
    middleLeftDataMiddle: "VMH1378850",
    middleRightDateHeader: "Due Date",
    middleRightDateContent: "2-12-23",
    buttonText: "Proceed",
  },
  {
    id: 4,
    foreclosureProceedBtnActive: true,
    foreclosureCardDetail: true,
    Person2Outlined: Person2Outlined,
    loanType: "Persona Loan",
    loanFor: "Lorem Epsum sibil ko josdvbuasdn",
    middleLeftHeader: "Total Amount",
    middleLeftData: 10000,
    middleRightHeader: "Remaining Amount",
    middleRightData: 5000,
    errorDescription:
      "Foreclosure not allowed within freeze period. Please try after 5th of next month.",
    periodTime: "Locking period ends on - 00 Month 0000",
    buttonText: "Check the status",
  },
];

// call executive number formatter
export const formatNumber = (number) => {
  if (number) return number.replace(/(\d{4})(?=\d)/g, "$1 ");
};

export function capitalizeWords(str) {
  return str
    .toLowerCase()
    .split(" ")
    .map((word) => {
      return word.charAt(0).toUpperCase() + word.slice(1);
    })
    .join(" ");
}

// bookmarks
export const mergeBranchLists = (list1, list2) => {
  if (!list1 || !list2) return [];

  const codeSet = new Set(list2.map((branch) => branch.code));
  return list1.map((branch) => ({
    ...branch,
    saved: codeSet.has(branch.code),
  }));
};

// utils.js
const REGEX = {
  REGISTERPAGE: /^\/register(?:\/.*)?$/,
  PRODUCUCTSPAGE: /^\/product\/.*$/,
  PRODUCUCTFEATURESPAGE: /^\/product-feature\/.*$/,
  PRODUCUCTDETAILSPAGE: /^\/product-details\/.*$/,
  SERVICEDETAILSPAGE: /^\/services\/.*$/,
  APPFAQPAGE: /^\/faqs\/[^/]+$/,
  OFFERSPAGE: /^\/offer-details\/.*$/,
};

export const shouldShowSidebar = (pathname) => {
  return !(
    pathname.toLowerCase() === "/login" ||
    pathname.toLowerCase() === "/reset-password" ||
    pathname.toLowerCase() === "/change-password" ||
    pathname.toLowerCase() === "/products/home/leadgen" ||
    pathname.toLowerCase() === "/products/home/leadgen/success" ||
    pathname.toLowerCase() === "/locate-us" ||
    pathname.toLowerCase() === "/locate-us/" ||
    pathname.toLowerCase() === "/locate-us/details" ||
    REGEX.REGISTERPAGE.test(pathname.toLowerCase()) ||
    REGEX.PRODUCUCTSPAGE.test(pathname.toLowerCase()) ||
    REGEX.PRODUCUCTFEATURESPAGE.test(pathname.toLowerCase()) ||
    REGEX.PRODUCUCTDETAILSPAGE.test(pathname.toLowerCase()) ||
    REGEX.SERVICEDETAILSPAGE.test(pathname.toLowerCase()) ||
    REGEX.APPFAQPAGE.test(pathname.toLowerCase()) ||
    REGEX.OFFERSPAGE.test(pathname.toLowerCase())
  );
};

export const showSearchHandler = (pathname) => {
  return (
    pathname.toLowerCase() === "/product" ||
    pathname.toLowerCase() === "/faqs" ||
    pathname.toLowerCase() === "/offers" ||
    pathname.toLowerCase() === "/services" ||
    pathname.toLowerCase() === "/settings"
  );
};

export const convertToUnderscoreFormat = (inputString) => {
  return inputString.replace(/[-\s]/g, "_");
};

export const capitalizeTitle = (title) => {
  return title
    ?.split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

// Rupee formatting
export const formatRupee = (rupee, toFixed = true) => {
  let decimalPlaces = toFixed ? 2 : 0;

  let fixedRupee = parseFloat(rupee).toFixed(decimalPlaces);
  let [integerPart, decimalPart] = fixedRupee.split(".");

  let lastThreeDigits = integerPart.slice(-3);
  let otherDigits = integerPart.slice(0, -3);

  if (otherDigits !== "") {
    lastThreeDigits = "," + lastThreeDigits;
  }

  let formattedRupee =
    otherDigits.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThreeDigits;

  // Append the decimal part, if it exists
  if (decimalPart) {
    formattedRupee += "." + decimalPart;
  }

  return "₹" + formattedRupee;
};
