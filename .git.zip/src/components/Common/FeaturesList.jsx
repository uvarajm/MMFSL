import PropTypes from "prop-types";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "./SvgIcon";

const ProductFeature = ({
  icon = "",
  features,
  title = "",
  staticTitle = "",
}) => {
  const { FeaturesIcon } = iconConfig;
  const svgUrl = icon ? icon : FeaturesIcon;
  return (
    <div className="">
      <div className="lg:hidden subtitle mb-2">
        {title ? title : staticTitle}
      </div>
      <div className="space-y-2 text-wrap pb-4 border-b border-lilac-light lg:border-none mb-6 lg:mb-0">
        <div className=" flex flex-wrap gap-4 ">
          {features?.map((item, index) => (
            <div className="flex gap-1  w-full md:w-2/4 lg:w-1/4" key={index}>
              {item && (
                <>
                  <SvgIcon url={svgUrl} />
                  <p className="label label_md label_primary">{item}</p>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

ProductFeature.propTypes = {
  features: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  title: PropTypes.string,
  staticTitle: PropTypes.string,
  icon: PropTypes.string,
};

export default ProductFeature;
