import PropTypes from "prop-types";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { PickersDay } from "@mui/x-date-pickers/PickersDay";
import { createTheme, styled, ThemeProvider } from "@mui/material/styles";
import IconButton from "@mui/material/IconButton";

const customTheme = createTheme({
  palette: {
    primary: {
      main: "#2196f3",
    },
    secondary: {
      main: "#f50057",
    },
  },
});

const StyledButton = IconButton;
const StyledDay = styled(PickersDay)(({ theme }) => ({
  borderRadius: theme.shape.borderRadius,
  color:
    theme.palette.mode === "light"
      ? theme.palette.primary.dark
      : theme.palette.primary.light,
}));

const DatePickerTextBox = ({ title, icon, fontSize }) => {
  return (
    <ThemeProvider theme={customTheme}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DemoContainer components={["DatePicker"]}>
          <DatePicker
            label={title}
            slots={{
              openPickerIcon: () => <img src={icon} alt="Calendar" />,
              openPickerButton: StyledButton,
              day: StyledDay,
            }}
            slotProps={{
              openPickerIcon: { fontSize: fontSize },
              openPickerButton: { color: "secondary" },
              textField: {
                variant: "filled",
                focused: true,
                color: "secondary",
              },
            }}
          />
        </DemoContainer>
      </LocalizationProvider>
    </ThemeProvider>
  );
};

DatePickerTextBox.propTypes = {
  title: PropTypes.string,
  fontSize: PropTypes.string,
  icon: PropTypes.object,
};

export default DatePickerTextBox;
