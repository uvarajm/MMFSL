import AlertDialog from "./index";

export default {
  title: "Dialog",
  component: AlertDialog,
};

const Template = (args) => <AlertDialog {...args} />;

export const Default = Template.bind({});
Default.args = {
  header: "Terms And Conditions",
  content: "Hello",
  optionOne: "Cancel",
  optionTwo: "Accept",
  onChange: () => {},
};
