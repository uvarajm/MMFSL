import TableComp from "./index";

export default {
  title: "Table",
  component: TableComp,
};

const Template = (args) => <TableComp {...args} />;

export const Default = Template.bind({});
const handleRowClick = () => {};
Default.args = {
  data: [
    { id: 1, name: "John", age: 30, email: "john@example.com" },
    { id: 2, name: "Jane", age: 25, email: "jane@example.com" },
    // More data...
  ],
  columns: [
    { header: "Name", field: "name" },
    { header: "Age", field: "age" },
    { header: "Email", field: "email" },
  ],
  onRowClick: handleRowClick,
};
