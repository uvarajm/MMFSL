import { takeLatest, put, call } from "redux-saga/effects";
import { PAYMENT } from "../actions/actions";
import {
  fetchPaymentStatusData,
  fetchPaymentStatusDataSuccess,
  fetchPaymentStatusDataFailure,
} from "../slices/paymentSlice";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";
function* fetchPaymentData(action) {
  try {
    yield put(fetchPaymentStatusData());
    const response = yield call(
      makeApiRequest,
      endpoints.payment,
      BACKEND_TOKEN,
      "POST",
      {
        mobileNumber: action.payload,
      },
    );

    yield put(fetchPaymentStatusDataSuccess(response.linkToRedirect));
  } catch (error) {
    yield put(fetchPaymentStatusDataFailure(error.message));
  }
}

export function* watchfetchPaymentData() {
  yield takeLatest(PAYMENT, fetchPaymentData);
}
