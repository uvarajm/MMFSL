import PropTypes from "prop-types";
import ProductItems from "../../components/ProductFeatures/ProductItems";
const ServiceLists = ({ serviceListData, listType = "" }) => {
  return (
    <div>
      {serviceListData &&
        Object.entries(serviceListData).map(([productsName, subProducts]) => {
          return (
            <ProductItems
              key={productsName}
              product_title={productsName}
              types={subProducts}
              imageType="icons"
              listType={listType}
            />
          );
        })}
    </div>
  );
};

export default ServiceLists;

ServiceLists.propTypes = {
  serviceListData: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  listType: PropTypes.string,
};
