import { Autoplay, Pagination, Navigation } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import PreApprovedOffer from "../Common/PreApprovedOffer";

const Carousel = () => {
  return (
    <div className="relative">
      <Swiper
        spaceBetween={30}
        centeredSlides={true}
        autoplay={{
          delay: 190000,
          disableOnInteraction: false,
        }}
        pagination={{
          clickable: true,
          el: ".custom-swiper-pagination",
        }}
        navigation={false}
        modules={[Autoplay, Pagination, Navigation]}
        className=" max-w-screen-2xl"
      >
        {/* {
                    slideImages && slideImages.map(item => (
                        <SwiperSlide key={item?.id}>
                            <img src={item?.imagePath} alt={`Slide${item?.id}`} className='object-cover w-full h-full' />
                        </SwiperSlide>
                    ))
                } */}
        {Array.from({ length: 3 }).map((_, index) => (
          <SwiperSlide key={index}>
            <PreApprovedOffer />
          </SwiperSlide>
        ))}
      </Swiper>
      <div className="absolute bottom-0 lg:bottom-[20px] left-0 lg:left-[10px] w-full z-10">
        <div className="custom-swiper-pagination text-center lg:text-left"></div>
      </div>
    </div>
  );
};

export default Carousel;
