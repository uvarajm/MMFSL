import { takeLatest, call, put } from "redux-saga/effects";
import {
  fetchRegisteredUserStatusData,
  fetchRegisteredUserStatusDataSuccess,
  fetchRegisteredUserStatusDataFailure,
} from "../slices/registrationUserStatusSlice";
import { REGISTERED_USER_STATUS } from "../actions/actions";
import { endpoints } from "../../utils/apiUtils";

function* fetchRegisteredUserStatus(data) {
  try {
    const { payload } = data;
    const { token, ...restPayload } = payload;
    yield put(fetchRegisteredUserStatusData());
    const config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const response = yield call(
      endpoints.registrationStatus,
      "POST",
      restPayload,
      config,
    );
    yield put(fetchRegisteredUserStatusDataSuccess(response?.data));
  } catch (error) {
    yield put(fetchRegisteredUserStatusDataFailure(error.message));
  }
}
export function* watchFetchRegisteredUserStatus() {
  yield takeLatest(REGISTERED_USER_STATUS, fetchRegisteredUserStatus);
}
