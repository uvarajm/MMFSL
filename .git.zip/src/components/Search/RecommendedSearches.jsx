import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const RecommendedSearches = ({ recommended }) => (
  <div className="mt-4">
    <div className="header__search_title">Recommended</div>
    <ul className="header__search_recommended_lists">
      {recommended.map((result) => (
        <li key={result.title} className="recommended_list__item">
          <Link to={result.url}>{result.title}</Link>
        </li>
      ))}
    </ul>
  </div>
);

RecommendedSearches.propTypes = {
  recommended: PropTypes.array.isRequired,
};

export default RecommendedSearches;
