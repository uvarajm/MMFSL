import { useState } from "react";
import { Breadcrumb, MainContainer } from "../../components";
import ProgressCircleBar from "../../components/ProgressCircleBar/ProgressCircleBar";
import calendar from "../../assets/icons/calendar.svg";
import DatePickerValue from "../../components/DatePicker/DatePickerTextBox";
import { default as MonthsTenureBar } from "../../components/RangeSelectorBar";
import { TENURE_SLOTS_FOR_DATE_RANGE } from "../../const/common";

const FdOnboarding = () => {
  const progress = 40;
  const [selectedTenure] = useState(12);
  const handleRangeChange = () => {
    // console.log("Selected months:", value);
  };

  return (
    <MainContainer className={`flex flex-col xl:px-4`}>
      <div className="sticky top-[64px] sm:top-[48px] z-10 bg-white max-lg:px-2">
        <Breadcrumb />
        <DatePickerValue
          title="Enter your date of birth"
          icon={calendar}
          fontSize="large"
        />
        <ProgressCircleBar progress={progress} />
        <MonthsTenureBar
          defaultValue={selectedTenure}
          onChange={handleRangeChange}
          slots={TENURE_SLOTS_FOR_DATE_RANGE}
        />
      </div>
    </MainContainer>
  );
};
export default FdOnboarding;
