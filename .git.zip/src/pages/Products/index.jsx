import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import {
  MainContainer,
  ProductFeatures,
  InProgress,
  ActiveProducts,
  CompletedProducts,
} from "../../components";
import {
  IN_PROGRESS_PRODUCTS,
  LOAN_LIST,
  PRODUCT_CATEGORY,
} from "../../store/actions/actions";
import { PRODUCT_PAGE_CONSTANTS } from "../../const/common";
import { isObjectBlank } from "../../utils";
import ProductPageDetails from "./ProductPageDetails";
import Sidebar from "../../components/OfferSidebar";
// import loanListDataResponse from "./activeProductMockData.json";

const Explore = () => {
  const { loginStatus, mobileNumber, ucic } = useSelector(
    (state) => state.login,
  );
  const dispatch = useDispatch();
  const {
    categoryProduct,
    error: categoryError,
    loading: categoryLoading,
  } = useSelector((state) => state.categoryProduct);
  const {
    progressData,
    error: progressError,
    loading: progressLoading,
  } = useSelector((state) => state.progressData);
  const {
    loanListDataResponse,
    error: loanListError,
    loading: loanListLoading,
  } = useSelector((state) => state.loanListDataResponse);
  useEffect(() => {
    if (isObjectBlank(categoryProduct))
      dispatch({
        type: PRODUCT_CATEGORY,
      });

    if (loginStatus == true) {
      if (isObjectBlank(progressData))
        dispatch({
          type: IN_PROGRESS_PRODUCTS,
          payload: mobileNumber,
        });
      if (isObjectBlank(loanListDataResponse)) {
        dispatch({
          type: LOAN_LIST,
          payload: ucic,
        });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const filteredApplications = progressData?.loanApplicationStatusList?.filter(
    (application) => application.applicationStatus === "Completed",
  );
  const activeApplications = loanListDataResponse?.data?.filter(
    (application) => application.loanStatus !== "Completed",
  );
  const completedApplications = loanListDataResponse?.data?.filter(
    (application) => application.loanStatus === "Completed",
  );

  const [EXPLORE, IN_PROGRESS, ACTIVE, COMPLETED] =
    PRODUCT_PAGE_CONSTANTS.PRODUCT_TABS;
  let defaultActiveTab = loginStatus ? ACTIVE : EXPLORE;
  const renderTabContent = (activeTab) => {
    const tabContentMap = {
      [EXPLORE]: (
        <ProductFeatures
          categoryProduct={categoryProduct?.product_feature}
          error={categoryError}
          loading={categoryLoading}
        />
      ),
      [IN_PROGRESS]: (
        <InProgress
          progressData={progressData}
          error={progressError}
          loading={progressLoading}
          filteredApplications={filteredApplications}
        />
      ),
      [ACTIVE]: (
        <ActiveProducts
          loanListDataResponse={activeApplications}
          error={loanListError}
          loading={loanListLoading}
        />
      ),
      [COMPLETED]: (
        <CompletedProducts completedApplications={completedApplications} />
      ),
    };

    return tabContentMap[activeTab];
  };
  return (
    <MainContainer className="" showSidebar={true}>
      <ProductPageDetails
        renderTabContent={renderTabContent}
        productDetails={PRODUCT_PAGE_CONSTANTS}
        defaultActiveTab={defaultActiveTab}
      />
      <Sidebar customClasses="lg:mt-[60px]" />
    </MainContainer>
  );
};

export default Explore;
