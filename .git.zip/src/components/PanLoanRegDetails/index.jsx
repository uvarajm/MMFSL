import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { Input, Button, Container, Help } from "..";
import { useState } from "react";
import { items } from "../../utils";

// Import statements...

function PanLoanRegDetails() {
  const navigate = useNavigate();

  const initialValues = {
    panDetails: "",
    loanDetails: "",
  };

  const [isPan, setIsPan] = useState(false);
  const [isLoan, setIsLoan] = useState(false);

  const validationSchema_pan = Yup.object({
    panDetails: Yup.string().required("Enter PAN").min(10),
  });

  const validationSchema_loan = Yup.object({
    loanDetails: Yup.string().required("Enter Loan Account number").min(10),
  });

  const panClick = () => {
    setIsPan(true);
    setIsLoan(false);
  };

  const loanClick = () => {
    setIsLoan(true);
    setIsPan(false);
  };

  const onSubmit = () => {
    navigate("/register/set-password");
  };

  return (
    <Container>
      <div className="relative w-[560px] h-[580px] flex flex-col border p-4">
        <div className="absolute right-7">
          <Help helpTitle="OTP Issues" items={items} />
        </div>

        <div className="flex flex-col flex-1 gap-2 mt-14">
          <h1 className="text-3xl">Enter more details</h1>
          <p>we need few more details to verify account</p>

          {!isPan && !isLoan && (
            <div className="flex-1 space-y-4">
              <button
                className="bg-transparent border border-gray-500 text-gray-500 hover:bg-gray-100
               hover:text-gray-700 py-2 px-4 rounded-md w-full"
                onClick={panClick}
              >
                Pan Card
              </button>
              <p className="text-center">OR</p>
              <button
                className="bg-transparent border border-gray-500 text-gray-500
                 hover:bg-gray-100 hover:text-gray-700 py-2 px-4 rounded-md w-full"
                onClick={loanClick}
              >
                Loan Account
              </button>
            </div>
          )}

          {/* pan form */}

          {isPan && !isLoan && (
            <div className="flex flex-col flex-1 space-y-4">
              <button
                className="bg-gray-300 px-4 py-2 rounded-md cursor-not-allowed opacity-50 w-full"
                disabled
              >
                Pancard
              </button>

              <div className="flex-1">
                <Formik
                  initialValues={initialValues}
                  validationSchema={validationSchema_pan}
                  onSubmit={onSubmit}
                >
                  {(formik) => (
                    <Form className="flex flex-col justify-between h-full">
                      <div>
                        <Input
                          name="panDetails"
                          label="PAN card Number"
                          placeholder="Enter PAN card number"
                          formik={formik}
                        />
                        <p className=" text-gray-500">Eg:ABCDE1234F</p>
                      </div>

                      <div className="flex flex-col items-center">
                        <Button
                          type="submit"
                          name="Verify"
                          disabled={!(formik.isValid && formik.dirty)}
                          className="bg-black-100 hover:opacity-85 text-white w-full h-12 mt-2"
                        >
                          Verify
                        </Button>
                        <button
                          type="button"
                          className="underline self-center"
                          onClick={loanClick}
                        >
                          Try Account number instead
                        </button>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </div>
          )}

          {/* loan form */}
          {!isPan && isLoan && (
            <div className="flex flex-col flex-1 space-y-4">
              <div className="flex-1">
                <Formik
                  initialValues={initialValues}
                  validationSchema={validationSchema_loan}
                  onSubmit={onSubmit}
                >
                  {(formik) => (
                    <Form className="flex flex-col justify-between h-full">
                      <div>
                        <Input
                          name="loanDetails"
                          label="Loan Account number"
                          placeholder="Enter Loan Account number"
                          formik={formik}
                        />
                        <p className="text-gray-500">Eg: ABCDE1234F</p>
                      </div>

                      <div className="flex items-end justify-between w-full">
                        <Button
                          type="submit"
                          name="Verify"
                          disabled={!(formik.isValid && formik.dirty)}
                          className="bg-black-100 hover:opacity-85 text-white h-12 w-full"
                        />
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </div>
          )}
        </div>
      </div>
    </Container>
  );
}
export default PanLoanRegDetails;
