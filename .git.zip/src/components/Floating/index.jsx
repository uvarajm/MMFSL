import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import Locate from "../../assets/locate-us/location.svg";
import FloatingIcon from "../../assets/locate-us/floating-icon.svg";
import Mobile from "../../assets/locate-us/mobile.svg";
import Chat from "../../assets/locate-us/chat.svg";
import CallExecutive from "../CallExecutive";
import { CMS_TOKEN } from "../../const/common";
import { formatNumber } from "../../utils/utils";
import { endpoints, makeApiRequest } from "../../utils/apiUtils";
import { useLayoutEffect, useState } from "react";
import { isObjectBlank } from "../../utils";

const Floating = ({
  showOverlay,
  setShowOverlays,
  handleLocateOpen,
  showCallExecutive,
  setShowCallExecutive,
}) => {
  const [callNumber, setCallNumber] = useState("");

  const fetchServiceRequestDetails = async () => {
    try {
      const response = await makeApiRequest(
        endpoints.callExecutive,
        CMS_TOKEN,
        "GET",
      );

      if (response) {
        setCallNumber(response?.data?.toll_free_number);
      }

      // console.log(typeof response?.data?.toll_free_number);
    } catch (error) {
      console.log(error);
    }
  };

  useLayoutEffect(() => {
    if (!isObjectBlank(callNumber)) {
      fetchServiceRequestDetails();
    }
  }, []);

  // SvgIcon component is not working

  return (
    <div className={`absolute z-30 w-[114px] h-[141px] right-2 bottom-[5px]`}>
      {showOverlay && (
        <div className="relative h-full">
          {showCallExecutive && (
            <CallExecutive
              className="absolute top-4 right-4 transition duration-100 ease-in-out"
              setShowCallExecutive={setShowCallExecutive}
              tollFreeNumber={formatNumber(callNumber)}
            />
          )}

          <button
            onClick={() => {
              setShowCallExecutive(!showCallExecutive);
            }}
          >
            <div className="container-icon -right-1 mb-2 top-[30px]">
              <img src={Mobile} alt="mobile" className="pt-2" />
              <p className="pb-2 label !font-medium label_md label_primary-dark">
                Call
              </p>
            </div>
          </button>

          <div className="container-icon mb-2 right-[56px] bottom-4">
            <img src={Chat} alt="chat" className="pt-2" />
            <p className="pb-2 label !font-medium label_md label_primary-dark">
              Chat
            </p>
          </div>

          <Link
            to={"/locate-us"}
            onClick={() => setShowOverlays(false)}
            className="container-icon mt-[5px] right-[54px] -bottom-[40px]"
          >
            <img src={Locate} alt="locate" className="pt-2" />
            <p className="pb-2 label !font-medium label_md label_primary-dark">
              Locate
            </p>
          </Link>
        </div>
      )}
      <div className="absolute right-2 bottom-0">
        <img
          src={FloatingIcon}
          alt="floating-icon"
          width={40}
          height={40}
          className="cursor-pointer"
          onClick={handleLocateOpen}
        />
      </div>
    </div>
  );
};

Floating.propTypes = {
  showOverlay: PropTypes.bool.isRequired,
  setShowOverlays: PropTypes.func.isRequired,
  handleLocateOpen: PropTypes.func.isRequired,
  showCallExecutive: PropTypes.bool.isRequired,
  setShowCallExecutive: PropTypes.func.isRequired,
};

export default Floating;
