import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchStateListStatusData,
  fetchStateListDataSuccess,
  fetchStateListDataFailure,
} from "../slices/StateListSlice";
import { STATE_LIST } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchStateListStatus({ payload }) {
  try {
    yield put(fetchStateListStatusData());

    const responseState = yield call(
      makeApiRequest,
      endpoints.stateList,
      BACKEND_TOKEN,
      "GET",
      {},
    );

    let responseCity = null;
    if (payload) {
      responseCity = yield call(
        makeApiRequest,
        endpoints.cityList,
        BACKEND_TOKEN,
        "POST",
        payload,
      );
    }

    const combineResponse = {
      state: responseState,
      city: responseCity,
    };
    yield put(fetchStateListDataSuccess(combineResponse));
  } catch (error) {
    yield put(fetchStateListDataFailure(error.message));
  }
}

export function* watchFetchStateList() {
  yield takeLatest(STATE_LIST, fetchStateListStatus);
}
