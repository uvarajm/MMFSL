// saga.js
import { takeLatest, put, call } from "redux-saga/effects";
import {
  fetchLeadGenStatusData,
  fetchLeadGenDataSuccess,
  fetchLeadGenDataFailure,
} from "../slices/leadGenSlice";
import { LEAD_GEN } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { endpoints } from "../../utils/apiUtils";

function* fetchLeadGenStatus(action) {
  try {
    yield put(fetchLeadGenStatusData());
    const mobileNumber = action.payload.mobileNumber;
    const pincode = action.payload.pincode;
    const fullName = action.payload.fullName;
    const leadType = "PL";
    const tokenName = "backendToken";
    const response = yield call(
      makeApiRequest,
      endpoints.leadGen,
      tokenName,
      "POST",
      {
        mobileNumber,
        pincode,
        fullName,
        leadType,
      },
    );
    yield put(fetchLeadGenDataSuccess(response));
  } catch (error) {
    yield put(fetchLeadGenDataFailure(error.message));
  }
}

export function* watchFetchLeadGenStatus() {
  yield takeLatest(LEAD_GEN, fetchLeadGenStatus);
}
