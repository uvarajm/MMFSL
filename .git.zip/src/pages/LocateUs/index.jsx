import { useEffect, useLayoutEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import { Button, Input, MainContainer, MyLocation } from "../../components";
import BackButton from "../../components/Common/BackButton";
import { pinCodeValidation } from "../../utils/validation";
import SelectDropdown from "../../components/Common/SelectDropdown";
import {
  BRANCH_STATE_CITY_CODE,
  DEALER_PINCODE_DATA,
  DEALER_STATE_CITY_CODE,
  GET_SAVED_BOOKMARKS_DATA,
  PIN_CODE_DATA,
  STATE_LIST,
} from "../../store/actions/actions";
import { isObjectBlank } from "../../utils";
import Map from "../../components/Map";
import { CASH_COLLECTION_POINTS } from "../../const/locateConst";
import Sidebar from "../../components/OfferSidebar";
import Loader from "../../components/Common/Loader";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../../components/Common/SvgIcon";
import { resetDealerPinCodeData } from "../../store/slices/pinCodeStatusSlice";

const initialValues = {
  pinCode: "",
};

const validationSchema = Yup.object({
  pinCode: pinCodeValidation("Enter pincode"),
});

const LocateUs = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { MyLocationIcon } = iconConfig;
  const { stateAllList, loading: stateLoading } = useSelector(
    (state) => state.stateList,
  );
  const { latitude, longitude } = useSelector((state) => state.geoLocation);
  const { pinCodeData, loading: pinCodeLoading } = useSelector(
    (state) => state.pinCodeData,
  );
  const [selectedValueState, setSelectedValueState] = useState("");
  const [selectedValueCity, setSelectedValueCity] = useState("");
  const [selectedPincodeValue, setSelectedPincodeValue] = useState("");

  const [cityList, setCityList] = useState([]);
  const [stateList, setStateList] = useState([]);
  const [showMap, setShowMap] = useState(false);
  const location = useLocation();
  let redirectFrom = location.state?.redirectFrom || "";
  const { superAppId } = useSelector((state) => state.login);

  useEffect(() => {
    if (redirectFrom === "location") {
      setShowMap(false);
    }
    redirectFrom = " ";
    dispatch(resetDealerPinCodeData());
  }, []);

  useEffect(() => {
    if (latitude && longitude) {
      setShowMap(!showMap);
    }
  }, [latitude, longitude]);

  useLayoutEffect(() => {
    if (isObjectBlank(stateAllList?.state)) {
      dispatch({ type: STATE_LIST });
    }
  }, [stateAllList]);

  useEffect(() => {
    if (selectedValueState) {
      dispatch({
        type: STATE_LIST,
        payload: { stateCode: selectedValueState },
      });
    }
  }, [selectedValueState]);

  const handleStateChange = (value, formik) => {
    setSelectedValueState(value);
    setSelectedValueCity("");
    formik.setFieldValue("pinCode", "");
  };

  const handleCityChange = (value, formik) => {
    setSelectedValueCity(value);
    formik.setFieldValue("pinCode", "");
  };

  const handlePinCodeChange = (formik) => (e) => {
    formik.handleChange(e);
    setSelectedPincodeValue(e.target.value);
    setSelectedValueState("");
    setSelectedValueCity("");
  };

  const onSubmit = (values) => {
    if (values.pinCode) {
      dispatch({ type: PIN_CODE_DATA, payload: values?.pinCode });
      dispatch({ type: DEALER_PINCODE_DATA, payload: values?.pinCode });
      dispatch({
        type: GET_SAVED_BOOKMARKS_DATA,
        payload: { superAppId: superAppId },
      });
      setSelectedValueCity("");
      setSelectedValueState("");
    } else {
      if (selectedValueState && selectedValueCity) {
        dispatch({
          type: BRANCH_STATE_CITY_CODE,
          payload: {
            stateCode: selectedValueState,
            cityCode: selectedValueCity,
          },
        });
        dispatch({
          type: DEALER_STATE_CITY_CODE,
          payload: {
            stateCode: selectedValueState,
            cityCode: selectedValueCity,
          },
        });
        dispatch({
          type: GET_SAVED_BOOKMARKS_DATA,
          payload: { superAppId: superAppId },
        });
      }
    }
  };

  const findStateNameByCode = (code) => {
    const state = stateList.find((state) => state.stateCode === code);
    return state ? state.stateName.trim() : "State not found";
  };

  const findCityNameByCode = (code) => {
    const state = cityList.find((state) => state.cityCode === code);
    return state ? state.cityName.trim() : "State not found";
  };

  useEffect(() => {
    const StateCity = `${findStateNameByCode(selectedValueState, "stateName")} ${findCityNameByCode(selectedValueCity, "cityName")}`;

    if (!isObjectBlank(pinCodeData)) {
      navigate("/locate-us/details", {
        state: { locate: selectedPincodeValue || StateCity },
      });
    }
  }, [pinCodeData]);
  // sorting state
  useEffect(() => {
    if (stateAllList?.state?.stateList) {
      const sortedStateList = [...stateAllList.state.stateList].sort((a, b) => {
        const nameA = a.stateName.trim();
        const nameB = b.stateName.trim();
        if (nameA < nameB) return -1;
        if (nameA > nameB) return 1;
        return 0;
      });
      setStateList(sortedStateList);
    }
  }, [stateAllList]);

  // sorting city
  useEffect(() => {
    if (stateAllList?.city?.cityList) {
      const sortedCityList = [...stateAllList.city.cityList].sort((a, b) => {
        const nameA = a.cityName;
        const nameB = b.cityName;
        if (nameA < nameB) return -1;
        if (nameA > nameB) return 1;
        return 0;
      });
      setCityList(sortedCityList);
    }
  }, [cityList, stateAllList]);

  const handleCallBack = () => {
    setShowMap(!showMap);
  };

  return (
    <MainContainer className={`flex lg:pt-4 px-4 lg:px-12 dark:text-white`}>
      <div className="sidebar-width">
        <div className="w-full flex justify-between flex-wrap lg:flex-nowrap">
          <div className="w-full">
            <div className="flex items-center pt-4 pb-6">
              <BackButton />
              <p className="headline headline_md">
                {CASH_COLLECTION_POINTS?.MAIN_PAGE_TITLE}
              </p>
            </div>
            {showMap ? (
              <Map handleCallBack={handleCallBack} />
            ) : (
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {(formik) => (
                  <Form className="flex flex-col">
                    <div className="">
                      <div className="w-full flex">
                        <Input
                          type="text"
                          name="pinCode"
                          label="Enter pincode"
                          placeholder="Enter pincode"
                          className="lg:w-[328px] w-[310px]"
                          formik={formik}
                          onChange={handlePinCodeChange(formik)}
                        />
                        <SvgIcon
                          url={MyLocationIcon}
                          className="pl-4 pt-5"
                          alt="location"
                        />
                      </div>
                      <span className="flex justify-center pt-4 w-[328px] label label_lg label_primary !font-bold">
                        or
                      </span>
                    </div>
                    <div className="lg:w-[328px] w-[310px] flex justify-between pt-4">
                      <SelectDropdown
                        label={"State"}
                        minWidth={"155px"}
                        options={stateList}
                        optionLabelProp="stateName"
                        optionValueProps="stateCode"
                        selectedValue={selectedValueState}
                        setSelectedValue={(value) =>
                          handleStateChange(value, formik)
                        }
                      />
                      <SelectDropdown
                        label={"City"}
                        minWidth={"155px"}
                        options={cityList}
                        optionLabelProp="cityName"
                        optionValueProps="cityCode"
                        selectedValue={selectedValueCity}
                        setSelectedValue={(value) =>
                          handleCityChange(value, formik)
                        }
                        disabled={selectedValueState ? false : true}
                      />
                    </div>
                    <div className="pt-10 sm:w-[178px] w-full">
                      <Button
                        disabled={
                          !formik.values.pinCode &&
                          !(selectedValueState && selectedValueCity)
                        }
                        type="submit"
                        name="Search"
                        className="hover:opacity-85 w-full rounded-lg label label_lg text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
                      />
                    </div>
                  </Form>
                )}
              </Formik>
            )}
          </div>
        </div>

        <MyLocation />

        {(stateLoading || pinCodeLoading) && <Loader />}
        {/* {!isObjectBlank(stateAllList) && !showMap && (
          <Toaster
            className="justify-center"
            text={"State not found"}
            url={iconConfig.Cancel}
            colorClass={"fill-red-500"}
          />
        )} */}
      </div>
      <Sidebar className="pt-[50px] lg:pt-0" />
    </MainContainer>
  );
};

export default LocateUs;
