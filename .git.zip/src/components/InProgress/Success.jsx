import PropTypes from "prop-types";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import { INPROGRESS_PRODUCT_CONSTANTS } from "../../const/common";

const LoanSuccess = ({ filteredApplications }) => {
  return (
    <div className="flex flex-col gap-2 lg:gap-4">
      {filteredApplications &&
        filteredApplications.map((application, index) => {
          return (
            <div key={index} className="bg-white p-4 rounded-lg">
              <div
                className={`flex items-center w-full justify-between border-b-2 pb-4 border-light-border-color dark:border-dark-border-color`}
              >
                <div className="flex">
                  <svg
                    width="56"
                    height="56"
                    viewBox="0 0 56 56"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="56" height="56" rx="8" fill="#EDE0E3" />
                    <mask
                      id="mask0_1_81064"
                      style={{ maskType: "alpha" }}
                      maskUnits="userSpaceOnUse"
                      x="5"
                      y="7"
                      width="46"
                      height="45"
                    >
                      <rect
                        x="5.59961"
                        y="7"
                        width="44.8"
                        height="44.6634"
                        fill="#D9D9D9"
                      />
                    </mask>
                    <g mask="url(#mask0_1_81064)"></g>
                    <mask
                      id="mask1_1_81064"
                      style={{ maskType: "alpha" }}
                      maskUnits="userSpaceOnUse"
                      x="8"
                      y="8"
                      width="40"
                      height="40"
                    >
                      <rect x="8" y="8" width="40" height="40" fill="#D9D9D9" />
                    </mask>
                    <g mask="url(#mask1_1_81064)">
                      <path
                        d="M18.1925 37.0298V38.53C18.1925 38.9977 18.021 39.3953 17.6779 39.7227C17.3347 40.0501 16.9181 40.2139 16.4279 40.2139C15.9377 40.2139 15.5217 40.0501 15.1798 39.7227C14.8379 39.3953 14.667 38.9977 14.667 38.53V27.3C14.667 27.1347 14.6782 26.9694 14.7007 26.804C14.7231 26.6387 14.7609 26.4803 14.8139 26.329L17.7984 18.2683C17.9981 17.695 18.3601 17.2292 18.8845 16.8708C19.4087 16.5125 19.9954 16.3333 20.6445 16.3333H37.0227C37.6718 16.3333 38.2585 16.5125 38.7828 16.8708C39.3071 17.2292 39.6691 17.695 39.8688 18.2683L42.8533 26.329C42.9064 26.4803 42.9441 26.6387 42.9666 26.804C42.989 26.9694 43.0002 27.1347 43.0002 27.3V38.53C43.0002 38.9977 42.8287 39.3953 42.4855 39.7227C42.1424 40.0501 41.7257 40.2139 41.2356 40.2139C40.7454 40.2139 40.3294 40.0501 39.9875 39.7227C39.6456 39.3953 39.4747 38.9977 39.4747 38.53V37.0298H18.1925ZM18.1797 24.416H39.4875L37.5131 19.0429C37.4704 18.9408 37.4063 18.8617 37.3208 18.8056C37.2353 18.7494 37.1338 18.7214 37.0163 18.7214H20.651C20.5334 18.7214 20.4319 18.7494 20.3465 18.8056C20.261 18.8617 20.1969 18.9408 20.1541 19.0429L18.1797 24.416ZM21.2733 32.8048C21.8797 32.8048 22.394 32.602 22.816 32.1965C23.238 31.791 23.449 31.2986 23.449 30.7193C23.449 30.14 23.2367 29.6488 22.8122 29.2457C22.3877 28.8426 21.8722 28.641 21.2657 28.641C20.6593 28.641 20.1451 28.8438 19.723 29.2493C19.301 29.6548 19.09 30.1472 19.09 30.7265C19.09 31.3058 19.3023 31.797 19.7268 32.2001C20.1514 32.6032 20.6668 32.8048 21.2733 32.8048ZM36.4015 32.8048C37.0079 32.8048 37.5222 32.602 37.9442 32.1965C38.3662 31.791 38.5772 31.2986 38.5772 30.7193C38.5772 30.14 38.3649 29.6488 37.9404 29.2457C37.5159 28.8426 37.0004 28.641 36.394 28.641C35.7875 28.641 35.2733 28.8438 34.8513 29.2493C34.4293 29.6548 34.2182 30.1472 34.2182 30.7265C34.2182 31.3058 34.4305 31.797 34.855 32.2001C35.2796 32.6032 35.7951 32.8048 36.4015 32.8048ZM17.167 34.6418H40.5003V26.804H17.167V34.6418Z"
                        fill="#691A1E"
                      />
                    </g>
                  </svg>
                  <div
                    className={`flex flex-col pl-4 text-light-text-primary justify-center`}
                  >
                    <p className={`text-xs`}>{application.loanType}</p>
                    <p className="text-sm font-semibold">
                      {INPROGRESS_PRODUCT_CONSTANTS.APPLICATION_ID_PREFIX}
                      {application.applicationNumber}
                    </p>
                  </div>
                </div>
                <KeyboardArrowRightIcon className="text-red-800" />
              </div>
              <div className="status-update mt-4">
                <p className={`text-sm font-semibold text-light-text-primary`}>
                  {INPROGRESS_PRODUCT_CONSTANTS.CONGRATULATION}
                </p>
                <p className="text-xs text-grey-500 font-karla mt-2">
                  {INPROGRESS_PRODUCT_CONSTANTS.SUCCESS_MSG}
                </p>
              </div>
            </div>
          );
        })}
    </div>
  );
};

LoanSuccess.propTypes = {
  filteredApplications: PropTypes.array,
};

export default LoanSuccess;
