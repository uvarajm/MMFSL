/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        karla: "Karla",
        quicksand: "Quicksand",
      },
      colors: {
        black: {
          100: "#161616",
          200: "#1b0808",
        },
        red: {
          100: "#A1626B",
          200: "#BA8F94",
          500: "#E31837",
          600: "#9A0D00",
          700: "#F6BBC5",
          800: "#691A1E",
        },
        grey: {
          100: "#A59E9B",
          200: "#B0B0B0",
          300: "#190607",
          400: "rgba(25, 6, 7, 0.4)",
          500: "#333333",
          600: "#A5A5A5",
          700: "#3C2C26",
          800: "#7C726E",
          900: "#635651",
        },
        lilac: {
          dark: "#BA8F94",
          light: "#EDE0E3",
        },
        yellow: {
          100: "#E68600",
        },
        green: {
          500: "#238823",
        },
        searchBg: "rgba(237, 224, 227, 0.6)",
        // light theme color
        "light-primary": "rgba(252, 229, 241, 0.4)",
        "light-secondary": "rgba(237, 175, 181, 0.04)",
        "light-coral": "rgba(223, 122, 122, 0)",

        // dark theme color
        "dark-primary": "rgba(224, 166, 80, 0.28)",
        "dark-secondary": "rgba(127, 92, 74, 0)",
        "dark-coral": "rgba(25, 6, 7, 1)",

        // theme border color
        "light-border-color": "rgba(237, 224, 227, 1)",
        "dark-border-color": "rgba(224, 166, 80, 0.28)",

        // light text color
        "light-text-primary": "rgba(105, 26, 30, 1)",
        "light-text-active": "rgba(227, 24, 55, 1)",

        // dark text color
        "dark-text-primary": "rgba(255, 255, 255, 1)",
        "dark-text-secondary": "rgba(246, 187, 197, 1)",

        // text Breadcrumb
        "light-text-breadcrumb": "rgba(51, 51, 51, 1)",

        // Button color
        "button-bg-red": "#E31837",
        "disable-red": "#D3B9BD",
        "tac-blue": "#1d4ed8",
        // Search Input
        "search-bg-input": "rgba(237, 224, 227, 0.6)",
        "search-text-color": "rgba(161, 98, 107, 1)",
      },
      boxShadow: {
        "custom-primary": "0px 1px 2px 0px #0000000D",
      },
      maxWidth: {
        "3xl": "1440px",
      },
      fontSize: {
        largeScreen: ["22px", "28px"],
      },
    },
  },
  plugins: [
    /*require("tailwind-scrollbar")*/
    function ({ addUtilities }) {
      const newUtilities = {
        ".scrollbar-thin": {
          scrollbarWidth: "thin",
          scrollbarColor: "rgb(176 176 176) white ",
          borderRadius: "10px",

          "&::-webkit-scrollbar": {
            width: "4px",
            height: "116px",
            scrollbarArrowColor: "transparent",
            borderRadius: "10px",
            backgroundColor: "white",
          },

          "&::-webkit-scrollbar-button": {
            display: "none",
            height: "40px",
          },
        },
        "scrollbar-webkit": {
          "&::-webkit-scrollbar": {
            width: "8px",
            height: "116px",
            scrollbarGutter: "0",
            borderRadius: "10px",
          },
          "&::-webkit-scrollbar-track": {
            background: "white",
          },
          /* '&::-webkit-scrollbar-thumb': {
            
            borderRadius: '20px',
            border: '1px solid white',
          },*/
        },
      };
      addUtilities(newUtilities, ["responsive", "hover"]);
    },
  ],
};
