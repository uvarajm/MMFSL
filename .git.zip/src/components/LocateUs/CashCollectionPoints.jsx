import { Link } from "react-router-dom";
import { CASH_COLLECTION_POINTS } from "../../const/locateConst";

const CashCollectionPoints = () => {
  const {
    PAGE_TITLE,
    PAYMENT_FINO_TITLE,
    PAYMENT_FINO_LINK,
    PAYMENT_CSC_TITLE,
    PAYMENT_CSC_LINK,
    PAYMENT_POST_OFFICE_TITLE,
    PAYMENT_POST_OFFICE_LINK,
  } = CASH_COLLECTION_POINTS;
  return (
    <div className="w-full">
      <p className="label label-primary label-lg pb-4 leading-[22px]">
        {PAGE_TITLE}
      </p>
      <div className="pt-2 lg:w-[680px]">
        <Link
          className="mb-4 label label-primary-red label-md"
          target="_blank"
          to={PAYMENT_FINO_LINK}
          rel="nofollow"
        >
          {PAYMENT_FINO_TITLE}
        </Link>
        <hr className="w-full border-lilac-light dark:border-grey-900" />

        <Link
          className="label label-primary-red label-md my-4"
          target="_blank"
          to={PAYMENT_CSC_LINK}
          rel="nofollow"
        >
          {PAYMENT_CSC_TITLE}{" "}
        </Link>
        <hr className="w-full border-lilac-light dark:border-grey-900" />

        <Link
          className="label label-primary-red label-md mt-4"
          target="_blank"
          to={PAYMENT_POST_OFFICE_LINK}
          rel="nofollow"
        >
          {PAYMENT_POST_OFFICE_TITLE}
        </Link>
      </div>
    </div>
  );
};

export default CashCollectionPoints;
