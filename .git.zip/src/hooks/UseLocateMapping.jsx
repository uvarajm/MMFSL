import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { capitalizeWords } from "../utils/utils";
import BookmarkIconFill from "../assets/locate-us/bookmark.svg";
import PathIcon from "../assets/locate-us/fork_right.svg";
import CallIcon from "../assets/locate-us/call.svg";
import BookmarkOutline from "../assets/locate-us/bookmark-outline.svg";
// import { useState } from "react";
import { CASH_COLLECTION_POINTS } from "../const/locateConst";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { updateBookMarks } from "../store/slices/saveBranchesEvent";
import { Toaster } from "../components";
import iconConfig from "../assets/iconsConfig";

const UseLocateMapping = ({ item }) => {
  const dispatch = useDispatch();
  const [isBookMarked, setIsBookMarked] = useState(item.saved);
  const [showToaster, setShowToaster] = useState(false);

  const bookmarksHandle = (code) => {
    setIsBookMarked(!isBookMarked);
    dispatch(updateBookMarks({ isBookmarks: !isBookMarked, code: code }));
    setShowToaster(true);
    setTimeout(() => {
      setShowToaster(false);
    }, 3000);
  };

  return (
    <div className="w-full">
      <div className="w-full flex justify-between items-center">
        <p className="label label_lg label_primary">
          {item?.name && capitalizeWords(item.name)}
        </p>
        <div
          className="pr-1 cursor-pointer"
          onClick={() => {
            bookmarksHandle(item?.code);
          }}
        >
          {isBookMarked ? (
            <img src={BookmarkIconFill} alt="Bookmark Filled Icon" />
          ) : (
            <img src={BookmarkOutline} alt="Bookmark Outline Icon" />
          )}
        </div>
      </div>
      <div className="pr-[38px] pt-[10px]">
        <p className="content content_md content_secondary">
          {item?.address && capitalizeWords(item?.address)}
        </p>
        <p className="pt-1 content content_sm content_secondary leading-3 !font-medium">
          {item?.distance ? item?.distance?.toFixed(2) : "0.00"}{" "}
          {CASH_COLLECTION_POINTS.OPEN_CLOSE_TIMING}
        </p>
      </div>
      <div className="pt-3 pb-4 flex items-center">
        <div className="flex items-center">
          <img src={PathIcon} alt={PathIcon} className="pl-1" />
          <Link
            target="_blank"
            to={`${CASH_COLLECTION_POINTS.MAP_DOMAIN}${item?.lat},${item?.lon}/@${item?.lat},${item?.lon},13z`}
            className="pl-2 label label_md label_primary_dark_red"
          >
            {CASH_COLLECTION_POINTS.GET_DIRECTIONS}
          </Link>
        </div>
        <div className="flex items-center pl-6">
          {item?.mobileNo && (
            <>
              <img src={CallIcon} alt={CallIcon} className="pl-1" />
              <Link
                to={`tel:${item?.mobileNo}`}
                className="pl-2 label label_md label_primary_dark_red"
              >
                {item?.mobileNo?.length >= 10
                  ? item?.mobileNo
                  : ` +91 ${item?.mobileNo}`}
              </Link>
            </>
          )}
        </div>
      </div>
      <hr className="w-full border-light-border-color dark:border-dark-border-color mb-4" />
      {showToaster && (
        <Toaster
          className="justify-center"
          showToaster={showToaster}
          text={"Bookmarks updated successfully"}
          url={iconConfig.CheckCircleFilled}
          colorClass={"fill-green-500"}
        />
      )}
    </div>
  );
};

UseLocateMapping.propTypes = {
  item: PropTypes.shape({
    distance: PropTypes.number,
    name: PropTypes.string,
    address: PropTypes.string,
    mobileNo: PropTypes.string,
    saved: PropTypes.bool,
    isBookmarks: PropTypes.bool,
    code: PropTypes.string,
    lat: PropTypes.number,
    lon: PropTypes.number,
  }),
  handleUpdateBookmarks: PropTypes.func,
};

export default UseLocateMapping;
