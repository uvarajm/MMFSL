import { useEffect } from "react";
import { MainContainer } from "../../components";
import { useDispatch, useSelector } from "react-redux";
import { OFFERS } from "../../store/actions/actions";
import ProductPageDetails from "../Products/ProductPageDetails";
import PreApprovedLoans from "../../components/Offers/PreApprovedLoans";
import GenericOffers from "../../components/Offers/GenericOffers";
import { isObjectBlank } from "../../utils";
import { OFFERS_DETAILS } from "../../store/actions/actions";
import OnlyOffers from "../../components/Offers/OnlyOffers";
import Sidebar from "../../components/OfferSidebar";
import HandleDataRendering from "../../components/Common/HandleDataRendering";

export const OFFERS_TABS = {
  PAGE_TITLE: "My Offers",
  PRODUCT_TABS: ["Pre-Approved loans", "Offers"],
};

export const [PREAPPROVED, GENERIC_OFFER] = OFFERS_TABS.PRODUCT_TABS;

const Offers = () => {
  const dispatch = useDispatch();
  const { mobileNumber, ucic } = useSelector((state) => state.login);
  const {
    offers,
    error: offersError,
    loading: offersLoading,
  } = useSelector((state) => state.offers);
  const {
    offersDetails,
    error: offersDetailsError,
    loading: offersDetailsLoading,
  } = useSelector((state) => state.offersDetails);

  useEffect(() => {
    if (isObjectBlank(offers)) {
      dispatch({
        type: OFFERS,
      });
    }

    if (!offersDetails) {
      dispatch({
        type: OFFERS_DETAILS,
        payload: {
          mobileNumber: mobileNumber,
          ucic: ucic,
        },
      });
    }
  }, []);

  const preApprovedLoans = offers?.offers_list?.filter(
    (offer) => offer.offer_type === "personalized_offer",
  );

  const genericOffers = offers?.offers_list?.filter(
    (offer) => offer.offer_type === "generic_offers",
  );

  const renderTabContent = (activeTab) => {
    if (offers && offersDetails) {
      const tabContentMap = {
        [PREAPPROVED]: (
          <PreApprovedLoans
            offers={preApprovedLoans}
            offersDetails={offersDetails}
          />
        ),
        [GENERIC_OFFER]: (
          <GenericOffers
            genericOffers={genericOffers}
            offersDetails={offersDetails}
          />
        ),
      };
      return tabContentMap[activeTab];
    }
  };

  return (
    <HandleDataRendering
      data={offers}
      loading={offersLoading || offersDetailsLoading}
      error={offersDetailsError || offersError}
    >
      <MainContainer className="" showSidebar={true}>
        {preApprovedLoans?.length > 0 && genericOffers?.length > 0 && (
          <ProductPageDetails
            renderTabContent={renderTabContent}
            productDetails={OFFERS_TABS}
            defaultActiveTab={PREAPPROVED}
            showBeforeLogin={true}
          />
        )}
        {preApprovedLoans?.length === 0 && genericOffers?.length > 0 && (
          <OnlyOffers title={"My Offers"}>
            <GenericOffers
              genericOffers={genericOffers}
              offersDetails={offersDetails}
            />
          </OnlyOffers>
        )}

        {preApprovedLoans?.length > 0 && genericOffers?.length === 0 && (
          <OnlyOffers title={"My Offers"}>
            <PreApprovedLoans
              offers={preApprovedLoans}
              offersDetails={offersDetails}
            />
          </OnlyOffers>
        )}
        <Sidebar showPreApproved={false} customClasses="lg:mt-4" />
      </MainContainer>
    </HandleDataRendering>
  );
};
export default Offers;
