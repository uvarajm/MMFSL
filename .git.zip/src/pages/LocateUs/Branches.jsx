import PropTypes from "prop-types";
import UseLazyLoading from "../../hooks/UseLazyLoading";
import { CASH_COLLECTION_POINTS } from "../../const/locateConst";
import { useEffect, useLayoutEffect, useState } from "react";
import { mergeBranchLists } from "../../utils/utils";
import { useSelector } from "react-redux";

const Branches = ({ pinCodeData }) => {
  const [saveList, setSaveList] = useState([]);
  const [branchList, setBranchList] = useState([]);
  const { getSavedBookmarksData } = useSelector((state) => state.getBookmarks);
  useLayoutEffect(() => {
    if (
      getSavedBookmarksData?.dealerList ||
      getSavedBookmarksData?.branchList
    ) {
      const { dealerList = [], branchList = [] } = getSavedBookmarksData;

      const dealerListWithSaved = dealerList.map((dealer) => ({
        ...dealer,
        saved: true,
      }));
      const branchListWithSaved = branchList.map((branch) => ({
        ...branch,
        saved: true,
      }));

      setSaveList([...dealerListWithSaved, ...branchListWithSaved]);
    }
  }, []);

  useEffect(() => {
    const mergedBranchList = mergeBranchLists(
      pinCodeData?.branchList,
      saveList,
    );

    if (mergedBranchList.length > 0) setBranchList(mergedBranchList);
  }, [pinCodeData, saveList]);

  return (
    <div className="w-full">
      <p className="title title_sm title_primary leading-[22px]">
        {branchList?.length} {CASH_COLLECTION_POINTS.BRANCHES_NEAR_YOU}
      </p>
      <div className="pt-2 lg:max-w-[678px] w-full">
        <UseLazyLoading data={branchList} />
      </div>
    </div>
  );
};

Branches.propTypes = {
  pinCodeData: PropTypes.object,
  getSavedBookmarksData: PropTypes.object,
  latitudeLongitudeData: PropTypes.object,
  latitude: PropTypes.number,
  longitude: PropTypes.number,
  superAppId: PropTypes.string,
  handleUpdateBookmarks: PropTypes.func,
  saveLoading: PropTypes.any,
  updateBookmarkData: PropTypes.any,
  loading: PropTypes.bool,
};

export default Branches;
