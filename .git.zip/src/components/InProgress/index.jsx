import PropTypes from "prop-types";
import HandleDataRendering from "../Common/HandleDataRendering";
import LoanStatus from "./LoanStatus";
// import loanData from "../../db.json";
import "../Card/card.css";
import LoanSuccess from "./Success";

const InProgress = ({ progressData, error, loading, filteredApplications }) => {
  const loanApplicationStatusList = progressData?.loanApplicationStatusList;

  return (
    <HandleDataRendering data={progressData} loading={loading} error={error}>
      <>
        <LoanSuccess filteredApplications={filteredApplications} />
        <div className="flex flex-wrap lg:-mx-4">
          {loanApplicationStatusList?.length > 0 &&
            loanApplicationStatusList.map((loans, index) => {
              return <LoanStatus key={index} details={loans} />;
            })}
        </div>
      </>
    </HandleDataRendering>
  );
};

export default InProgress;

InProgress.propTypes = {
  progressData: PropTypes.object,
  filteredApplications: PropTypes.object,
  error: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  loading: PropTypes.bool,
};
