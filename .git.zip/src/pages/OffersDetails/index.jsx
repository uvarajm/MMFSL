/* eslint-disable react-hooks/rules-of-hooks */
import OfferDetailsTabs from "./OfferDetailsTabs";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
const offerDetail = () => {
  const { offers } = useSelector((state) => state.offers);
  const { offersDetails } = useSelector((state) => state.offersDetails);
  const { offerId } = useParams();
  const offer = offers?.offers_list?.find((offer) => offer.offer_id == offerId);

  return <OfferDetailsTabs offer={offer} offerDetails={offersDetails} />;
};

export default offerDetail;
