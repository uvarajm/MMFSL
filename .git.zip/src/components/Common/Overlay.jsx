import PropTypes from "prop-types";
const Overlay = ({ showOverlay, callBackEvent = () => {} }) => {
  return (
    <div
      onClick={() => callBackEvent()}
      className={`${
        showOverlay
          ? "fixed top-0 left-0 right-0 bottom-0 bg-grey-300 opacity-40 z-20"
          : ""
      }`}
    ></div>
  );
};

export default Overlay;

Overlay.propTypes = {
  showOverlay: PropTypes.bool,
  callBackEvent: PropTypes.func,
};
