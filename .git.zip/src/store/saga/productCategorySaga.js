// saga.js
import { takeLatest, put, call } from "redux-saga/effects";
import {
  fetchProductCategoryStatusData,
  fetchProductCategoryStatusDataSuccess,
  fetchProductCategoryStatusDataFailure,
} from "../slices/productCategorySlice";
import { PRODUCT_CATEGORY } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { CMS_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchProductCategoryStatus() {
  try {
    yield put(fetchProductCategoryStatusData());
    // Make API request using the token name
    const response = yield call(
      makeApiRequest,
      endpoints.productFeatures,
      CMS_TOKEN,
    );
    yield put(fetchProductCategoryStatusDataSuccess(response.data));
  } catch (error) {
    yield put(fetchProductCategoryStatusDataFailure(error.message));
  }
}

export function* watchFetchProductCategoryStatus() {
  yield takeLatest(PRODUCT_CATEGORY, fetchProductCategoryStatus);
}
