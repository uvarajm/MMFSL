import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const Info = ({ icon, text, redirectLink, redirectText }) => {
  return (
    <div className="bg-lilac-light rounded-lg p-[18px] flex items-center justify-center mt-6">
      {icon}
      <span className="text-red-800 font-semibold ml-2 mr-[10px]">{text}</span>
      <Link to={redirectLink} className="text-red-500 text-sm font-semibold">
        {redirectText}
      </Link>
    </div>
  );
};

export default Info;

Info.propTypes = {
  icon: PropTypes.string,
  text: PropTypes.string,
  redirectLink: PropTypes.string,
  redirectText: PropTypes.string,
};
