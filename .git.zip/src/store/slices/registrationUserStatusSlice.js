import { createSlice } from "@reduxjs/toolkit";
import { REGISTERED_USER_STATUS } from "../actions/actions";

const initialState = {
  registeredUserStatusData: {},
  loading: false,
  error: null,
};

const registrationUserStatusSlice = createSlice({
  name: REGISTERED_USER_STATUS,
  initialState,
  reducers: {
    fetchRegisteredUserStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchRegisteredUserDataSuccess(state, action) {
      state.loading = false;
      state.registeredUserStatusData = action.payload;
    },
    fetchRegisteredUserDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchRegisteredUserStatusData,
  fetchRegisteredUserStatusDataSuccess,
  fetchRegisteredUserStatusDataFailure,
} = registrationUserStatusSlice.actions;

export default registrationUserStatusSlice.reducer;
