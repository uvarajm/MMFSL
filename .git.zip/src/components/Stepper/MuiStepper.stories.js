import StepperComp from "./index";

export default {
  title: "Stepper",
  component: StepperComp,
};

const Template = (args) => <StepperComp {...args} />;

export const Default = Template.bind({});
Default.args = {
  onChange: () => {},
};
