import { takeLatest, put, call } from "redux-saga/effects";
import { OFFERS } from "../actions/actions";
import {
  fetchOffers,
  fetchOffersSuccess,
  fetchOffersFailure,
} from "../slices/offersSlice";
import { makeApiRequest } from "../../utils/apiUtils";
import { CMS_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";
import offers from "../../../src/pages/Offers/pre_approved_offers.json";
function* fetchOffersGen() {
  try {
    yield put(fetchOffers());
    // Make API request using the token name
    const response = yield call(makeApiRequest, endpoints.offers, CMS_TOKEN);
    console.log(response);
    yield put(fetchOffersSuccess(offers?.data));
  } catch (error) {
    yield put(fetchOffersSuccess(offers?.data));
    yield put(fetchOffersFailure(error.message));
  }
}

export function* watchFetchOffers() {
  yield takeLatest(OFFERS, fetchOffersGen);
}
