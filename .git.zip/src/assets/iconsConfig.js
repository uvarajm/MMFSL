import AccountBalanceWallet from "./icons/account_balance_wallet.svg";
import AccountBalance from "./icons/account_balance.svg";
import AccountCircle from "./icons/account_circle.svg";
import AddAccount from "./icons/Add account.svg";
import AddCard from "./icons/add_card.svg";
import Add from "./icons/add.svg";
import AirplaneModeActive from "./icons/airplanemode_active.svg";
import Alert from "./icons/Alert.svg";
import ApprovalDelegation from "./icons/approval_delegation.svg";
import Apps from "./icons/apps.svg";
import ArrowBack from "./icons/arrow_back.svg";
import ArrowDownwardAlt from "./icons/arrow_downward_alt.svg";
import ArrowLeftAlt from "./icons/arrow_left_alt.svg";
import ArrowRightAlt from "./icons//arrow_right_alt.svg";
import ArrowUpwardAlt from "./icons/arrow_upward_alt.svg";
import Assignment from "./icons/assignment.svg";
import AttachEmail1 from "./icons/attach_email-1.svg";
import AttachEmail from "./icons/attach_email.svg";
import AttachFile from "./icons/attach_file.svg";
import Authenticate from "./icons/authenticate.svg";
import AutoRenew from "./icons/autorenew.svg";
import Battery1Bar from "./icons/battery_1_bar.svg";
import Bluetooth from "./icons/bluetooth.svg";
import Bookmark from "./icons/bookmark.svg";
import BrandAwareness from "./icons/brand_awareness.svg";
import Bureau from "./icons/Bureau.svg";
import Cached from "./icons/cached.svg";
import Calculate from "./icons/calculate.svg";
import CalenderMonth from "./icons/calendar_month.svg";
import CalenderToday from "./icons/calendar_today.svg";
import Call from "./icons/call.svg";
import Campaign from "./icons/campaign.svg";
import Cancel1 from "./icons/cancel-1.svg";
import Cancel from "./icons/cancel.svg";
import Cancellation from "./icons/Cancellation.svg";
import Category from "./icons/Category.svg";
import Chat from "./icons/chat.svg";
import CheckCircleFilled from "./icons/check_circle filled.svg";
import CheckCircle from "./icons/check_circle.svg";
import CheckSmall from "./icons/check_small.svg";
import Check from "./icons/check.svg";
import CheckList from "./icons/checklist.svg";
import ChevronLeft from "./icons/chevron_left.svg";
import ChevronRight from "./icons/chevron_right.svg";
import Circle from "./icons/Circle.svg";
import Close from "./icons/close.svg";
import Cloud from "./icons/close.svg";
import Comment1 from "./icons/comment-1.svg";
import Comment from "./icons/comment.svg";
import CommercialVehicle from "./icons/Commercial vehicle.svg";
import Communication from "./icons/Communication.svg";
import ContactEmergency from "./icons/contact_emergency.svg";
import ContactPage from "./icons/contact_page.svg";
import ContentCopy from "./icons/content_copy.svg";
import ContentPaste from "./icons/contact_page.svg";
import Content from "./icons/Content.svg";
import CopyAll from "./icons/copy_all.svg";
import CopyRight from "./icons/copyright.svg";
import CreditCard from "./icons/credit_card.svg";
import CropRotate from "./icons/crop_rotate.svg";
import Crop from "./icons/crop.svg";
import CurrencyRupee from "./icons/currency_rupee.svg";
import CurrentAddress from "./icons/current address.svg";
import DarkMode from "./icons/dark_mode.svg";
import Database from "./icons/database.svg";
import Dataset from "./icons/dataset.svg";
import DateRange from "./icons/date_range.svg";
import Delete from "./icons/delete.svg";
import Divider1 from "./icons/Divider-1.svg";
import Divider2 from "./icons/Divider-2.svg";
import Divider3 from "./icons/Divider-3.svg";
import Divider4 from "./icons/Divider-4.svg";
import Divider5 from "./icons/Divider-5.svg";
import Divider from "./icons/Divider.svg";
import Document from "./icons/Document.svg";
import DoneAll from "./icons/done_all.svg";
import Download from "./icons/download.svg";
import Drafts from "./icons/drafts.svg";
import EditCalendar from "./icons/edit_calendar.svg";
import Edit from "./icons/edit.svg";
import Error1 from "./icons/error-1.svg";
import Error from "./icons/error.svg";
import ExpandLess from "./icons/expand_less.svg";
import ExpandMore from "./icons/expand_more.svg";
import EyeTracking from "./icons/eye_tracking.svg";
import Favorite from "./icons/favorite.svg";
import Feedback1 from "./icons/feedback-1.svg";
import Feedback from "./icons/feedback.svg";
import FileCopy from "./icons/file_copy.svg";
import FileDownloadDone from "./icons/file_download_done.svg";
import FileSave from "./icons/file_save.svg";
import File from "./icons/File.svg";
import Filled from "./icons/Filled.svg";
import FilterAlt from "./icons/filter_alt.svg";
import FilterList from "./icons/filter_list.svg";
import FingerPrint from "./icons/fingerprint.svg";
import FirstPage from "./icons/first_page.svg";
import FixedDeposit from "./icons/Fixed deposit.svg";
import Flags from "./icons/flags.svg";
import FlashOff from "./icons/flash_off.svg";
import FlashLightOn from "./icons/flashlight_on.svg";
import FlipCameraAndroid from "./icons/flip_camera_android.svg";
import ForeClosure from "./icons/Foreclosure.svg";
import FullScreen from "./icons/fullscreen.svg";
import FullScreenExit from "./icons/fullscreen_exit.svg";
import Gif from "./icons/gif.svg";
import GridView from "./icons/grid_view.svg";
import HealthInsurance from "./icons/Health  insurance.svg";
import Help from "./icons/help.svg";
import HomeLoan from "./icons/Home loan.svg";
import Home from "./icons/home.svg";
import HourGlass from "./icons/hourglass.svg";
import IdCard from "./icons/id_card.svg";
import Image from "./icons/image.svg";
import Info from "./icons/info.svg";
import Keep from "./icons/keep.svg";
import KeySecurity from "./icons/Key Security.svg";
import KeyVertical from "./icons/key_vertical.svg";
import LastPage from "./icons/last_page.svg";
import LifeInsurance from "./icons/Life insurance.svg";
import Link from "./icons/link.svg";
import List from "./icons/list.svg";
import LiveHelp from "./icons/live_help.svg";
import LoanDetails from "./icons/Loan details.svg";
import Location from "./icons/location.svg";
import Lock from "./icons/lock.svg";
import Logout from "./icons/logout.svg";
import Mail from "./icons/mail.svg";
import Menu from "./icons/menu.svg";
import Mic from "./icons/mic.svg";
import Mobile from "./icons/mobile.svg";
import MoreHorizontal from "./icons/more_horiz.svg";
import MoreVertical from "./icons/more_vert.svg";
import MotorInsurance from "./icons/Motor insurance.svg";
import MutualFunds from "./icons/Mutual funds.svg";
import Navigation from "./icons/Navigation.svg";
import NewCar from "./icons/New car.svg";
import NewReleases1 from "./icons/new_releases-1.svg";
import NewReleases from "./icons/new_releases.svg";
import Noc from "./icons/NOC.svg";
import NorthEast from "./icons/north_east.svg";
import NorthWest from "./icons/north_west.svg";
import NotificationActive from "./icons/notifications_active.svg";
import NotificationUnread from "./icons/notifications_unread.svg";
import Notification from "./icons/notifications.svg";
import Offers from "./icons/Offer.svg";
import PaymentNotUpdated from "./icons/Payment not updated.svg";
import Others from "./icons/Others.svg";
import Payments from "./icons/payments.svg";
import PersonAdd from "./icons/person_add.svg";
import Person from "./icons/person.svg";
import PersonalLoan from "./icons/Personal loan.svg";
import PhotoCamera from "./icons/photo_camera.svg";
import PictureAsPdf from "./icons/picture_as_pdf.svg";
import Print from "./icons/print.svg";
import QrCode from "./icons/qr_code.svg";
import QuickReference from "./icons/quick_reference.svg";
import ReDo from "./icons/redo.svg";
import Refresh from "./icons/refresh.svg";
import ReFund from "./icons/refund.svg";
import RememberMe from "./icons/remember_me.svg";
import Remove from "./icons/remove.svg";
import Report from "./icons/report.svg";
import Review from "./icons/review.svg";
import RightReturnArrow from "./icons/review.svg";
import Savings from "./icons/review.svg";
import Schedule1 from "./icons/review.svg";
import Schedule from "./icons/review.svg";
import Search from "./icons/search.svg";
import Send from "./icons/review.svg";
import SentimentSatisfied from "./icons/review.svg";
import Services from "./icons/Services.svg";
import Settings from "./icons/settings.svg";
import Share from "./icons/share.svg";
import ShieldLock from "./icons/review.svg";
import SimCard from "./icons/review.svg";
import Sort from "./icons/review.svg";
import Sunny from "./icons/review.svg";
import SupportAgent from "./icons/review.svg";
import SwitchLeft from "./icons/review.svg";
import SwitchRight from "./icons/review.svg";
import ThreeWheeler from "./icons/review.svg";
import ThumbDown from "./icons/review.svg";
import ThumbUp from "./icons/review.svg";
import Tracking from "./icons/review.svg";
import Tractor from "./icons/review.svg";
import Undo from "./icons/review.svg";
import UnfoldLess from "./icons/review.svg";
import UnfoldMore from "./icons/review.svg";
import UpdateMobileNo from "./icons/update mobile no.svg";
import Upgrade from "./icons/review.svg";
import UploadFile from "./icons/review.svg";
import Upload from "./icons/review.svg";
import UsedCar from "./icons/review.svg";
import UtilityVehicle from "./icons/review.svg";
import Translate from "./icons/translate.svg";
import VerifiedUser from "./icons/verified_user.svg";
import VisibilityLock from "./icons/visibility_lock.svg";
import VisibilityOff from "./icons/visibility_off.svg";
import Visibility from "./icons/visibility.svg";
import VolumeOff from "./icons/volume_off.svg";
import VolunteerActivism from "./icons/volunteer_activism.svg";
import Warning1 from "./icons/warning-1.svg";
import Warning from "./icons/warning.svg";
import Widgets from "./icons/widgets.svg";
import WifiAccess from "./icons/Wifi  access.svg";
import Wifi from "./icons/wifi.svg";
import ZoomIn from "./icons/zoom_in.svg";
import ZoomOut from "./icons/zoom_out.svg";
import happyFace from "./icons/happyFace.svg";
import InputText from "./icons/input-text.svg";
import CloseModal from "./icons/Close_Modal.svg";
import Unhappy from "./icons/sentiment_dissatisfied.svg";
import UnhappyRed from "./icons/sentiment_dissatisfiedRed.svg";
import Okay from "./icons/sentiment_neutral.svg";
import OkayRed from "./icons/sentiment_satisfiedRed.svg";
import Happy from "./icons/mood.svg";
import HappyRed from "./icons/moodRed.svg";
import play_circle from "./icons/play_circle.svg";
import Reminder from "./icons/reminder.svg";
import Switch from "./icons/switch.svg";
import Light from "./icons/Light.svg";
import FloatingIcon from "./icons/floating-icon.svg";
import MobileRed from "./icons/mobile-red.svg";
import MyLocationIcon from "./icons/my_location.svg";
import PersonPlay from "./icons/person_play.svg";
import HomePin from "./icons/home_pin.svg";
import ServiceIcon from "./icons/ServiceIcon.svg";
import FeaturesIcon from "./icons/feature_icon.svg";

const iconConfig = {
  AccountBalanceWallet,
  AccountBalance,
  AccountCircle,
  AddAccount,
  AddCard,
  Add,
  AirplaneModeActive,
  Alert,
  ApprovalDelegation,
  Apps,
  ArrowBack,
  ArrowDownwardAlt,
  ArrowLeftAlt,
  ArrowRightAlt,
  ArrowUpwardAlt,
  Assignment,
  AttachEmail1,
  AttachEmail,
  AttachFile,
  Authenticate,
  AutoRenew,
  Battery1Bar,
  Bluetooth,
  Bookmark,
  BrandAwareness,
  Bureau,
  Cached,
  Calculate,
  CalenderMonth,
  CalenderToday,
  Call,
  Campaign,
  Cancel1,
  Cancel,
  Cancellation,
  Category,
  Chat,
  CheckCircleFilled,
  CheckCircle,
  CheckSmall,
  Check,
  CheckList,
  ChevronLeft,
  ChevronRight,
  Circle,
  Close,
  Cloud,
  Comment1,
  Comment,
  CommercialVehicle,
  Communication,
  ContactEmergency,
  ContactPage,
  ContentCopy,
  ContentPaste,
  Content,
  CopyAll,
  CopyRight,
  CreditCard,
  CropRotate,
  Crop,
  CurrencyRupee,
  CurrentAddress,
  DarkMode,
  Database,
  Dataset,
  DateRange,
  Delete,
  Divider1,
  Divider2,
  Divider3,
  Divider4,
  Divider5,
  Divider,
  Document,
  DoneAll,
  Download,
  Drafts,
  EditCalendar,
  Edit,
  Error1,
  Error,
  ExpandLess,
  ExpandMore,
  EyeTracking,
  Favorite,
  Feedback1,
  Feedback,
  FileCopy,
  FileDownloadDone,
  FileSave,
  File,
  Filled,
  FilterAlt,
  FilterList,
  FingerPrint,
  FirstPage,
  FixedDeposit,
  Flags,
  FlashOff,
  FlashLightOn,
  FlipCameraAndroid,
  FloatingIcon,
  ForeClosure,
  FullScreen,
  FullScreenExit,
  Gif,
  GridView,
  HealthInsurance,
  Help,
  HomeLoan,
  Home,
  HourGlass,
  IdCard,
  Image,
  Info,
  Keep,
  KeySecurity,
  KeyVertical,
  LastPage,
  LifeInsurance,
  Light,
  Link,
  List,
  LiveHelp,
  LoanDetails,
  Location,
  Lock,
  Logout,
  Mail,
  Menu,
  Mic,
  Mobile,
  MoreHorizontal,
  MoreVertical,
  MotorInsurance,
  MutualFunds,
  Navigation,
  NewCar,
  NewReleases1,
  NewReleases,
  Noc,
  NorthEast,
  NorthWest,
  NotificationActive,
  NotificationUnread,
  Notification,
  Offers,
  Others,
  PaymentNotUpdated,
  Payments,
  PersonAdd,
  Person,
  PersonalLoan,
  PhotoCamera,
  PictureAsPdf,
  Print,
  QrCode,
  QuickReference,
  ReDo,
  Refresh,
  ReFund,
  RememberMe,
  Remove,
  Report,
  Review,
  RightReturnArrow,
  Savings,
  Schedule1,
  Schedule,
  Search,
  Send,
  SentimentSatisfied,
  Services,
  Settings,
  Share,
  ShieldLock,
  SimCard,
  Sort,
  Sunny,
  SupportAgent,
  SwitchLeft,
  SwitchRight,
  ThreeWheeler,
  ThumbDown,
  ThumbUp,
  Tracking,
  Tractor,
  Translate,
  Undo,
  UnfoldLess,
  UnfoldMore,
  UpdateMobileNo,
  Upgrade,
  UploadFile,
  Upload,
  UsedCar,
  UtilityVehicle,
  VerifiedUser,
  VisibilityLock,
  VisibilityOff,
  Visibility,
  VolumeOff,
  VolunteerActivism,
  Warning1,
  Warning,
  Widgets,
  WifiAccess,
  Wifi,
  ZoomIn,
  ZoomOut,
  happyFace,
  InputText,
  CloseModal,
  Unhappy,
  UnhappyRed,
  Okay,
  OkayRed,
  Happy,
  HappyRed,
  play_circle,
  Reminder,
  Switch,
  MobileRed,
  MyLocationIcon,
  PersonPlay,
  HomePin,
  ServiceIcon,
  FeaturesIcon,
};

export default iconConfig;
