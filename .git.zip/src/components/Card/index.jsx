import PropTypes from "prop-types";

const Card = ({ children, className, ...rest }) => {
  return (
    <div className={`bg-white rounded-lg   ${className}`} {...rest}>
      {children}
    </div>
  );
};

Card.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
};

export default Card;
