import { Formik, Form } from "formik";
import * as Yup from "yup";
import { Input, Button, Alert, CheckBox } from "../../components";
import { useState, useEffect } from "react";
import { Container } from "../../components";
import {
  validation,
  termsAndConditionsValidation,
} from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";
import { REGISTRATION } from "../../const/common";

const EnterMoreDetails = () => {
  const [wrongAttempts, setWrongAttempts] = useState(0);
  const [alertError, setAlertError] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const initialValues = {
    panDetails: "",
    name: "",
    dob: "",
    termsAndCondition: false,
  };
  const [date, setDate] = useState("");
  const validationSchema_pan = Yup.object({
    panDetails: validation("Enter Pan")
      .min(10, "Pan number should be 10 digits")
      .max(10, "Incorrect Pan number"),
    name: Yup.string()
      .required("Name is required")
      .test("no-numbers", "Name cannot contain numbers", (value) =>
        /^[^\d]+$/g.test(value),
      ),
    dob: validation("Date of birth is required"),
    termsAndCondition: termsAndConditionsValidation("Accept Terms"),
  });

  const onSubmit = (values, { setFieldError }) => {
    if (values.panDetails === "ABCDE1234F") {
      ("");
    } else {
      setWrongAttempts((prevAttempts) => prevAttempts + 1);
      if (wrongAttempts >= 2) {
        setAlertError(true);
      } else {
        setFieldError(
          "panDetails",
          `Sorry you have entered invalid PAN number. ${
            3 - wrongAttempts
          } attempts remaining.`,
        );
      }
    }
  };

  useEffect(() => {
    const today = new Date();
    const maxDate = today.toISOString().split("T")[0];
    setDate(maxDate);
  }, []);

  return (
    <Container>
      <div className="relative w-full max-w-md mx-auto flex flex-col p-4">
        <div className="mt-5 mb-[36px]">
          <div className="flex items-center lg:block">
            <BackButton />
            <p className="mb-0 lg:mb-2 lg:pt-2 headline headline_xl text-red-800">
              {REGISTRATION.ENTER_DETAILS}
            </p>
          </div>
          <p className="mb-2 text-grey-500 content content_lg">
            {REGISTRATION.UNABLE_TO_AUTHENTICATE}
          </p>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema_pan}
            onSubmit={onSubmit}
          >
            {(formik) => (
              <Form className="flex flex-col">
                <div className="">
                  <div className="mb-[16px]">
                    <Input
                      name="panDetails"
                      label={REGISTRATION.PAN}
                      formik={formik}
                      className=" w-full text-grey-500 focus:border-red-600 label label_md mt-2"
                      disabled={alertError}
                    />
                    <p className="text-grey-500 content content_md pt-1">
                      {REGISTRATION.EG}
                    </p>
                  </div>
                  <div className="mb-4">
                    <Input
                      name="name"
                      label={REGISTRATION.NAME_AS_PER_PAN}
                      formik={formik}
                      className=" text-grey-500 mb-2 focus:border-red-600 label label_md"
                      disabled={alertError}
                    />
                  </div>
                  <div className="mb-3">
                    <Input
                      name="dob"
                      type="date"
                      label={REGISTRATION.DATE_AS_PER_PAN}
                      formik={formik}
                      max={date}
                      className=" text-grey-500 mb-2 focus:border-red-600 label label_md"
                      disabled={alertError}
                    />
                  </div>
                  <CheckBox
                    checked={termsAccepted}
                    onChange={() => {
                      const newTermsAccepted = !termsAccepted;
                      setTermsAccepted(newTermsAccepted);
                      formik.setFieldValue(
                        "termsAndCondition",
                        newTermsAccepted,
                      );
                    }}
                    label={REGISTRATION.I_Agree}
                    name="termsAndCondition"
                    className="text-xs text-grey-500 font-karla font-normal"
                  />
                </div>
                <Button
                  type="submit"
                  name="Verify"
                  disabled={
                    !(formik.isValid && formik.dirty) ||
                    alertError ||
                    !formik.values.dob ||
                    !formik.values.name ||
                    !formik.values.panDetails ||
                    !formik.values.termsAndCondition
                  }
                  className=" font-bold text-white w-full mt-[40px] h-[42px] rounded-md bg-red-500 disabled:bg-disable-red disabled:text-red-200 dark:disabled:bg-grey-900 dark:disabled:text-grey-100"
                />
                {alertError && (
                  <Alert errorMessage="We are unable to authenticate you as a customer, please visit a nearby branch for a resolution" />
                )}
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </Container>
  );
};
export default EnterMoreDetails;
