import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import FaqAccordion from "../../components/Accordion/FaqAccordion";
import { Breadcrumb, MainContainer } from "../../components";
import BackButton from "../../components/Common/BackButton";
import { capitalizeTitle } from "../../utils/utils";
import { findMatchingTypes } from "./findMatchingTypeshelper";
import Sidebar from "../../components/OfferSidebar";
import NoData from "../../components/Common/NoData";
import HowtoFaqViewMore from "./HowtoFaqViewMore";
import { compareStr } from "../../utils/commonUtils";
import { FAQ_TYPE, FAQ_TYPE_URL } from "../../const/ProductConst";

const AppFaq = () => {
  const { title, loanType } = useParams();
  const capitalizedTitle = capitalizeTitle(title);
  const [isSticky, setIsSticky] = useState(false);
  const { AppFaqs } = useSelector((state) => state.AppFaqs);

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  if (!AppFaqs) {
    return <NoData errorText="FAQ not Found" />;
  }

  const howToFaqData = AppFaqs.filter((item) => item.faq_type === FAQ_TYPE)
    .flatMap((item) => item.video_types)
    .filter((item) => compareStr(item.header, title));

  const matchingTypes = findMatchingTypes(AppFaqs, capitalizedTitle);
  return (
    <MainContainer className={`flex flex-col lg:p-4 p-0`}>
      <div
        className={`sticky top-[64px] sm:top-[63px] right-0 z-10 ${
          isSticky ? "bg-white" : ""
        } w-full dark:bg-black-200`}
      >
        <Breadcrumb />
        <div className="pt-3 capitalize font-semibold flex items-center text-[22px] lg:text-[28px] dark:text-white">
          <BackButton />
          {capitalizedTitle}
        </div>
      </div>

      <div
        className={`lg:w-[100%] sticky top-[145px] lg:top-[150px] z-10 ${
          isSticky ? "bg-white" : ""
        } overflow-x-auto dark:bg-black-200 w-full`}
      ></div>
      <div className="flex flex-wrap lg:flex-nowrap">
        {loanType === FAQ_TYPE_URL ? (
          <HowtoFaqViewMore howToFaqData={howToFaqData} />
        ) : (
          <div className="w-full pt-2 lg:pt-4">
            <div className="flex flex-wrap lg:flex-nowrap">
              <div className="w-full">
                {!matchingTypes || matchingTypes.length === 0
                  ? "No matching types found"
                  : matchingTypes.map((type, index) => (
                      <section key={index}>
                        <h4 className="subtitle">{type.header}</h4>
                        <div className="bg-white rounded p-2 pb-0 lg:p-4">
                          <FaqAccordion items={type.faq} />
                        </div>
                      </section>
                    ))}
              </div>
            </div>
          </div>
        )}
        <Sidebar showPreApproved={false} customClasses="lg:mt-4" />
      </div>
    </MainContainer>
  );
};

export default AppFaq;
