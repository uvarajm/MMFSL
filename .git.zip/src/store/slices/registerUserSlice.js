import { createSlice } from "@reduxjs/toolkit";
import { REGISTERED_USER } from "../actions/actions";

const initialState = {
  registeredUserData: {},
  loading: false,
  error: null,
};

const registerUserSlice = createSlice({
  name: REGISTERED_USER,
  initialState,
  reducers: {
    fetchRegisteredStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchRegisteredDataSuccess(state, action) {
      state.loading = false;
      state.registeredUserData = action.payload;
    },
    fetchRegisteredDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchRegisteredStatusData,
  fetchRegisteredDataSuccess,
  fetchRegisteredDataFailure,
} = registerUserSlice.actions;

export default registerUserSlice.reducer;
