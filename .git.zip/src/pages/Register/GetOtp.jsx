import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Button, Container } from "../../components";
import { getOtpSuccessAction } from "./registerSlice";
import { numberReg } from "../../utils";
import BackButton from "../../components/Common/BackButton";
import { REGISTER_USER, VALIDATE_OTP } from "../../store/actions/actions";
import { numberMask } from "../../utils";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import iconConfig from "../../assets/iconsConfig";

const GetOtp = () => {
  const navigate = useNavigate();
  const inputRefs = useRef([]);
  const dispatch = useDispatch();
  const { mobileNumber, tncFlag } = useSelector((state) => state.register);
  const { otpValidateData, loading, error } = useSelector(
    (state) => state.validateOtp,
  );
  const [timer, setTimer] = useState(180);
  const [clickCount, setClickCount] = useState(0);
  const [showResend, setShowResend] = useState(false);
  const [showGetOtpOverCall, setShowGetOtpOverCall] = useState(false);
  const [wrongAttempts, setWrongAttempts] = useState(0);
  const mobileData = null;
  const [alertError, setAlertError] = useState(false);
  const [retryError, setRetryError] = useState(false);
  const [retryErrorMsg, setRetryErrorMsg] = useState(false);
  const register = useSelector((state) => state.register);
  const [otpInputs, setOtpInputs] = useState(["", "", "", "", "", ""]);
  const [maskedOtpInputs, setMaskedOtpInputs] = useState([
    "",
    "",
    "",
    "",
    "",
    "",
  ]);
  const [errors, setErrors] = useState(Array(6).fill(""));
  const [allFieldsFilled, setAllFieldsFilled] = useState(false);

  const dataSend = {
    mobileNumber: mobileNumber,
    otpResend: false,
    otp: otpInputs.join(""),
    deviceId: "123.23.24",
    tncFlag: 2,
    source: "web",
    journey: "REGISTRATION",
  };

  const handleInputChange = (index, value) => {
    const isNumber = numberReg(value);
    const newInputs = [...otpInputs];
    const newMaskedInputs = [...maskedOtpInputs];

    if (isNumber || value === "") {
      newInputs[index] = value;
      newMaskedInputs[index] = value ? "*" : "";
      setOtpInputs(newInputs);
      setMaskedOtpInputs(newMaskedInputs);
      validateInput(index, value);

      if (value && index < inputRefs.current.length - 1) {
        inputRefs.current[index + 1].focus();
      } else if (value === "") {
        const focusIndex = index ? index - 1 : index;
        inputRefs.current[focusIndex].focus();
      }
    }
    const allFilled = newInputs.every((input) => input !== "");
    setAllFieldsFilled(allFilled);
  };

  const validateInput = (index, value) => {
    const isNumber = numberReg(value);
    const newErrors = [...errors];
    newErrors[index] = isNumber ? "" : "Please enter a number";
    setErrors(newErrors);
  };

  const handleClearInputs = () => {
    const newInputs = Array(6).fill("");
    setOtpInputs(newInputs);
    setMaskedOtpInputs(newInputs);
    setErrors(newInputs);

    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  };

  useEffect(() => {
    let intervalId;

    if (timer > 0 && !showResend) {
      intervalId = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    } else if (timer === 0 && !showResend) {
      setShowResend(true);
    }

    return () => {
      clearInterval(intervalId);
    };
  }, [timer, showResend]);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
  };

  const handleResendClick = () => {
    const data = {
      mobileNumber: mobileNumber,
      otpResend: false,
      source: "web",
      journey: "REGISTRATION",
      tncFlag: tncFlag,
    };

    setTimer(120);
    setShowResend(false);
    setClickCount((prevClickCount) => prevClickCount + 1);
    setRetryError(false);

    dispatch({ type: REGISTER_USER, payload: data });
  };

  const handleGetOtpOverCall = () => {
    setShowGetOtpOverCall(true);
    if (clickCount >= 2) setShowResend(false);
  };

  const handleSubmit = () => {
    if (register.forgot) {
      // [TODO][YG] need to use it later
      // eslint-disable-next-line no-undef
      const mob = mobileData.find((mob) => mob.otp === otpValues);
      if (mob) {
        setRetryError(false);
        dispatch(getOtpSuccessAction(mob));
        mob.isRegistered
          ? navigate("/reset-password")
          : mob.isCustomer
            ? navigate("/register/get-more-details")
            : "";
      } else {
        setWrongAttempts((prevAttempts) => prevAttempts + 1);

        if (wrongAttempts >= 2) {
          handleClearInputs();
          setRetryError(false);
          setAlertError(true);
        } else {
          setRetryError(true);
          setRetryErrorMsg(
            `OTP does not match. Please enter a valid OTP.${
              wrongAttempts == 0 ? wrongAttempts + 2 : wrongAttempts
            } attempts remaining.`,
          );
          handleClearInputs();
        }
      }
    } else {
      if (dataSend.mobileNumber) {
        setRetryError(false);
        dispatch({ type: VALIDATE_OTP, payload: dataSend });
      } else {
        setWrongAttempts((prevAttempts) => prevAttempts + 1);

        if (wrongAttempts >= 2) {
          handleClearInputs();
          setRetryError(false);
          setAlertError(true);
        } else {
          setRetryError(true);
          setRetryErrorMsg(
            `OTP does not match. Please enter a valid OTP. ${
              wrongAttempts == 0 ? wrongAttempts + 2 : wrongAttempts
            } attempts remaining.`,
          );
          handleClearInputs();
        }
      }
    }
  };

  useEffect(() => {
    if (otpValidateData && otpValidateData?.code === "SUCCESS") {
      navigate("/register/get-register-details");
    }
  }, [navigate, otpValidateData]);

  return (
    <Container className="px-4">
      <HandleDataRendering
        data={otpValidateData}
        loading={loading}
        error={error}
      >
        <div className="w-[400px] minHeight flex justify-center p-1 font-quicksand items-center">
          <div className="w-full flex flex-col flex-1 justify-between">
            <div className="flex items-center lg:block pb-4">
              <BackButton />
              <p className=" text-red-800 lg:leading-10 leading-6 lg:pt-4 headline headline_md lg:mt-0">
                Enter OTP
              </p>
            </div>
            <p className="leading-4 tracking-wider label label_md text-red-800">
              Enter the 6 digit OTP sent to +91-{numberMask(mobileNumber)}
            </p>
            <div className="flex-1 h-full mt-4">
              <div className="">
                <div className="flex space-x-2">
                  {otpInputs.map((value, index) => (
                    <div
                      key={index}
                      className="relative w-[48px] h-[44px] lg:w-[56px] lg:h-[44px] flex items-center justify-center"
                    >
                      <input
                        className="w-full h-full text-center border-b-2 bg-transparent border-b-disable-red focus:outline-none focus:border-red-500"
                        type="number"
                        maxLength="1"
                        disabled={alertError}
                        value={value}
                        onChange={(e) =>
                          handleInputChange(index, e.target.value)
                        }
                        ref={(el) => (inputRefs.current[index] = el)}
                        style={{ color: "transparent" }}
                      />
                      {maskedOtpInputs[index] && (
                        <img
                          src={iconConfig.InputText}
                          alt="star"
                          className="absolute w-[8px] h-[8px]"
                          style={{ margin: "auto" }}
                        />
                      )}
                    </div>
                  ))}
                </div>
                {retryError && (
                  <p className="timer-cls text-red-600 font-karla text-xs font-normal pt-1">
                    {retryErrorMsg}
                  </p>
                )}
                {!showResend && !alertError && (
                  <p
                    name="time"
                    className="timer-cls text-grey-500 font-karla font-normal text-xs pt-1"
                  >
                    {formatTime(timer)}
                  </p>
                )}
                {showResend && (
                  <div className="timer-cls flex flex-row justify-between pt-1">
                    <div className=" text-grey-500 content content_md">
                      <span>Did not receive OTP? </span>
                    </div>
                    <div className="text-red-500">
                      <button
                        onClick={handleResendClick}
                        className="text-red-500 content content_md"
                        disabled={alertError}
                      >
                        Resend OTP
                      </button>
                    </div>
                  </div>
                )}
                {clickCount >= 2 && !showGetOtpOverCall && (
                  <div className="timer-cls flex justify-between">
                    <span>Still facing issues? </span>
                    <button
                      onClick={handleGetOtpOverCall}
                      className="underline"
                      disabled={alertError}
                    >
                      Get OTP over call
                    </button>
                  </div>
                )}

                {otpValidateData?.code === "FAILURE" && (
                  <div className="bg-white p-2 rounded-lg text-XS mt-[40px] font-karla font-normal leading-[18px] text-grey-500">
                    {otpValidateData?.message}
                  </div>
                )}
              </div>
              <div
                className={`${
                  otpValidateData?.code === "FAILURE"
                    ? "lg:mt-0 mt-32"
                    : "lg:mt-0 mt-48"
                }`}
              >
                <Button
                  type="submit"
                  name="Verify"
                  disabled={!allFieldsFilled || alertError}
                  onClick={handleSubmit}
                  className={`verify-btn mt-[14px] rounded-lg ${
                    allFieldsFilled
                      ? "bg-red-500 text-white"
                      : "bg-disable-red text-lilac-dark dark:disabled:bg-grey-900 dark:disabled:text-grey-100"
                  }`}
                />
              </div>
            </div>
            {showGetOtpOverCall && (
              <p>Option to get OTP over call is available now.</p>
            )}
            <Link
              to={"/register"}
              className="try-diff-btn mt-4 text-center dark:!text-red-700 dark:!border-red-700"
            >
              Try a different phone number
            </Link>
          </div>
        </div>
      </HandleDataRendering>
    </Container>
  );
};
export default GetOtp;
