import { takeLatest, call, put } from "redux-saga/effects";
import {
  fetchCreatePasswordStatusData,
  fetchCreatePasswordDataSuccess,
  fetchCreatePasswordDataFailure,
} from "../slices/createPasswordSlice";
import { CREATE_PASSWORD } from "../actions/actions";
import { endpoints } from "../../utils/apiUtils";
function* fetchCreatePasswordStatus(data) {
  try {
    const { payload } = data;
    const { token, ...restPayload } = payload;
    yield put(fetchCreatePasswordStatusData());
    const config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const response = yield call(
      endpoints.validateOtp,
      "POST",
      restPayload,
      config,
    );
    yield put(fetchCreatePasswordDataSuccess(response?.data));
  } catch (error) {
    yield put(fetchCreatePasswordDataFailure(error.message));
  }
}
export function* watchFetchCreatePasswordStatus() {
  yield takeLatest(CREATE_PASSWORD, fetchCreatePasswordStatus);
}
