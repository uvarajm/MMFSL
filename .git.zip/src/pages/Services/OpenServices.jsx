import PropTypes from "prop-types";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import CardDetailsList from "../../components/Common/CardDetailsList";
const OpenServices = ({
  openServiceData = [],
  loading,
  error,
  handleRedirection,
}) => {
  return (
    <HandleDataRendering data={openServiceData} loading={loading} error={error}>
      {openServiceData.length > 0 &&
        openServiceData?.map((openItem) => {
          return (
            <CardDetailsList
              details={openItem}
              key={openItem.caseNumber}
              handleRedirection={handleRedirection}
            />
          );
        })}
    </HandleDataRendering>
  );
};

export default OpenServices;

OpenServices.propTypes = {
  openServiceData: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  error: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  loading: PropTypes.bool,
  handleRedirection: PropTypes.func,
};
