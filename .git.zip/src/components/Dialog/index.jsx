import PropTypes from "prop-types";
import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";

export default function AlertDialog(props) {
  // const [open, setOpen] = React.useState(false);
  const { header, content, optionOne, optionTwo, open, setOpen } = props;

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <React.Fragment>
      {/* <Button variant="outlined" onClick={handleClickOpen}>
        Open alert dialog
      </Button> */}
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        sx={{ borderRadius: "0px" }}
      >
        <DialogTitle id="alert-dialog-title">{header}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {content}
          </DialogContentText>
        </DialogContent>
        <DialogActions
          sx={{
            display: "flex",
            width: "100%",
            justifyContent: "space-between",
          }}
        >
          <Button
            onClick={handleClose}
            sx={{ backgroundColor: "", width: "100%" }}
          >
            {optionOne}
          </Button>
          <Button
            onClick={handleClose}
            autoFocus
            sx={{ backgroundColor: "", width: "100%" }}
          >
            {optionTwo}
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}

AlertDialog.propTypes = {
  header: PropTypes.string,
  content: PropTypes.string,
  optionOne: PropTypes.string,
  optionTwo: PropTypes.string,
  open: PropTypes.bool,
  setOpen: PropTypes.func,
};
