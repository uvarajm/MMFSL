import PropTypes from "prop-types";
import { useState } from "react";

const TableComp = ({ data, columns, onRowClick }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortedField, setSortedField] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSort = (field) => {
    if (field === sortedField) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortedField(field);
      setSortOrder("asc");
    }
  };

  const sortedData = sortedField
    ? data.sort((a, b) => {
        if (sortOrder === "asc") {
          return a[sortedField] > b[sortedField] ? 1 : -1;
        } else {
          return a[sortedField] < b[sortedField] ? 1 : -1;
        }
      })
    : data;

  const filteredData = sortedData.filter((item) =>
    Object.values(item).some((value) =>
      value.toString().toLowerCase().includes(searchTerm.toLowerCase()),
    ),
  );

  return (
    <div>
      <input
        type="text"
        placeholder="Search..."
        value={searchTerm}
        onChange={handleSearch}
      />
      <table>
        <thead>
          <tr>
            {columns.map((column, index) => (
              <th key={index} onClick={() => handleSort(column.field)}>
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filteredData.map((item, rowIndex) => (
            <tr key={rowIndex} onClick={() => onRowClick(item)}>
              {columns.map((column, colIndex) => (
                <td key={colIndex}>{item[column.field]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

TableComp.propTypes = {
  data: PropTypes.object,
  columns: PropTypes.array,
  onRowClick: PropTypes.func,
};

export default TableComp;
