import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Container from "../../components/Container";

function Success() {
  const [countdown, setCountdown] = useState(10);
  const navigate = useNavigate();

  useEffect(() => {
    const redirectTimeout = setTimeout(() => {
      navigate("/login");
    }, countdown * 1000);

    const interval = setInterval(() => {
      setCountdown((prevTimer) => prevTimer - 1);
    }, 1000);

    // Clean up timer interval
    return () => {
      clearTimeout(redirectTimeout);
      clearInterval(interval);
    };
  }, [navigate, countdown]);
  return (
    <Container>
      <div className="relative w-[560px] lg:h-[671px] flex flex-col gap-4 lg:border p-4">
        <div className="flex flex-col flex-1 gap-2 mt-14">
          <h1 className="text-3xl">
            You have successfully reset your password.
          </h1>
          <p>You will be redirected to login in {countdown} seconds.</p>
        </div>
      </div>
    </Container>
  );
}

export default Success;
