// saga.js
import { takeLatest, put, call } from "redux-saga/effects";
import { IN_PROGRESS_PRODUCTS } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import {
  fetchInProgressProductsStatusData,
  fetchInProgressProductsDataFailure,
  fetchInProgressProductsDataSuccess,
} from "../slices/inProgressProductSlice";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchInProgress(action) {
  try {
    yield put(fetchInProgressProductsStatusData());
    const response = yield call(
      makeApiRequest,
      endpoints.applicationStatusApi,
      BACKEND_TOKEN,
      "POST",
      {
        MobileNumber: action.payload,
      },
    );
    yield put(fetchInProgressProductsDataSuccess(response));
  } catch (error) {
    yield put(fetchInProgressProductsDataFailure(error.message));
  }
}

export function* watchFetchInProgressProducts() {
  yield takeLatest(IN_PROGRESS_PRODUCTS, fetchInProgress);
}
