import { Outlet, useLocation } from "react-router-dom";
import { useState } from "react";
import { useSelector } from "react-redux";
import { shouldShowSidebar } from "../../../utils/utils";
import Header from "../../Header";
import Sidebar from "../../Sidebar";
import Footer from "../../Footer";
import Floating from "../../Floating";
import Overlay from "../../Common/Overlay";
import { showSearchHandler } from "../../../utils/utils";

const RootLayout = () => {
  const location = useLocation();
  const showButton = shouldShowSidebar(location.pathname);
  const [showOverlay, setShowOverlays] = useState(false);
  const [showCallExecutive, setShowCallExecutive] = useState(false);

  const { loginStatus, theme } = useSelector((state) => ({
    loginStatus: state.login.loginStatus,
    theme: state.theme.theme,
  }));

  const handleLocateOpen = () => {
    setShowOverlays(!showOverlay);
    setShowCallExecutive(false);
  };
  const handleOutSideClose = () => {
    setShowOverlays(false);
  };

  return (
    <div
      className={`${
        theme === "dark" ? "dark" : ""
      } max-w-3xl min-h-screen mx-auto flex flex-col justify-between`}
    >
      <div className="">
        <Header />
        <section
          className={`flex relative bg-wrapper ${loginStatus && showSearchHandler(location.pathname) ? "mt-[108px] lg:mt-[64px]" : "mt-[64px]"}`}
        >
          {showButton && (
            <Sidebar className="fixed top-0 lg:top-[64px] bottom-[48px] left-auto" />
          )}

          {/* Floating Main Icons */}
          <Floating
            showOverlay={showOverlay}
            setShowOverlays={setShowOverlays}
            handleLocateOpen={handleLocateOpen}
            showCallExecutive={showCallExecutive}
            setShowCallExecutive={setShowCallExecutive}
          />

          <div className="w-full minHeight">
            <Outlet />
          </div>
        </section>
      </div>
      <Footer />
      <Overlay
        showOverlay={showOverlay}
        setShowOverlays={setShowOverlays}
        callBackEvent={handleOutSideClose}
        className="transition duration-200 ease-in-out"
      />
    </div>
  );
};

export default RootLayout;
