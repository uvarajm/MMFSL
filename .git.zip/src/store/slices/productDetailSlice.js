import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  productDetail: {},
};

const productDetailSlice = createSlice({
  name: "PRODUCT_DETAIL",
  initialState,
  reducers: {
    setProductDetails: (state, action) => {
      state.productDetail = action.payload;
    },
  },
});

export const { setProductDetails } = productDetailSlice.actions;

export default productDetailSlice.reducer;
