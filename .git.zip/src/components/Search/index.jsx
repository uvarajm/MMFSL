import { useEffect, useState } from "react";
import { useDebouncedCallback } from "use-debounce";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import Overlay from "../Common/Overlay";
import SearchInput from "./SearchInput";
import SearchLoader from "./SearchLoader";
import SearchResults from "./SearchResults";
import RecentSearches from "./RecentSearches";
import RecommendedSearches from "./RecommendedSearches";
import TYPE_AHEAD_MAPPING from "./type-ahead-mapping.json";
import NoData from "../Common/NoData";
import { endpoints, makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN, CMS_TOKEN } from "../../const/common";
import { compareStr } from "../../utils/commonUtils";
import "./search.scss";
import { useSelector } from "react-redux";

const Search = ({ parentClasses = "", childClasses = "" }) => {
  const [showSearch, setShowSearch] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [savedResults, setSavedResults] = useState([]);
  const [recommended, setRecommended] = useState([]);
  const [loading, setLoading] = useState(false);
  const [cmsSearchDone, isCMSSearchDone] = useState(false);
  const [prevQuery, setPrevQuery] = useState("");
  const { superAppId } = useSelector((state) => state.login);
  const { theme } = useSelector((state) => state.theme);

  const fetchSearchHistory = async () => {
    try {
      const response = await makeApiRequest(
        endpoints.getSearchHistory,
        BACKEND_TOKEN,
        "POST",
        { superAppId: superAppId },
      );
      if (response.code === "SUCCESS") {
        const mappedResults = response.data.searchKeys
          .slice(-5)
          .reverse()
          .map((key) => {
            const matchedItem = TYPE_AHEAD_MAPPING.find(
              (item) =>
                item.searchList.includes(key.toLowerCase()) ||
                item.searchList.some((searchTerm) =>
                  key.toLowerCase().includes(searchTerm.toLowerCase()),
                ),
            );

            return {
              title: key,
              url: matchedItem ? matchedItem.webRoutes : "/404",
            };
          });

        setSavedResults(mappedResults.reverse());
      }
    } catch (error) {
      console.error("Error fetching search result:", error);
    }
  };

  const fetchRecommendedSearch = async () => {
    try {
      const response = await makeApiRequest(
        endpoints.recommended_search,
        CMS_TOKEN,
        "GET",
      );
      if (response.status === "SUCCESS") {
        const updatedData = response.data.map((item) => {
          let matchedItem = TYPE_AHEAD_MAPPING.find((entry) =>
            entry.searchList.some((searchTerm) =>
              compareStr(searchTerm, item.title),
            ),
          );

          if (!matchedItem) {
            matchedItem = TYPE_AHEAD_MAPPING.find((entry) =>
              compareStr(entry.title, item.title),
            );
          }

          if (!matchedItem) {
            matchedItem = TYPE_AHEAD_MAPPING.find((entry) =>
              entry.searchList.some((searchTerm) => {
                const searchTerms = searchTerm.toLowerCase().split(" ");
                const itemTitleWords = item.title.toLowerCase().split(" ");
                const matchingWords = searchTerms.filter((term) =>
                  itemTitleWords.includes(term),
                );
                return matchingWords.length >= 2;
              }),
            );
          }

          if (!matchedItem) {
            matchedItem = TYPE_AHEAD_MAPPING.find((entry) => {
              const titleWords = entry.title.toLowerCase().split(" ");
              const itemTitleWords = item.title.toLowerCase().split(" ");
              const matchingWords = titleWords.filter((word) =>
                itemTitleWords.includes(word),
              );
              return matchingWords.length >= 2;
            });
          }
          if (matchedItem) {
            return { ...item, url: matchedItem.webRoutes };
          } else {
            return item;
          }
        });
        setRecommended(updatedData);
      }
    } catch (error) {
      console.error("Error fetching recommended search:", error);
    }
  };

  useEffect(() => {
    fetchSearchHistory();
    fetchRecommendedSearch();
  }, []);

  useEffect(() => {
    if (query.length === 0 && prevQuery.length > 0) {
      fetchSearchHistory();
    }
    setPrevQuery(query);
  }, [query, prevQuery]);
  const includesQuery = (str, query) =>
    str.toLowerCase().includes(query.toLowerCase());
  const sortResults = (results, query) => {
    const hasServiceMatch =
      results.Service &&
      results.Service.some((item) => includesQuery(item.title, query));
    const sortedResults = {};

    // Prioritize 'Service' category
    if (hasServiceMatch)
      if (results.Service) {
        sortedResults.Service = results.Service.sort((a, b) => {
          const aIncludes = includesQuery(a.title, query);
          const bIncludes = includesQuery(b.title, query);
          if (aIncludes && !bIncludes) return -1;
          if (!aIncludes && bIncludes) return 1;
          return 0;
        });
      }

    // Sort and add other categories
    for (const typeKey in results) {
      if (typeKey !== "Service") {
        sortedResults[typeKey] = results[typeKey].sort((a, b) => {
          const aIncludes = includesQuery(a.title, query);
          const bIncludes = includesQuery(b.title, query);
          if (aIncludes && !bIncludes) return -1;
          if (!aIncludes && bIncludes) return 1;
          return 0;
        });
      }
    }

    return sortedResults;
  };

  const handleSearch = useDebouncedCallback(() => {
    if (!query) {
      setResults({});
      setLoading(false);
      return;
    }

    const results = {};

    TYPE_AHEAD_MAPPING.forEach((item) => {
      item.searchList.forEach((keyword) => {
        if (includesQuery(keyword, query)) {
          const typeKey = item.category;

          if (!results[typeKey]) {
            results[typeKey] = [];
          }

          const existingResult = results[typeKey].find(
            (result) =>
              result.title === item.title && result.url === item.webRoutes,
          );

          if (!existingResult) {
            results[typeKey].push({
              title: item.title,
              url: item.webRoutes,
              type: item.type,
            });
          }
        }
      });
    });

    isCMSSearchDone(false);
    setResults(sortResults(results, query));
    setLoading(false);
  }, 300);

  const handleChange = (e) => {
    const newQuery = e.target.value;
    setQuery(newQuery);

    if (newQuery.length > 3) {
      setLoading(true);
      handleSearch();
    } else {
      setLoading(false);
      setResults({});
    }
  };

  const saveInSearchHistory = async (value) => {
    // Add the new query to the search history

    setSavedResults((prevResults) => {
      const newResults = [
        { title: value ? value.title : query, url: value ? value.url : "" },
        ...prevResults,
      ];
      return newResults;
    });

    const updatedResults = [
      { title: value ? value.title : query, url: value ? value.url : "" },
      ...savedResults,
    ];

    const uniqueResults = Array.from(
      new Set(updatedResults.map((item) => item.title)),
    ).map((title) => updatedResults.find((item) => item.title === title));

    const titles = uniqueResults
      .reverse()
      .slice(-5)
      .map((item) => item.title);

    try {
      await makeApiRequest(
        endpoints.getSearchHistoryDetails,
        BACKEND_TOKEN,
        "POST",
        {
          superAppId: superAppId,
          searchKeys: titles.reverse(),
        },
      );
    } catch (error) {
      console.log(error);
    }
  };

  const clearAndClose = (value) => {
    saveInSearchHistory(value);
    setShowSearch(false);
    setQuery("");
  };

  const removeDuplicateTitles = (obj) => {
    // Iterate through each key in the object
    Object.keys(obj).forEach((key) => {
      // Array to keep track of unique titles across all keys
      const allTitles = [];

      // Iterate through other keys to collect all titles
      Object.keys(obj).forEach((otherKey) => {
        if (otherKey !== key) {
          obj[otherKey].forEach((item) => {
            allTitles.push(item.title);
          });
        }
      });

      // Filter out objects with duplicate titles within the current key
      const uniqueTitles = [];
      obj[key].forEach((item) => {
        if (!allTitles.includes(item.title)) {
          uniqueTitles.push(item); // Push the item if title is unique across all keys
          allTitles.push(item.title); // Update allTitles with current key's titles
        }
      });

      // Update the object's array with unique titles
      obj[key] = uniqueTitles;
    });

    return obj;
  };

  const mergeObjects = (obj1, obj2) => {
    const merged = { ...obj1 };

    for (const key in obj2) {
      if (merged[key]) {
        merged[key] = merged[key].concat(obj2[key]);
      } else {
        merged[key] = obj2[key];
      }
    }

    return merged;
  };

  const cmsSearchHandler = () => {
    makeApiRequest(endpoints.getCmsSearch + query, CMS_TOKEN, "GET")
      .then((response) => {
        const formattedResults = response?.data.reduce((acc, item) => {
          if (item.faq_question) {
            if (!acc["faq"]) {
              acc["faq"] = [];
            }
            acc["faq"].push({
              title: item.faq_question,
              url: "/faq/",
              answer: item.answer, // Include answer if needed
              type: "FAQ", // Add type explicitly for FAQ items
            });
          } else {
            const key = "Products"; // Default to "other" if product_type is not defined
            if (!acc[key]) {
              acc[key] = [];
            }
            acc[key].push({
              title: item.title,
              url: item.product_sub_type
                ? `/product-feature/${item.product_type.toLowerCase()}/${item.product_sub_type.toLowerCase()}`
                : item.type.toLowerCase(),
              type: key, // Add type explicitly based on product_type or "other"
            });
          }
          return acc;
        }, {});
        // Remove duplicates from formattedResults based on title
        const uniqueFormattedResults = {};
        Object.keys(formattedResults).forEach((typeKey) => {
          const uniqueTitles = new Set();
          uniqueFormattedResults[typeKey] = formattedResults[typeKey].filter(
            (item) => {
              if (!uniqueTitles.has(item.title)) {
                uniqueTitles.add(item.title);
                return true;
              }
              return false;
            },
          );
        });

        // Merge results and unique formattedResults
        const mergedObject = mergeObjects(results, uniqueFormattedResults);
        const modifiedObject = removeDuplicateTitles(mergedObject);
        isCMSSearchDone(true);
        setResults(sortResults(modifiedObject, query));
      })
      .catch((error) => console.error("Error Fetching Saved Search:", error));
  };
  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      setSavedResults((prevResults) => {
        let updateValue = { title: query, url: "" };
        const updatedResults = [updateValue, ...prevResults]; // Add new result to the beginning
        if (updatedResults.length > 5) {
          updatedResults.pop(); // Remove the last element to maintain FIFO with maximum 5 elements
        }
        return updatedResults; // Reverse the array before returning
      });
      cmsSearchHandler();
      saveInSearchHistory();
    }
  };

  return (
    <div className={parentClasses}>
      <div
        className={`header__search  ${theme === "dark" ? "header__search_darkwrap" : ""} ${childClasses}`}
      >
        <div
          className={`relative header__search_wrap  ${
            showSearch ? "z-[21]" : ""
          }`}
        >
          <SearchInput
            query={query}
            setShowSearch={setShowSearch}
            handleChange={handleChange}
            handleKeyDown={handleKeyDown}
          />
          <div
            className={`header__search_content transition-all ${
              showSearch ? "block" : "hidden"
            }`}
          >
            <div className="default">
              {loading == true ? (
                <SearchLoader />
              ) : query.length > 3 ? (
                Object.keys(results).length === 0 ? (
                  <NoData errorText={"No results found"}>
                    <Link
                      to="/faqs"
                      onClick={() => clearAndClose()}
                      className="text-red-500 text-sm mt-1 font-semibold"
                    >
                      See all FAQ’s
                    </Link>
                  </NoData>
                ) : (
                  <div className="result">
                    <SearchResults
                      results={results}
                      query={query}
                      clearAndClose={clearAndClose}
                    />
                  </div>
                )
              ) : (
                <>
                  <RecentSearches savedResults={savedResults} />
                  <RecommendedSearches recommended={recommended} />
                </>
              )}

              {!cmsSearchDone && Object.keys(results).length > 0 && (
                <NoData errorText={"Cannot find what you are looking for?"}>
                  <Link
                    to="/faqs"
                    onClick={() => clearAndClose()}
                    className="text-red-500 text-sm mt-1 font-semibold"
                  >
                    See all FAQ’s
                  </Link>
                </NoData>
              )}
            </div>
          </div>
        </div>
      </div>
      <Overlay
        showOverlay={showSearch}
        callBackEvent={() => setShowSearch(false)}
      />
    </div>
  );
};

export default Search;

Search.propTypes = {
  parentClasses: PropTypes.string,
  superAppId: PropTypes.string,
  childClasses: PropTypes.string,
};
