import PropTypes from "prop-types";
import { useState } from "react";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import Card from "../Card";
import "./product.css";
import { useNavigate } from "react-router-dom";
import { PRODUCT_PAGE_CONSTANTS } from "../../const/common";
import FetchDynamicImage from "../Common/FetchDynamicImage";
import { convertToUnderscoreFormat } from "../../utils/utils";

const ProductItems = ({
  product_title,
  types,
  imageType = "dynamic",
  listType,
}) => {
  const navigate = useNavigate();
  const [showItems, setShowItems] = useState(true);

  const handleProduct = (productItem, productTitle) => {
    if (listType !== "Services") {
      const faqTitle = productItem?.title?.toLowerCase().split(" ").join("-");
      const productTypeName = productItem?.type_name || faqTitle;
      if (productItem?.title) {
        navigate(`/faqs/faq/${faqTitle}`);
      } else {
        navigate(
          `/product-feature/${productTitle.toLowerCase()}/${convertToUnderscoreFormat(productTypeName)}`,
        );
      }
    } else {
      navigate(productItem.url);
    }
  };

  const handleShowItems = () => {
    setShowItems(!showItems);
  };

  return (
    <div className="space-y-4 lg:space-y-6 mb-6 lg:mb- w-full">
      <div
        className="flex justify-between cursor-pointer"
        onClick={handleShowItems}
      >
        <div className={`title title_xl title_primary `}>{product_title}</div>
        {showItems ? (
          <IoIosArrowDown className="text-red-500 " />
        ) : (
          <IoIosArrowUp className="text-red-500" />
        )}
      </div>
      <div className="flex justify-center w-full">
        {showItems ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 w-full gap-6">
            {types.map((prodItem, index) => {
              return (
                <Card
                  className="cursor-pointer flex items-center relative h-16 text-red-800 px-2"
                  onClick={() => handleProduct(prodItem, product_title)}
                  key={index}
                >
                  {
                    // TODO : TEXT will be dynamic from API
                    false && (
                      <div className="ribbon">
                        {PRODUCT_PAGE_CONSTANTS.OFFER_TEXT}
                      </div>
                    )
                  }
                  <FetchDynamicImage
                    src={prodItem.image}
                    alt={prodItem.type_name ?? prodItem.title}
                    customClasses="w-6 h-6"
                    imageType={imageType}
                  />

                  <div
                    className={`label label_md pl-[10px] label-primary-dark pr-4 capitalize`}
                  >
                    {prodItem.type_name ?? prodItem.title}
                  </div>
                </Card>
              );
            })}
          </div>
        ) : null}
      </div>
    </div>
  );
};

ProductItems.propTypes = {
  product_title: PropTypes.string,
  imageType: PropTypes.string,
  listType: PropTypes.string,
  types: PropTypes.array,
};

export default ProductItems;
