import { takeLatest, put, call } from "redux-saga/effects";
import { OFFERS_DETAILS } from "../actions/actions";
import {
  fetchOffersDetails,
  fetchOffersDetailsSuccess,
  fetchOffersDetailsFailure,
} from "../../store/slices/offersDetailsSlice";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";
import offerDetails from "../../../src/pages/OffersDetails/pre_approve_offer_response.json";
function* fetchOffersDetailsGen(action) {
  try {
    yield put(fetchOffersDetails());
    // Make API request using the token name
    const response = yield call(
      makeApiRequest,
      endpoints.offersDetails,
      BACKEND_TOKEN,
      "POST",
      {
        ucic: action.payload.ucic,
        mobileNumber: action.payload.mobileNumber,
      },
    );
    console.log(response);
    yield put(fetchOffersDetailsSuccess(offerDetails));
  } catch (error) {
    yield put(fetchOffersDetailsFailure(error.message));
  }
}

export function* watchFetchOffersDetails() {
  yield takeLatest(OFFERS_DETAILS, fetchOffersDetailsGen);
}
