import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useState, useEffect } from "react";
import { toggleMenu } from "../../store/slices/menuSlice";
import Search from "../Search";
import menu from "../../assets/icons/menu.svg";
import Logo from "../../assets/logo.svg";
import Button from "../Button";
import Profile from "../Profile";
import Notification from "../../pages/Notification";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../Common/SvgIcon";
import { getUserLoginAction } from "../../pages/Login/loginFormSlice";
import { showSearchHandler } from "../../utils/utils";

const { Switch, Help, Translate } = iconConfig;

const Header = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const [showSidebar, setShowSidebar] = useState(false);
  const [isSticky, setIsSticky] = useState(false);
  const { loginStatus } = useSelector((state) => state.login);
  const navigate = useNavigate();
  // const isLandingPage = true;

  const registerPageRegex = /^\/register(?:\/.*)?$/;
  const showButton = !(
    location.pathname === "/login" ||
    location.pathname === "/reset-password" ||
    location.pathname === "/change-password" ||
    registerPageRegex.test(location.pathname)
  );

  const handleMenuClick = () => {
    dispatch(toggleMenu());
    setShowSidebar(!showSidebar);
  };

  const redirectToLogin = () => {
    navigate("/login");
    dispatch(
      getUserLoginAction({
        mobileNumber: "",
        ucic: "",
        name: "",
        loginStatus: "",
      }),
    );
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return (
    <div className={`z-20 fixed left-0 right-0 top-0`}>
      <div className="max-w-3xl mx-auto w-full">
        <div
          className={`border-light-border-color  py-3 dark:border-dark-border-color dark:bg-black-200 dark:text-white w-full flex flex-col lg:flex-row  lg:justify-between lg:items-center border-b-[1px] h-full px-[16px] lg:px-[48px] justify-between ${
            isSticky ? "bg-white" : "from-transparent"
          }`}
        >
          <div className="flex justify-between w-full">
            <div className=" flex">
              <div className="lg:hidden">
                <SvgIcon url={menu} customClickCallback={handleMenuClick} />
                {/* <img src={menu} alt="menu" onClick={handleMenuClick} /> */}
              </div>

              <Link to="/" className="w-[88px] lg:w-[129px] ml-2 lg:ml-0">
                <SvgIcon url={Logo} colorClass="" />
              </Link>
              {/* Todo add loginStatus && after testing */}
              {loginStatus && showSearchHandler(location.pathname) && (
                <Search parentClasses="hidden lg:block" />
              )}
            </div>
            <div className="flex items-center justify-end">
              {!showButton && (
                <div className="items-center cursor-pointer hidden lg:flex ">
                  <SvgIcon
                    className="cursor-pointer h-4 w-4 lg:h-6 lg:w-6"
                    url={Help}
                    colorClass="group-hover:fill-red-500 "
                  />
                  <span className="label label_md label_primary">Help</span>
                </div>
              )}
              {showButton && (
                <>
                  {loginStatus ? (
                    <div className="flex items-center">
                      <Notification />
                      <div className="flex items-center lg:ml-2 cursor-pointer">
                        <Profile />
                      </div>
                      <div
                        className="flex items-center ml-1 lg:ml-2 cursor-pointer"
                        onClick={() => redirectToLogin()}
                      >
                        <SvgIcon url={Switch} colorClass="" />
                        <span className="hidden lg:block label label_md label_primary ml-1">
                          Log out
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="hidden lg:flex items-center ml-1 gap-2">
                      <div className="flex items-center mr-[8px]">
                        <SvgIcon url={Translate} colorClass="" />
                        <p className=" ml-1 label label_md label_primary">
                          Language
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <NavLink to="/login">
                          <Button
                            name="Login"
                            className="border border-button-bg-red !rounded-lg  px-[22px] py-[10px] dark:!border-red-700 label label_lg label_primary-contrast-red"
                          />
                        </NavLink>
                        <NavLink to="/register" className="ml-2">
                          <Button
                            name="Register"
                            className="bg-button-bg-red text-white px-[22px] py-[10px]  !rounded-lg"
                          />
                        </NavLink>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
          {loginStatus && showSearchHandler(location.pathname) ? (
            <Search parentClasses="block lg:hidden" childClasses="!pl-0" />
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Header;
