import PropTypes from "prop-types";

const ProductOverview = ({ title, description }) => {
  return (
    <div className="space-y-2">
      <h4 className="font-medium text-wrap">{title} </h4>
      <p className="text-wrap md:text-justify">{description}</p>
    </div>
  );
};

ProductOverview.propTypes = {
  title: PropTypes.string,
  description: PropTypes.string,
};

export default ProductOverview;
