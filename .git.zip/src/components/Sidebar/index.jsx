import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { NavLink } from "react-router-dom";
import CloseIcon from "@mui/icons-material/Close";
import { useDispatch, useSelector } from "react-redux";
import { toggleSidebar } from "../../store/slices/sidebarSlice";
import { toggleMenu } from "../../store/slices/menuSlice";
import { isMobile } from "../../utils";
import { PAYMENT } from "../../store/actions/actions";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../Common/SvgIcon";

const {
  Home,
  Dataset,
  Payments,
  Calculate,
  Services,
  Offers,
  Settings,
  LiveHelp,
} = iconConfig;

const navItems = [
  { items: "Home", link: "/", Icons: Home },
  { items: "Products", link: "/product", Icons: Dataset },
  { items: "Pay", link: "/pay", Icons: Payments },
  { items: "Calculators", link: "/calculators", Icons: Calculate },
  { items: "Services", link: "/services", Icons: Services },
  { items: "Offers", link: "/offers", Icons: Offers },
  { items: "FAQ", link: "/faqs", Icons: LiveHelp },
  { items: "Settings", link: "/settings", Icons: Settings },
  { items: "Login", link: "/login", Icons: LiveHelp },
  { items: "Registration", link: "/register", Icons: Settings },
];

const Sidebar = ({ className }) => {
  const dispatch = useDispatch();
  const isOpen = useSelector((state) => state.menu.isOpen);
  const { mobileNumber } = useSelector((state) => {
    return state.login;
  });

  const [payLink, setPaylink] = useState("");
  const pay = useSelector((state) => state.payment);

  const activeClasses = ({ isActive }) =>
    isActive
      ? `group text-light-text-active font-semibold rounded-[20px] text-sm w-full py-2 flex tracking-wider gap-2 items-center pl-[45px] is-active relative`
      : `group hover:text-red-500 gap-2 py-2 rounded-[20px] text-sm flex tracking-wider items-center pl-[45px] title title_sm relative`;

  useEffect(() => {
    if (isOpen) {
      dispatch(toggleSidebar());
    }
  }, [isOpen, dispatch]);

  useEffect(() => {
    if (mobileNumber != "") {
      dispatch({
        type: PAYMENT,
        payload: mobileNumber,
      });
      setPaylink(pay?.payment);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payLink]);

  return (
    <div
      className={`lg:flex  min-h-screen border-r-[1px] opacity-100 border-light-border-color overflow-scroll text-light-text-primary dark:border-dark-border-color dark:text-white ${className} lg:dark:bg-transparent dark:bg-dark-coral h-full mobile-sidebar max-w-[224px] w-full ${
        isOpen
          ? "translate-x-[-100%] "
          : "translate-x-0 ease-in-out top-0 !left-0 !right-0"
      } lg:translate-x-0 lg:z-[11] z-50 bg-white lg:bg-transparent`}
    >
      <div
        className={`flex flex-col min-h-screen py-4 font-semibold  transition-all duration-100 ease-in-out w-full lg:opacity-100 dark:${
          isOpen ? "pt-0" : "pt-0"
        }`}
      >
        <div className={`flex items-center  justify-end p-2  lg:hidden`}>
          <button
            className="focus:outline-none "
            onClick={() => dispatch(toggleMenu())}
          >
            <CloseIcon />
          </button>
        </div>

        <nav
          className={`flex-1 overflow-y-auto lg:pt-4 ${isOpen ? "pt-0" : ""}`}
        >
          <ul className=" lg:space-y-4 mb-14">
            {navItems.map((navItem, index) => {
              const { items, link, Icons } = navItem;
              return (
                <li
                  className={`${open ? "" : "px-1"} mb-1 lg:mb-0 ${items == "Login" || items == "Registration" ? "lg:hidden" : ""}`}
                  key={index}
                >
                  <NavLink
                    target={`${link === "/pay" ? "_blank" : "_self"}`}
                    to={`${link === "/pay" ? payLink : link}`}
                    className={activeClasses}
                    onClick={() => {
                      if (isMobile()) dispatch(toggleMenu());
                    }}
                  >
                    <SvgIcon
                      className={`h-4 w-4 transition-all duration-100 ease-in-out`}
                      url={Icons}
                      colorClass="group-hover:fill-red-500 "
                    />

                    {open ? (
                      <span
                        className={`transition-all duration-100 title title_primary title_xs ease-in-out ${
                          open ? "opacity-100" : "opacity-0 text-center"
                        }`}
                      >
                        {items}
                      </span>
                    ) : null}
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </div>
  );
};

Sidebar.propTypes = {
  className: PropTypes.string,
};

export default Sidebar;
