import { createSlice } from "@reduxjs/toolkit";
import { LATITUDE_LONGITUDE_DATA } from "../actions/actions";

const initialState = {
  latitudeLongitudeData: {},
  loading: false,
  error: null,
};

const latitudeLongitudeSlice = createSlice({
  name: LATITUDE_LONGITUDE_DATA,
  initialState,
  reducers: {
    fetchLatiLongiStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchLatiLongiDataSuccess(state, action) {
      state.loading = false;
      state.latitudeLongitudeData = action.payload;
    },
    fetchLatiLongiDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchLatiLongiStatusData,
  fetchLatiLongiDataSuccess,
  fetchLatiLongiDataFailure,
} = latitudeLongitudeSlice.actions;

export default latitudeLongitudeSlice.reducer;
