import { createSlice } from "@reduxjs/toolkit";
import { VALIDATE_OTP } from "../actions/actions";

const initialState = {
  otpValidateData: {},
  loading: false,
  error: null,
  mobileNumber: "",
};

const validateOtpSlice = createSlice({
  name: VALIDATE_OTP,
  initialState,
  reducers: {
    fetchValidateOtpStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchValidateOtpDataSuccess(state, action) {
      state.loading = false;
      state.otpValidateData = action.payload;
    },
    fetchValidateOtpDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchValidateOtpStatusData,
  fetchValidateOtpDataSuccess,
  fetchValidateOtpDataFailure,
} = validateOtpSlice.actions;

export default validateOtpSlice.reducer;
