import MuiTextField from "./index";

export default {
  title: "Textbox",
  component: MuiTextField,
};

const Template = (args) => <MuiTextField {...args} />;

export const Default = Template.bind({});
Default.args = {
  defaultValue: "",
  label: "Hello",
  name: "textField",
  onChange: () => {},
};
