import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isRegistered: false,
  isCustomer: false,
  isPan: false,
  successData: {},
  failureData: {},
};

const registerSlice = createSlice({
  name: "Register",
  initialState,
  reducers: {
    getOtpSuccessAction: (state, action) => {
      state.isCustomer = action.payload.isCustomer;
      state.isRegistered = action.payload.isRegistered;
      state.isPan = action.payload.isPan; // import Json mock file till api get ready to consume
    },
    getOtpFailureAction: (state, action) => {
      state.failureData = action.payload;
    },
    getForgotAction: (state, action) => {
      state.forgot = action.payload;
    },
  },
});

export const { getOtpSuccessAction, getOtpFailureAction, getForgotAction } =
  registerSlice.actions;

export default registerSlice.reducer;
