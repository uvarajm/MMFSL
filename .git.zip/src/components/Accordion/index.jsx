import PropTypes from "prop-types";
import DOMPurify from "dompurify";
import { useState } from "react";

const CustomAccordion = ({ items, customFontStyle }) => {
  const sanitizer = DOMPurify.sanitize;
  // const items = props?.items;
  const [openIndex, setOpenIndex] = useState(null);
  const toggleAccordion = (index) => {
    setOpenIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  return (
    <div className="w-full">
      {items?.map((item, index) => (
        <div
          key={index}
          className={`${
            index == items.length - 1 ? "" : "border-b border-lilac-light"
          }`}
        >
          <button
            onClick={() => toggleAccordion(index)}
            className="w-full flex justify-between items-center p-4 focus:outline-none transition-all duration-500 ease-in-out"
          >
            <span
              className={`text-wrap text-start title title_sm title_primary-dark 0 ${customFontStyle}`}
            >
              {item.title}
            </span>
            <svg
              width="24"
              className={` w-4 h-4 lg:w-6 lg:h-6 transition-transform ${
                openIndex === index ? "" : "transform rotate-180"
              }`}
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <mask
                id="mask0_1988_39083"
                style={{ maskType: "alpha" }}
                maskUnits="userSpaceOnUse"
                x="0"
                y="0"
                width="24"
                height="24"
              >
                <rect
                  x="24"
                  y="24"
                  width="24"
                  height="24"
                  transform="rotate(-180 24 24)"
                  fill="#D9D9D9"
                />
              </mask>
              <g mask="url(#mask0_1988_39083)">
                <path
                  d="M12.0001 9.33849C12.1206 9.33849 12.2328 9.35773 12.3366 9.39619C12.4405 9.43466 12.5392 9.50069 12.6328 9.59427L17.127 14.0885C17.2655 14.2269 17.3363 14.401 17.3395 14.6106C17.3427 14.8202 17.2719 14.9975 17.127 15.1423C16.9821 15.2872 16.8065 15.3596 16.6001 15.3596C16.3937 15.3596 16.2181 15.2872 16.0732 15.1423L12.0001 11.0692L7.927 15.1423C7.78855 15.2808 7.61451 15.3516 7.4049 15.3548C7.1953 15.358 7.01806 15.2872 6.8732 15.1423C6.72831 14.9975 6.65587 14.8218 6.65587 14.6154C6.65587 14.409 6.72831 14.2334 6.8732 14.0885L11.3674 9.59427C11.461 9.50069 11.5597 9.43466 11.6636 9.39619C11.7674 9.35773 11.8796 9.33849 12.0001 9.33849Z"
                  fill="#E31837"
                />
              </g>
            </svg>
          </button>
          {openIndex === index && (
            <div
              className="px-4 py-2 pt-0 transition-all duration-500 ease-in-out primary-description"
              dangerouslySetInnerHTML={{
                __html: sanitizer(item.description) || sanitizer(item.answer),
              }}
            ></div>
          )}
        </div>
      ))}
    </div>
  );
};

CustomAccordion.propTypes = {
  items: PropTypes.any,
  customFontStyle: PropTypes.string,
};

export default CustomAccordion;
