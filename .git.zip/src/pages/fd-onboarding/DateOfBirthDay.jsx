import { Button } from "../../components";
import DatePickerTextBox from "../../components/DatePicker/DatePickerTextBox";
import calendar from "../../assets/icons/calendar.svg";
import { Breadcrumb, MainContainer } from "../../components";

const DateOfBirthDay = () => {
  return (
    <MainContainer className={`flex flex-col xl:px-4`}>
      <div className="sticky top-[64px] sm:top-[48px] z-10 bg-white max-lg:px-2">
        <Breadcrumb />
        <DatePickerTextBox
          title="Enter your date of birth"
          icon={calendar}
          fontSize="large"
        />
        <Button name="Continue" className="text-white bg-red-500 mt-10" />
      </div>
    </MainContainer>
  );
};
export default DateOfBirthDay;
