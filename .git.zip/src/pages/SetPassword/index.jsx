import {
  Container,
  PasswordWithStrength,
  Password,
  Button,
} from "../../components";
import { Form, Formik } from "formik";
import * as Yup from "yup";
import { useLocation } from "react-router-dom";
import {
  passwordValidation,
  passwordWithStrengthValidation,
} from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";
import { useDispatch, useSelector } from "react-redux";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import {
  CREATE_PASSWORD,
  REGISTERED_USER_STATUS,
} from "../../store/actions/actions";
import { useEffect, useState } from "react";

const initialValues = {
  password: "",
  confirmPassword: "",
};

// password validation
const validateSchema = Yup.object({
  password: passwordWithStrengthValidation("Please enter password"),
  confirmPassword: passwordValidation("Enter Confirm Password").oneOf(
    [Yup.ref("password"), null],
    "Passwords do not match",
  ),
});

const SetPassword = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const { createPasswordData, loading, error } = useSelector(
    (state) => state.createPassword,
  );
  const { mobileNumber } = useSelector((state) => state.register);

  useEffect(() => {
    if (showPassword) setShowConfirmPassword(false);
  }, [showPassword]);

  useEffect(() => {
    if (showConfirmPassword) setShowPassword(false);
  }, [showConfirmPassword]);

  const headerName =
    location.pathname === "/register/set-password"
      ? "Set your Password"
      : location.pathname === "/reset-password"
        ? "Reset your password"
        : null;

  const onSubmit = (values) => {
    const data = {
      mobileNumber: mobileNumber,
      password: values?.password,
    };

    dispatch({ type: CREATE_PASSWORD, payload: data });

    // if (location.pathname === "/reset-password") {
    //   navigate("/success");
    // } else {
    //   navigate("/success");
    // }
  };

  useEffect(() => {
    const data = {
      mobileNumber: mobileNumber,
    };
    if (createPasswordData && createPasswordData?.code === "SUCCESS")
      dispatch({ type: REGISTERED_USER_STATUS, payload: data });
  }, [createPasswordData, dispatch, mobileNumber]);

  return (
    <Container className="px-4">
      <HandleDataRendering
        data={createPasswordData}
        loading={loading}
        error={error}
        className="w-full minHeight flex justify-center items-center"
      >
        <div className="w-full minHeight flex justify-center items-center">
          <div className="flex flex-col justify-between w-[400px]">
            <div className="flex items-center lg:block">
              <BackButton />
              <div className="tracking-wide headline headline_xl lg:pt-2 pl-1 lg:pl-0">
                {headerName}
              </div>
            </div>

            <div className="flex-1">
              <Formik
                initialValues={initialValues}
                validationSchema={validateSchema}
                onSubmit={onSubmit}
              >
                {(formik) => (
                  <Form className="flex flex-col">
                    <div className="pt-4">
                      <PasswordWithStrength
                        label="Password"
                        name="password"
                        placeholder="Enter password"
                        formik={formik}
                        setShowPassword={setShowPassword}
                        showPassword={showPassword}
                        showConfirmPassword={showConfirmPassword}
                        setShowConfirmPassword={setShowConfirmPassword}
                      />
                    </div>
                    <div className="pt-4">
                      <Password
                        label="Re-enter password"
                        name="confirmPassword"
                        placeholder="Re-enter password"
                        showPassword={showPassword}
                        formik={formik}
                        setShowConfirmPassword={setShowConfirmPassword}
                        showConfirmPassword={showConfirmPassword}
                      />
                    </div>

                    {/* Failure message */}
                    {createPasswordData?.code === "FAILURE" && (
                      <p className="font-karla font-normal text-sm leading-[18px] text-grey-500 py-4 px-[18px] w-full bg-white mt-10 rounded-lg">
                        {createPasswordData?.message}
                      </p>
                    )}

                    <div className="flex w-full mt-[40px]">
                      <Button
                        type="submit"
                        name="Confirm"
                        disabled={!(formik.isValid && formik.dirty)}
                        className="hover:opacity-85 w-full rounded-lg font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
                      />
                    </div>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </HandleDataRendering>
    </Container>
  );
};

export default SetPassword;
