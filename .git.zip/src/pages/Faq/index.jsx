import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { APP_FAQS } from "../../store/actions/actions";
import ProductPageDetails from "../../pages/Products/ProductPageDetails";
import { FAQ_TYPE, PRODUCT_FAQ } from "../../const/ProductConst";
import { MainContainer } from "../../components";
import ProductsFaqs from "./ProductsFaqs";
import GeneralFaq from "./GeneralFaq";
import HowToFaq from "./HowToFaq";
import { isArrayEmpty } from "../../utils/commonUtils";
import { compareStr } from "../../utils/commonUtils";
import Sidebar from "../../components/OfferSidebar";

const [PRODUCTS, GENERAL, HOW_TO] = PRODUCT_FAQ.PRODUCT_TABS;

const Faq = () => {
  const dispatch = useDispatch();
  const { AppFaqs, loading, error } = useSelector((state) => state.AppFaqs);
  let defaultActiveTab = PRODUCTS;
  // for Filtering the general tab
  const generalFaqData = AppFaqs?.filter((item) =>
    compareStr(item.faq_type, GENERAL),
  );

  // for Filtering the how to tab
  const howToFaqData = AppFaqs?.filter((item) => item.faq_type === FAQ_TYPE);

  const renderTabContent = (activeTab) => {
    const tabContentMap = {
      [PRODUCTS]: (
        <ProductsFaqs AppFaqs={AppFaqs} loading={loading} error={error} />
      ),
      [GENERAL]: (
        <GeneralFaq
          generalFaqData={generalFaqData}
          loading={loading}
          error={error}
        />
      ),
      [HOW_TO]: (
        <HowToFaq howToFaqData={howToFaqData} loading={loading} error={error} />
      ),
    };

    return tabContentMap[activeTab];
  };

  useEffect(() => {
    if (isArrayEmpty(AppFaqs)) dispatch({ type: APP_FAQS });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <MainContainer className="" showSidebar={true}>
      <ProductPageDetails
        renderTabContent={renderTabContent}
        productDetails={PRODUCT_FAQ}
        defaultActiveTab={defaultActiveTab}
      />
      <Sidebar customClasses="lg:mt-[60px]" />
    </MainContainer>
  );
};

export default Faq;
