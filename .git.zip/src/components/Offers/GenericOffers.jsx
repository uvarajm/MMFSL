import PropTypes from "prop-types";
import GenericOffersCard from "./GenericOffersCard";

const GenericOffers = ({ genericOffers }) => {
  const getHeader = (offer) => {
    let customOfferDetails = {};
    customOfferDetails.flatRate = offer.offer_detail_tabs[0].tab_details.roi;
    customOfferDetails.loanAmount =
      offer.offer_detail_tabs[0].tab_details.loan_amount;
    customOfferDetails.emi =
      offer.offer_detail_tabs[0].tab_details.emi_tenure_max;
    customOfferDetails.tenure = offer.offer_detail_tabs[0].tab_details.tenure;

    let heading = "";
    offer?.header?.every((header) => {
      if (header.includes("offer_percentage")) {
        heading = header.replace(
          "offer_percentage",
          customOfferDetails.flatRate,
        );
        return true;
      } else if (header.includes("offer_amount")) {
        heading = header.replace("offer_amount", customOfferDetails.loanAmount);
        return true;
      } else if (header.includes("offer_tenure")) {
        heading = header.replace("offer_tenure", customOfferDetails.tenure);
        return true;
      }
    });
    return heading;
  };

  const genericOffersList = genericOffers.map((offer) => {
    return (
      <GenericOffersCard
        genericOffer={offer}
        header={getHeader(offer)}
        key={offer.offer_id}
      />
    );
  });

  return <div className="flex w-full">{genericOffersList}</div>;
};
GenericOffers.propTypes = {
  genericOffers: PropTypes.array,
};
export default GenericOffers;
