import PanCard from "../../pages/Register/PanCard";
import Help from "../Help";
import { items } from "../../utils";

const PanDetails = () => {
  return (
    <div
      className="w-[100vw] flex justify-center"
      style={{
        minHeight: "calc(100vh - 48px)",
      }}
    >
      <div className={` relative border-l-[1px] border-r-[1px] flex p-4`}>
        <div className="absolute right-7">
          <Help helpTitle="Pancard Issues" items={items} />
        </div>
        <div className="mt-10">
          <PanCard />
        </div>
      </div>
    </div>
  );
};

export default PanDetails;
