import { takeLatest, put, call } from "redux-saga/effects";
import { GET_PRIVACY_POLICY } from "../actions/actions";
import {
  fetchPrivacyPolicyPageData,
  fetchPrivacyPolicyPageDataSuccess,
  fetchPrivacyPolicypageDataFailure,
} from "../slices/privacyPolicyPageSlice";
import { endpoints, makeApiRequest } from "../../utils/apiUtils";
import { CMS_TOKEN } from "../../const/common";
function* fetchPrivacyPolicyData() {
  try {
    yield put(fetchPrivacyPolicyPageData());
    const response = yield call(
      makeApiRequest,
      endpoints.privacyPolicy,
      CMS_TOKEN,
    );
    yield put(fetchPrivacyPolicyPageDataSuccess(response.data));
  } catch (error) {
    yield put(fetchPrivacyPolicypageDataFailure(error.message));
  }
}

export function* watchfetchPrivacyPolicyContent() {
  yield takeLatest(GET_PRIVACY_POLICY, fetchPrivacyPolicyData);
}
