import { Outlet } from "react-router-dom";

const RegisterLayout = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default RegisterLayout;
