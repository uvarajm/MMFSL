import { createSlice } from "@reduxjs/toolkit";
import { USER_LOGIN } from "./types";

const initialState = {
  mobileNumber: "",
  ucic: "",
  name: "",
  loginStatus: false,
  superAppId: "5424431721", //Remove hardcoded superAppId after login integration "locate us: { superAppId: "SID12320"}"
  successData: {},
  failureData: {},
};

const loginSlice = createSlice({
  name: USER_LOGIN,
  initialState,
  reducers: {
    getUserLoginAction: (state, action) => {
      state.mobileNumber = action.payload.number;
      state.ucic = action.payload.ucic;
      state.name = action.payload.name;
      state.loginStatus = !state.loginStatus;
    },
    getUserLoginSuccessAction: (state, action) => {
      state.successData = action.payload;
      state.loginStatus = !state.loginStatus;
    },
    getUserLoginFailureAction: (state, action) => {
      state.failureData = action.payload;
    },
  },
});

export const {
  getUserLoginAction,
  getUserLoginSuccessAction,
  getUserLoginFailureAction,
} = loginSlice.actions;

export default loginSlice.reducer;
