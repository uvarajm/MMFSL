import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { status } from "../../const/common";
import CustomStepIcon from "./stepIcon"; // Ensure this path is correct
import CustomStepConnector from "./CustomStepConnector"; // Ensure this path is correct

export default function checkCircleIcon(applicantName) {
  const index = status.findIndex((ele) => ele === applicantName);
  return (
    <div className="-mx-[35px]">
      <Box sx={{ width: "100%" }}>
        <Stepper
          activeStep={index}
          alternativeLabel
          connector={<CustomStepConnector />}
        >
          {status.map((label) => (
            <Step key={label}>
              <StepLabel StepIconComponent={CustomStepIcon}></StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
    </div>
  );
}
