import axios from "axios";
import { getTokenFromCookies, setTokenInCookies } from "../utils/cookiesUtil";

const generateToken = async (
  clientId,
  clientSecret,
  tokenEndpoint,
  tokenName,
) => {
  // Check if token already exists in cookies
  const existingToken = getTokenFromCookies(tokenName);
  if (existingToken) {
    return existingToken;
  }

  try {
    const params = new URLSearchParams();
    params.append("grant_type", "client_credentials");
    params.append("client_id", clientId);
    params.append("client_secret", clientSecret);

    const response = await axios.post(
      `${import.meta.env.VITE_API_BASE_URL}${tokenEndpoint}`,
      params,
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      },
    );

    const token = response.data.access_token;

    // Set token expiration time in cookies
    const expiresIn = response.data.expires_in;
    setTokenInCookies(tokenName, token, expiresIn);

    return token;
  } catch (error) {
    console.error("Error generating token:", error);
    throw error;
  }
};

export default generateToken;
