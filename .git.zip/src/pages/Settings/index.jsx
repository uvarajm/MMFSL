import { MainContainer, Modal } from "../../components";
import iconConfig from "../../assets/iconsConfig";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import { toggleTheme } from "../../store/slices/themeSlice";
import { useDispatch, useSelector } from "react-redux";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import Button from "../../components/Button";
import { LANGUAGE_PREFERENCES } from "../../const/common";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import SvgIcon from "../../components/Common/SvgIcon";

const Settings = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { theme } = useSelector((state) => state.theme);
  const [modelToggle, setModelToggle] = useState(false);
  return (
    <MainContainer showSidebar={true} showPreApproved={false}>
      <div className={`content-section sidebar-width`}>
        <div className={`headline headline_md headline_primary`}>Settings</div>
        <div className="flex flex-col lg:flex-row">
          <div className="explore-width w-full">
            <ul className="text-red-800 dark:text-white">
              <li
                className="border-b border-lilac-light lg:px-2 py-4 flex items-center justify-between cursor-pointer"
                onClick={() => navigate("/reset-password")}
              >
                <div className="flex">
                  <SvgIcon url={iconConfig.KeyVertical} colorClass="" />
                  <p className="title title_primary title_sm ml-2">
                    Change password
                  </p>
                </div>
                <ChevronRightIcon className="text-red-500 dark:text-white" />
              </li>
              <li
                className="border-b border-lilac-light lg:px-2 py-4 flex items-center justify-between cursor-pointer"
                onClick={() => setModelToggle(true)}
              >
                <div className="flex">
                  <SvgIcon url={iconConfig.Translate} colorClass="" />
                  <p className="title title_primary title_sm ml-2">
                    Language preference - English
                  </p>
                </div>
                <ChevronRightIcon className="text-red-500 dark:text-white" />
              </li>
              <li className="border-b border-lilac-light lg:px-2 py-4 flex items-center justify-between ">
                <div className="flex">
                  <SvgIcon url={iconConfig.Image} colorClass="" />
                  <p className="title title_primary title_sm ml-2 ">
                    Theme - Light
                  </p>
                </div>
                <div className="rounded-[50%] pl-2">
                  <label className="switch">
                    <span className="moon">
                      <LightModeOutlinedIcon className="text-white" />
                    </span>
                    <span className="sun">
                      <DarkModeOutlinedIcon className="text-black-100" />
                    </span>
                    <input
                      type="checkbox"
                      className="input"
                      checked={theme !== "light" ? false : true}
                      onChange={() => dispatch(toggleTheme())}
                    ></input>
                    <span className="slider"></span>
                  </label>
                </div>
              </li>
              <li className="lg:px-2 pt-4">
                <div className="flex items-center mb-4">
                  <SvgIcon url={iconConfig.RememberMe} colorClass="" />
                  <p className="title title_primary title_sm ml-2 ">
                    Registered devices
                  </p>
                  <InfoOutlinedIcon className="!w-[12px] !h-[12px] ml-2" />
                </div>
                <div className="device-list border border-lilac-light rounded lg:p-4">
                  <div className="title title_primary title_xs p-3 lg:pb-2 lg:px-0 border-lilac-light border-b">
                    Samsung Galaxy Note 7
                  </div>
                  <div className="flex flex-wrap md:flex-nowrap p-2 lg:p-0 lg:pt-4 lg:-mx-4">
                    <div className="md:w-1/4 w-1/2 break-all px-2 md:px-4">
                      <p className="label label_primary label_md">Device ID</p>
                      <p className="content content_secondary content_md text-wrap">
                        10000056789
                      </p>
                    </div>
                    <div className="md:w-1/4 w-1/2 break-all px-2 md:px-4">
                      <p className="label label_primary label_md">
                        Last active
                      </p>
                      <p className="content content_secondary content_md ">
                        7 days ago
                      </p>
                    </div>
                    <div className="md:w-1/4 w-1/2 break-all px-2 md:px-4">
                      <p className="label label_primary label_md">Location</p>
                      <p className="content content_secondary content_md">
                        Mumbai
                      </p>
                    </div>
                    <div className="md:w-1/4 w-full break-all px-2 md:p-0 flex justify-start lg:justify-center">
                      <button className="max-w-[140px] w-full label label_lg !capitalize label label_lg label_primary-contrast-red dark:!border-red-700 !p-2 !border-red-500 !rounded-[10px] !max-h-[48px] border">
                        De- register
                      </button>
                    </div>
                  </div>
                </div>
              </li>
              <li className="px-2 py-4 flex items-center justify-between ">
                <div className="flex">
                  <SvgIcon url={iconConfig.Chat} colorClass=" " />
                  <p className="title title_primary title_md ml-2 ">
                    Whatsapp opt-in consent
                  </p>
                </div>
                <div className="p-2 rounded-[50%] pl-2">
                  <label className="consent-switch">
                    <input type="checkbox" className="input"></input>
                    <span className="slider"></span>
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <Modal
        isOpen={modelToggle}
        className="rounded-lg max-w-[720px] my-4 w-full"
      >
        <div className="p-4">
          <div className="space-y-2 flex justify-between items-center">
            <p className="lg:text-2xl font-semibold text-red-800 leading-[30px] font-quicksand mb-4">
              Choose your language
            </p>
          </div>
          <ul className="flex -mx-2 mb-6 flex-wrap language-preference">
            {LANGUAGE_PREFERENCES.map((language, index) => (
              <li
                className="p-2 w-2/4 lg:w-1/4 "
                key={`${language}-${index} relative`}
              >
                <label
                  className={`flex flex-wrap language-card w-[149px] h-[67px]`}
                >
                  <input name="language" className="radio" type="radio"></input>
                  <div className="plan-detail flex border border-lilac-light cursor-pointer rounded relative p-2 w-[149px] h-[67px]">
                    <div className="h-[33px] flex-shrink-0 ">
                      <img
                        src={language.icon}
                        alt={`${language?.text} icon`}
                        className="w-full h-auto "
                      />
                    </div>
                    <div className={`flex flex-col justify-center ml-2  `}>
                      {language.font && (
                        <p className="title title_sm title-primary-dark ">
                          {language.font}
                        </p>
                      )}
                      {language.text && (
                        <p className="title title_sm title_secondary-dark dark:font-normal font-normal ">
                          {language.text}
                        </p>
                      )}
                    </div>
                  </div>
                </label>
              </li>
            ))}
          </ul>
          <div className="flex items-center justify-center">
            <Button
              type="submit"
              name="Cancel"
              className="gap-8 border border-red-500 w-[177px] text-red-500 font-bold rounded-lg text-sm font-quicksand"
              onClick={() => setModelToggle(false)}
            />
            <Button
              type="submit"
              name="Save"
              className="rounded-lg bg-red-500 ml-5 w-[177px] text-white font-bold leading-5 text-sm font-quicksand"
              onClick={() => setModelToggle(false)}
            />
          </div>
        </div>
      </Modal>
    </MainContainer>
  );
};

export default Settings;
