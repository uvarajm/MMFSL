import { useNavigate } from "react-router-dom";
import Breadcrumb from "../../../components/Breadcrumb";
import { ArrowBack, ArrowForward } from "@mui/icons-material";
import { Box, Grid } from "@mui/material";
import { useState } from "react";
import ForeclosureItem from "../../../components/ForeclosureCard/ForeclosureItem";
import TabComponent from "../../../components/TabComponent";
import { ForeclosureCardData } from "../../../utils/utils";

const Foreclosure = () => {
  const navigate = useNavigate();
  const [foreclosureActive, setForeclosureActive] = useState(0);
  // const [foreclosureProceedBtnActive, setForeclosureProceedBtnActive] = useState(false);
  // const [foreclosureCardDetail, setForeclosureCardDetail] = useState(false);

  const handleBackward = () => {
    navigate("..");
  };

  return (
    <div className="w-full">
      <div className="p-5">
        <Breadcrumb />
      </div>

      <div className="w-full pt-2">
        <div className="w-full flex flex-col md:flex-row md:items-center justify-between p-5">
          <p className="flex items-center">
            <ArrowBack
              sx={{ color: "#1B438B", fontSize: "32px", cursor: "pointer" }}
              onClick={handleBackward}
            />
            <span className="text-[#322F35] font-semibold text-[22px] pl-2">
              Foreclosure
            </span>
          </p>

          <div className="flex max-sm:justify-between md:items-center max-sm:mt-2">
            <p className="underline text-[#322F35] font-normal text-[14px] md:px-20">
              Filter
            </p>
            <p className="flex md:items-center md:pr-20">
              <span className="underline text-[#322F35] font-normal text-[14px] pr-2">
                Application(s) in progress
              </span>
              <ArrowForward
                sx={{ color: "#322F35", fontSize: "25px", cursor: "pointer" }}
              />
            </p>
          </div>
        </div>

        <div className="w-full">
          <div className="mt-2 bg-[#D9D9D9] w-full flex justify-center">
            <TabComponent
              foreclosureActive={foreclosureActive}
              setForeclosureActive={setForeclosureActive}
            />
          </div>
          <div className="p-5 pt-0 mt-5">
            <Box sx={{ flexGrow: 1 }}>
              <Grid
                container
                rowSpacing={3}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
              >
                {ForeclosureCardData &&
                  ForeclosureCardData?.map((item) => (
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={6}
                      rowSpacing={3}
                      key={item?.id}
                    >
                      <ForeclosureItem
                        foreclosureProceedBtnActive={
                          item?.foreclosureProceedBtnActive
                        }
                        foreclosureCardDetail={item?.foreclosureCardDetail}
                        Person2Outlined={item?.Person2Outlined}
                        loneType={item?.loanType}
                        loanFor={item?.loanFor}
                        middleLeftHeader={item?.middleLeftHeader}
                        middleLeftData={10000}
                        middleRightHeader={"Remaining Amount"}
                        middleRightData={5000}
                        errorDescription={
                          "Foreclosure not allowed within freeze period. Please try after 5th of next month."
                        }
                        periodTime={"Locking period ends on - 00 Month 0000"}
                        buttonText={item?.buttonText}
                      />
                    </Grid>
                  ))}
              </Grid>
            </Box>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Foreclosure;
