import PropTypes from "prop-types";
import { Field, ErrorMessage } from "formik";
import TextError from "../TextError";
import { MdVisibilityOff, MdVisibility } from "react-icons/md";

const Password = ({
  label,
  name,
  showPassword,
  setShowConfirmPassword,
  showConfirmPassword,
  ...rest
}) => {
  // const { placeholder, ...restWithoutPlaceholder } = rest;

  // const togglePasswordVisibility = () => {
  //   // passwordRef.current.type =
  //   //   passwordRef.current.type === "password" ? "text" : "password";
  //   setShowPassword(!showPassword);
  // };

  const hasError = rest.formik.errors[name] && rest.formik.touched[name];

  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={name} className=" label label_lg label_primary">
        {label}
      </label>
      <div
        className={`flex gap-1 bg-transparent focus:outline-none ${
          hasError ? "border-b-1 border-red-500" : "w-full"
        }`}
      >
        <div className="flex items-center w-full relative">
          <Field
            id={name}
            // ref={passwordRef}
            type={showConfirmPassword && !showPassword ? "text" : "password"}
            name={name}
            {...rest}
            className="bg-transparent border-b-2 border-red-100 focus:outline-none pb-[7px] pl-3 text-grey-500 font-karla font-normal leading-[22px] w-full"
          />
          <button
            type="button"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            className="absolute right-2"
          >
            {showConfirmPassword && !showPassword ? (
              <MdVisibilityOff />
            ) : (
              <MdVisibility />
            )}
          </button>
        </div>
      </div>
      <ErrorMessage name={name} component={TextError} />
    </div>
  );
};

Password.propTypes = {
  label: PropTypes.string,
  name: PropTypes.string,
  showPassword: PropTypes.bool,
  setShowConfirmPassword: PropTypes.func,
  showConfirmPassword: PropTypes.bool,
};

export default Password;
