import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { MainContainer } from "../../components";
import BackButton from "../../components/Common/BackButton";
import Locate from "../../assets/icons/location.svg";
import ArrowDown from "../../assets/icons/expand_more.svg";
import ProductPageDetails from "../Products/ProductPageDetails";
import { LOCATE } from "../../const/common";
import Branches from "./Branches";
import Dealers from "./Dealers";
import Saved from "./Saved";
import SvgIcon from "../../components/Common/SvgIcon";
import iconConfig from "../../assets/iconsConfig";
import { isNumber, isObjectBlank } from "../../utils";
import Sidebar from "../../components/OfferSidebar";
import { CASH_COLLECTION_POINTS } from "../../const/locateConst";
import CashCollectionPoints from "../../components/LocateUs/CashCollectionPoints";
import {
  GET_SAVED_BOOKMARKS_DATA,
  UPDATE_BOOKMARKS,
} from "../../store/actions/actions";
import { resetDealerPinCodeData } from "../../store/slices/pinCodeStatusSlice";

const [BRANCHES, DEALERS, CASH_COLLECTIONS_POINTS, SAVED] = LOCATE.PRODUCT_TABS;

const LocationDetails = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { pinCodeData, loading } = useSelector((state) => state.pinCodeData);
  const { getSavedBookmarksData } = useSelector((state) => state.getBookmarks);
  let { updateBookmarkData, loading: saveLoading } = useSelector(
    (state) => state.updateBookmark,
  );
  const { latitude, longitude } = useSelector((state) => state.geoLocation);
  const { dealerPinCodeData, loading: pinCodeLoading } = useSelector(
    (state) => state.dealerPinCode,
  );
  const location = useLocation();
  const selectedPincodeValue = location.state?.locate || "";
  const { superAppId } = useSelector((state) => state.login);
  const [saveList, setSaveList] = useState([]);

  useEffect(() => {
    if (
      isObjectBlank(pinCodeData) &&
      isObjectBlank(dealerPinCodeData) &&
      isObjectBlank(getSavedBookmarksData)
    ) {
      navigate("/locate-us", {
        state: {
          redirectFrom: "location",
        },
      });
    }
  }, []);

  const { bookmarkObj } = useSelector((state) => state.bookmark);
  useEffect(() => {
    const checkBranchDealer = isNumber(bookmarkObj.code);
    dispatch({
      type: UPDATE_BOOKMARKS,
      payload: {
        code: `${checkBranchDealer ? "D" : "B"}-${bookmarkObj.code}`,
        saveBranch: bookmarkObj.isBookmarks,
        superAppId: superAppId,
      },
    });
    const filterUnSavedData = saveList?.filter(
      (item) => item.code !== bookmarkObj.code,
    );
    setSaveList(filterUnSavedData);
  }, [bookmarkObj]);

  useEffect(() => {
    dispatch({
      type: GET_SAVED_BOOKMARKS_DATA,
      payload: { superAppId: superAppId },
    });
  }, [updateBookmarkData]);

  const handleBackRedirection = () => {
    dispatch(resetDealerPinCodeData());
    navigate("/locate-us", {
      state: {
        redirectFrom: "location",
      },
    });
  };

  let defaultActiveTab = BRANCHES;
  const renderTabContent = (activeTab) => {
    const tabContentMap = {
      [BRANCHES]: (
        <Branches
          pinCodeData={pinCodeData}
          getSavedBookmarksData={getSavedBookmarksData}
          latitude={latitude}
          longitude={longitude}
          superAppId={superAppId}
          updateBookmarkData={updateBookmarkData}
          saveLoading={saveLoading}
          loading={loading}
        />
      ),
      [DEALERS]: (
        <Dealers
          getSavedBookmarksData={getSavedBookmarksData}
          dealerPinCodeData={dealerPinCodeData}
          superAppId={superAppId}
          updateBookmarkData={updateBookmarkData}
          saveLoading={saveLoading}
          loading={pinCodeLoading}
        />
      ),
      [CASH_COLLECTIONS_POINTS]: <CashCollectionPoints />,
      [SAVED]: (
        <Saved
          latitude={latitude}
          longitude={longitude}
          getSavedBookmarksData={getSavedBookmarksData}
          superAppId={superAppId}
          saveLoading={saveLoading}
          setSaveList={setSaveList}
          saveList={saveList}
          updateBookmarkData={updateBookmarkData}
        />
      ),
    };
    return tabContentMap[activeTab];
  };

  return (
    <MainContainer className={`flex lg:pt-4 px-4 lg:px-12 w-full`}>
      <div className="sidebar-width">
        <div className="w-full flex justify-between flex-wrap lg:flex-nowrap">
          <div className="w-full">
            <div className="flex items-center pt-4">
              <BackButton handleCallback={handleBackRedirection} />
              <p className="headline headline_md headline_primary">
                {CASH_COLLECTION_POINTS.MAIN_PAGE_TITLE}
              </p>
            </div>

            <div
              className="pt-6 w-[335px] flex items-center"
              onClick={() => {
                handleBackRedirection();
              }}
            >
              <div
                className={`w-[295px] ${pinCodeData?.branchList ? "h-auto" : "h-10"} bg-white px-4 py-[10px] rounded-lg relative flex items-center`}
              >
                <div className="w-6 h-6 absolute left-4 -top-[2px]">
                  <img src={Locate} alt="locate" className="pt-2" />
                </div>
                <p className="pl-7 pr-5 content content_lg content_secondary_dark leading-[18px]">
                  {selectedPincodeValue
                    ? selectedPincodeValue
                    : "No data found"}
                </p>
                <div className="w-6 h-6 absolute right-4 -top-[2px]">
                  <img src={ArrowDown} alt="arrow_down" className="pt-2" />
                </div>
              </div>
              <div className="pl-4">
                <SvgIcon
                  url={iconConfig.MyLocation}
                  colorClass="fill-red-800 "
                  className="w-[20.4px] h-[20.4px]"
                />
              </div>
            </div>
            <div className="w-full">
              <ProductPageDetails
                renderTabContent={renderTabContent}
                productDetails={LOCATE}
                defaultActiveTab={defaultActiveTab}
                showBeforeLogin={true}
                isHeaderSticky={true}
                stickyValue={100}
                headerStyle={"lg:max-w-[678px] w-full"}
              />
            </div>
          </div>
        </div>
      </div>
      <Sidebar className="pt-[50px]" />
    </MainContainer>
  );
};

export default LocationDetails;
