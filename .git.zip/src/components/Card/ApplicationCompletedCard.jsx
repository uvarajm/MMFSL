import "./card.css";

function ApplicationCompletedCard() {
  return (
    <div className="mt-6 p-4 text-size">
      <p className="text-grey-500 text-2xl">Congratulations!</p>
      <p className="font-semibold">
        Your application was processed successfully.
      </p>
    </div>
  );
}

export default ApplicationCompletedCard;
