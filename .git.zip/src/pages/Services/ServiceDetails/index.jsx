import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Breadcrumb, MainContainer } from "../../../components";
import BackButton from "../../../components/Common/BackButton";
import { useSelector } from "react-redux";
import Sidebar from "../../../components/OfferSidebar";
import moment from "moment";
import { MOMENT_FORMATS } from "../../../const/common";
import { DETAILS_LABLE } from "../serviceConstants";
import CopyToClipboard from "../../../components/Common/CopyToClipboard";

const ServiceDetails = () => {
  const Navigate = useNavigate();
  const { srId } = useParams();
  const [isSticky, setIsSticky] = useState(false);
  const [result, setResult] = useState({});
  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const { services } = useSelector((state) => {
    return {
      services: state.services.services,
    };
  });

  const getObjectByCaseNumber = (caseNumber) => {
    for (const key in services) {
      if (Array.isArray(services[key])) {
        const foundObject = services[key].find(
          (item) => item.caseNumber === caseNumber,
        );
        if (foundObject) {
          return foundObject;
        }
      }
    }
    return null;
  };

  useEffect(() => {
    if (!getObjectByCaseNumber(srId)) {
      Navigate("/services");
    } else {
      setResult(getObjectByCaseNumber(srId));
    }
  }, []);

  return (
    <MainContainer className="flex lg:p-4 p-0" showSidebar={true}>
      <div className="sidebar-width">
        <div className="max-w-[680px]">
          <div
            className={`sticky top-[52px] sm:top-[63px] right-0 z-10 ${
              isSticky ? "bg-white" : ""
            } w-full dark:bg-black-200`}
          >
            <Breadcrumb />
            <div className="pt-3 capitalize font-semibold flex items-center text-[22px] lg:text-[28px] dark:text-white">
              <BackButton />
              {DETAILS_LABLE.REQUEST_DETAILS}
            </div>
          </div>
          <div className=" pt-6 border-b border-lilac-light mb-4">
            <div className="text-lg font-semibold text-red-800 dark:text-white mb-1 flex flex-col lg:flex-row">
              {DETAILS_LABLE.REQUEST_SERVICE}
              <span className="hidden lg:inline px-1">|</span>
              <CopyToClipboard text={result.caseNumber} />
            </div>
            <p className="font-karla text-sm text-grey-500 dark:text-white mb-2">
              {DETAILS_LABLE.RAISED}
              {moment(result.caseCreatedAt, MOMENT_FORMATS.YYYYMMDD).format(
                MOMENT_FORMATS.DMMMYYY_WITH_TIME,
              )}
            </p>
          </div>
          <div className="rounded-lg bg-white p-3 flex flex-wrap">
            <div className="-m-2 w-full flex flex-wrap">
              <div className="w-full lg:w-1/3 p-2">
                <div className="text-sm text-red-800 font-semibold mb-1">
                  {DETAILS_LABLE.CATEGORY}
                </div>
                <div className="text-sm text-grey-500 font-karla">
                  {result.category}
                </div>
              </div>
              <div className="w-full lg:w-1/3 p-2">
                <div className="text-sm text-red-800 font-semibold mb-1">
                  {DETAILS_LABLE.PRODUCT}
                </div>
                <div className="text-sm text-grey-500 font-karla">
                  {result.productName}
                </div>
              </div>
              {"feedbacks" in result && result?.feedbacks.length > 0 && (
                <div className="w-full lg:w-1/3 p-2">
                  <div className="text-sm text-red-800 font-semibold mb-1">
                    {DETAILS_LABLE.QUERY}
                  </div>
                  {result?.feedbacks.map((feedback) => (
                    <div
                      key={feedback}
                      className="text-sm text-grey-500 font-karla"
                    >
                      {feedback}
                    </div>
                  ))}
                </div>
              )}
              <div className="w-full lg:w-1/3 p-2">
                <div className="text-sm text-red-800 font-semibold mb-1">
                  {DETAILS_LABLE.STATUS}
                </div>
                <div className="text-sm text-grey-500 font-karla">
                  {result.srStatus}
                </div>
              </div>
              <div className="w-full lg:w-1/3 p-2">
                <div className="text-sm text-red-800 font-semibold mb-1">
                  {DETAILS_LABLE.LAST_UPDATED}
                </div>
                <div className="text-sm text-grey-500 font-karla">
                  {moment(result.caseUpdatedAt, MOMENT_FORMATS.YYYYMMDD).format(
                    MOMENT_FORMATS.COMMA_SEPARATED_DATE_TIME,
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Sidebar customClasses="pt-[60px]" />
    </MainContainer>
  );
};

export default ServiceDetails;
