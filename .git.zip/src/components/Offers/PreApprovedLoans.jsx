import PropTypes from "prop-types";
import OffersCard from "./OffersCard";
import HandleDataRendering from "../Common/HandleDataRendering";
import Loader from "../Common/Loader";
import NoData from "../Common/NoData";
import { ERROR_MSG } from "../../const/common";

const PreApprovedLoans = ({
  offers,
  loading: offerLoading,
  error: offerError,
  offersDetails,
  loading: offersDetailsLoading,
  error: offersDetailsError,
}) => {
  if (offerLoading || offersDetailsLoading) return <Loader />;
  if (
    offersDetails?.code == "FAILURE" ||
    offers?.code == "FAILURE" ||
    offersDetailsError == true ||
    offerError == true
  )
    return (
      <p className="flex items-center justify-center">
        <NoData errorText={offers?.message || ERROR_MSG.API_ERROR} />
      </p>
    );
  const getHeader = (offer) => {
    let customOfferDetails = {};

    if (offer?.offer_sub_type === "pl-suvidha") {
      customOfferDetails.flatRate =
        offersDetails?.offerData[0]?.result?.defaultEligibleFlatRatePa;
      customOfferDetails.loanAmount =
        offersDetails?.offerData[0]?.result?.defaultEligibleAmount;
      customOfferDetails.emi = offersDetails?.offerData[0]?.result?.emiAmount;
      customOfferDetails.tenure =
        offersDetails?.offerData[0]?.result?.defaultEligibleTenure;
    } else if (offer?.offer_sub_type === "pl-lead") {
      customOfferDetails.flatRate =
        offersDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.default_interest_rate;
      customOfferDetails.loanAmount =
        offersDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.current_maximum_amount;
      customOfferDetails.emi =
        offersDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.maximumemi;
      customOfferDetails.tenure =
        offersDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.current_maximum_tenure;
    }

    let heading = "";
    offer?.header?.every((header) => {
      if (header.includes("offer_flat_rate")) {
        heading = header.replace(
          "offer_flat_rate",
          customOfferDetails.flatRate,
        );
        return true;
      } else if (header.includes("offer_amount")) {
        heading = header.replace("offer_amount", customOfferDetails.loanAmount);
        return true;
      } else if (header.includes("offer_tenure")) {
        heading = header.replace("offer_tenure", customOfferDetails.tenure);
        return true;
      }
    });
    return heading;
  };
  return (
    <HandleDataRendering
      data={offers}
      loading={offerLoading || offersDetailsLoading}
      error={offerError || offersDetailsError}
    >
      <div className="flex flex-wrap lg:flex-nowrap">
        {offers?.length === 0 ? (
          <div>No offers data available</div>
        ) : (
          offers?.map((offer) => {
            return (
              <div className="w-1/2 lg:1/3" key={offer.offer_id}>
                <OffersCard offer={offer} offerHeader={getHeader(offer)} />
              </div>
            );
          })
        )}
      </div>
    </HandleDataRendering>
  );
};
PreApprovedLoans.propTypes = {
  offers: PropTypes.array,
  loading: PropTypes.bool,
  offersDetails: PropTypes.object,
  error: PropTypes.bool,
};
export default PreApprovedLoans;
