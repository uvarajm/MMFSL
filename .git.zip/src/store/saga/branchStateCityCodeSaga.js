import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchPinCodeStatusData,
  fetchPinCodeDataSuccess,
  fetchPinCodeDataFailure,
} from "../slices/pinCodeStatusSlice";
import { BRANCH_STATE_CITY_CODE } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchBranchStateCityStatus({ payload }) {
  try {
    yield put(fetchPinCodeStatusData());

    const response = yield call(
      makeApiRequest,
      endpoints.branchStateCity,
      BACKEND_TOKEN,
      "POST",
      payload,
    );
    yield put(fetchPinCodeDataSuccess(response));
  } catch (error) {
    yield put(fetchPinCodeDataFailure(error.message));
  }
}
export function* watchFetchBranchStateCityStatus() {
  yield takeLatest(BRANCH_STATE_CITY_CODE, fetchBranchStateCityStatus);
}
