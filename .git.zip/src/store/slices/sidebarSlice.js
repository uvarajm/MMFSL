import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  open: true,
};

const sidebarSlice = createSlice({
  name: "SIDEBAR",
  initialState,
  reducers: {
    toggleSidebar: (state) => {
      state.open = true;
      // state.open = !state.open;
    },
  },
});

export const { toggleSidebar } = sidebarSlice.actions;

export default sidebarSlice.reducer;
