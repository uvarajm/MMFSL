export const MuiTheme = (theme, lightColor, darkColor) =>
  theme === "light" ? lightColor : darkColor;
