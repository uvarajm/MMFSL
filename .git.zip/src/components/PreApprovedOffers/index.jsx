import "./preApprovedOffers.css";

const PreApprovedOffers = () => {
  return (
    <section className="flex justify-center items-center gap-4 my-4 w-full">
      <div className="offer">Offer 1</div>
      <div className="offer">Offer 2</div>
    </section>
  );
};

export default PreApprovedOffers;
