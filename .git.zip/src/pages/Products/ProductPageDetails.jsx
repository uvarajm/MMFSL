import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import PropTypes from "prop-types";
const ProductPageDetails = ({
  renderTabContent,
  productDetails,
  defaultActiveTab,
  showBeforeLogin,
  isHeaderSticky = "",
  stickyValue = "",
  headerStyle = "",
}) => {
  const { loginStatus } = useSelector((state) => state.login);
  const [activeTab, setActiveTab] = useState(defaultActiveTab);
  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > stickyValue) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return (
    <div className={`content-section w-full`}>
      <div className={` py-4 headline headline_md headline_primary `}>
        {productDetails.PAGE_TITLE}
      </div>
      <div
        className={`flex flex-col lg:flex-row ${!loginStatus ? "pt-4" : ""}`}
      >
        <div className={`explore-width w-full `}>
          {loginStatus || showBeforeLogin ? (
            <div
              className={`flex lg:mb-6 mb-4 border-b shadow-custom-primary overflow-x-auto border-light-border-color dark:border-dark-border-color ${headerStyle} ${
                isHeaderSticky
                  ? `sticky top-[50px] lg:top-[65px] ${isSticky ? "bg-white" : ""}`
                  : ""
              }`}
            >
              {productDetails.PRODUCT_TABS.map((tab, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTab(tab)}
                  className={`p-4 first:pl-0 text-sm relative flex-shrink-0 ${
                    activeTab === tab
                      ? "text-red-500 font-bold dark:text-white"
                      : "text-light-text-primary  dark:text-white"
                  }`}
                >
                  {tab}
                  {activeTab === tab && (
                    <div
                      className={`rounded-se-full rounded-ss-full active-border bg- h-[3px] bg-red-500 absolute right-[16px] bottom-0 ${
                        index === 0 ? "left-0" : "left-[16px]"
                      }`}
                    ></div>
                  )}
                </button>
              ))}
            </div>
          ) : null}
          <div className="flex flex-wrap w-full">
            {renderTabContent(activeTab)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPageDetails;

ProductPageDetails.propTypes = {
  renderTabContent: PropTypes.oneOfType([PropTypes.node, PropTypes.func]),
  productDetails: PropTypes.object,
  defaultActiveTab: PropTypes.string,
  showBeforeLogin: PropTypes.bool,
  isHeaderSticky: PropTypes.bool,
  stickyValue: PropTypes.number,
  headerStyle: PropTypes.string,
};
