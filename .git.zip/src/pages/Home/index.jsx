import { MainContainer } from "../../components";

const Home = () => {
  return (
    <MainContainer>
      {/* <Loader /> */}
      <div
        className={`border-light-border-color text-light-text-primary light-theme-color dark:border-dark-border-color dark:text-white`}
      ></div>
    </MainContainer>
  );
};

export default Home;
