import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import SvgIcon from "../Common/SvgIcon";
import iconConfig from "../../assets/iconsConfig";

const { Search } = iconConfig;

const RecentSearches = ({ savedResults }) => (
  <div className="">
    <div className="header__search_title">Recent</div>
    <ul className="header__search_saved_lists">
      {savedResults.map((result, index) => (
        <li key={index} className="list__item">
          <Link to={result.url} className="flex items-center justify-between">
            {result.title}
            <SvgIcon url={Search} className="w-4 h-4" />
          </Link>
        </li>
      ))}
    </ul>
  </div>
);

RecentSearches.propTypes = {
  savedResults: PropTypes.array.isRequired,
};

export default RecentSearches;
