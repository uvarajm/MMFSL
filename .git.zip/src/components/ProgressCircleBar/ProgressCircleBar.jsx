import PropTypes from "prop-types";

const ProgressCircleBar = ({ progress }) => {
  const radius = 45;
  const strokeWidth = 10;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  // Calculate the stage number (e.g., 1/4)
  const stage = `${Math.ceil((progress / 100) * 4)}/4`;
  return (
    <div className="relative w-24 h-24 m-10">
      <svg
        className="absolute w-full h-full"
        viewBox="0 0 100 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          className="stroke-current text-lilac-light"
          stroke="#d2d6dc"
          strokeWidth={strokeWidth}
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
        />
        <circle
          className="stroke-current text-lilac-dark"
          stroke="#3b82f6"
          strokeWidth={strokeWidth}
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: strokeDashoffset,
          }}
        />
        <text
          className="text-center text-gray-600"
          x="50"
          y="50"
          dominantBaseline="middle"
          textAnchor="middle"
        >
          {stage}
        </text>
      </svg>
    </div>
  );
};

ProgressCircleBar.propTypes = {
  progress: PropTypes.number,
};

export default ProgressCircleBar;
