import { useEffect, useState } from "react";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import { Link, useNavigate } from "react-router-dom";
import { Container, Button, CheckBox, Input, Modal } from "../../components";
import { useDispatch, useSelector } from "react-redux";
import BackButton from "../../components/Common/BackButton";
import {
  setMobileNumber,
  setTermsCondition,
} from "../../store/slices/registerSlice";
import { REGISTER_USER } from "../../store/actions/actions";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import {
  mobileNumberValidation,
  termsAndConditionsValidation,
} from "../../utils/validation";
import { COMMON_HEADING_LABEL } from "../../const/common";

const initialValues = {
  mobileNumber: "",
  termsAndCondition: false,
  whatsappSms: false,
};

const validationSchema = Yup.object().shape({
  mobileNumber: mobileNumberValidation("Enter mobile number"),
  termsAndCondition: termsAndConditionsValidation("Accept terms"),
  whatsappSms: termsAndConditionsValidation("Whatsapp consent"),
});

const Register = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [whatsappSmsConcent, setWhatsappSmsConcent] = useState(false);
  const [isOpen, setOpen] = useState(false);
  const { registerUser, loading, error } = useSelector(
    (state) => state.register,
  );

  const onCloseModal = () => {
    setOpen(!isOpen);
    setTermsAccepted(true);
  };

  const onSubmit = (values) => {
    const data = {
      mobileNumber: values?.mobileNumber,
      otpResend: false,
      source: "web",
      journey: "REGISTRATION",
      tncFlag: Number(values?.termsAndCondition),
    };

    dispatch(setMobileNumber(values.mobileNumber));
    dispatch(setTermsCondition(Number(values?.termsAndCondition)));
    dispatch({ type: REGISTER_USER, payload: data });
  };

  useEffect(() => {
    if (registerUser && registerUser?.code === "SUCCESS") {
      navigate("/register/get-otp");
    }
  }, [navigate, registerUser]);
  return (
    <Container className="px-4">
      <HandleDataRendering data={registerUser} loading={loading} error={error}>
        <div className="w-full minHeight flex justify-center items-center">
          <div className="flex flex-col justify-between w-[400px]">
            <div className="flex lg:block mt-12 lg:mt-0 pb-4">
              <BackButton />
              <p className=" text-red-800 headline headline_md lg:leading-10  leading-6 lg:pt-4">
                {COMMON_HEADING_LABEL?.label}
              </p>
            </div>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="flex flex-col justify-between">
                  <div className="relative">
                    <Input
                      type="number"
                      name="mobileNumber"
                      label="Mobile number"
                      placeholder="Mobile number"
                      inputClassName="px-3 pl-3"
                      formik={formik}
                    />
                    <div className="absolute left-0 top-[28px] text-grey-500 content content_xl leading-[22px]">
                      +91
                    </div>
                  </div>

                  <div className="flex items-center pt-[15px]">
                    <CheckBox
                      onClick={onCloseModal}
                      name="termsAndCondition"
                      checked={termsAccepted}
                      onChange={() => {
                        const newTermsAccepted = !termsAccepted;
                        setTermsAccepted(newTermsAccepted);
                        formik.setFieldValue(
                          "termsAndCondition",
                          newTermsAccepted,
                        );
                      }}
                    />
                    <div
                      onClick={onCloseModal}
                      className="text-grey-500 leading-4 content content_md cursor-pointer"
                    >
                      I’ve read through and accept the Terms and Conditions
                    </div>
                  </div>
                  <div className="inline sm:flex items-center pt-[13px]">
                    <CheckBox
                      label="I consent to communication sent to me via WhatsApp"
                      name="termsAndCondition"
                      checked={whatsappSmsConcent}
                      onChange={() => {
                        const newWhatsappSms = !whatsappSmsConcent;
                        setWhatsappSmsConcent(newWhatsappSms);
                        formik.setFieldValue("whatsappSms", newWhatsappSms);
                      }}
                      className="text-base text-grey-500"
                    />
                  </div>

                  {registerUser?.code === "FAILURE" && (
                    <p className="bg-white w-full rounded-lg text-grey-500 my-10 text-xs font-normal font-karla p-2">
                      {registerUser?.message}
                    </p>
                  )}
                  <div
                    className={`flex justify-center w-full lg:mt-0 ${
                      registerUser?.code === "FAILURE" ? "mt-7" : "mt-36 pt-14"
                    } mt-36 pt-14`}
                  >
                    <Button
                      type="submit"
                      name="Get OTP"
                      disabled={
                        !(formik.isValid && formik.dirty) ||
                        !formik.values.mobileNumber ||
                        !formik.values.termsAndCondition
                      }
                      className="hover:opacity-85 w-full rounded-lg gap-2 font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark  disabled:text-lilac-dark dark:bg-red-500 dark:text-white dark:disabled:bg-grey-900 dark:disabled:text-grey-100"
                    />
                  </div>
                </Form>
              )}
            </Formik>
            <p className="flex items-center py-4 text-grey-500 label label_md pt-10">
              Already registered with us ? &nbsp;
              <Link
                to="/login"
                className="flex justify-center text-red-500 label label_md"
              >
                Login
              </Link>
            </p>
          </div>
        </div>

        <Modal
          isOpen={isOpen}
          onClose={onCloseModal}
          className="modal-content rounded-lg"
        >
          <div className="lg:w-full flex flex-col justify-center items-center overflow-hidden  p-[14px] w-[300px] h-[470px] relative">
            <div className="max-h-[450px]  mb-4">
              <div className="text-red-900 font-bold text-[24px] mt-[6px] mb-[12px]">
                Terms and Condition
              </div>

              <div className="lg:w-[616px]">
                <p className="text-sm font-bold ">1. Policy statement</p>
                <div
                  className="overflow-y-scroll max-h-[280px] scrollbar-webkit moz-scrollbar webkit-scrollbar-thumb webkit-scrollbar-button moz-scrollbar moz-scrollbar-thumb
  }, webkit-scrollbar scrollbar-thin"
                >
                  <div className="font-karla text-black-100  text-[16px] mb-[12px] mt-[12px]">
                    Mahindra and Mahindra Financial Services Limited
                    <strong> (the ‘Company’ or ‘MMFSL’)</strong> practices a{" "}
                    <strong>zero-tolerance</strong> approach to bribery and
                    corruption and is committed to act professionally and fairly
                    in all its business dealings and relationships and in
                    implementing and enforcing effective systems to counter
                    bribery and corruption in any form.
                  </div>
                  <div className="font-karla text-black-100 text-[16px]">
                    MMFSL mandates compliance with all applicable anti-bribery
                    and anti-corruption laws in all markets and jurisdictions in
                    which it operates. Bribery is a serious criminal offence in
                    jurisdictions in which the Company operates, including India
                    (Prevention of Corruption Act, 1988, Indian Penal Code,
                    1860, etc.), the United Kingdom (UK Bribery Act, 2010), the
                    United States of America (Foreign Corrupt Practices Act,
                    1977) and other applicable laws where bribery offences can
                    result in the imposition of severe fines and/or custodial
                    sentences, exclusion from tendering for public contracts and
                    severe reputational damage.
                  </div>
                  <div className="font-karla text-black-100 text-[16px] mb-[24px] mt-[12px]">
                    Whoever we, as a Company or as individuals, may deal with,
                    and wherever we may
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-center mt-auto w-[308px] h-[42px]">
              <Button
                name="I agree"
                onClick={onCloseModal}
                className="w-full hover:opacity-85 rounded-lg gap-2 leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
              >
                I agree
              </Button>
            </div>
          </div>
        </Modal>
      </HandleDataRendering>
    </Container>
  );
};
export default Register;
