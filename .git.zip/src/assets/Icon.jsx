import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import iconConfig from "./iconsConfig";

const Icon = ({
  name,
  size = 24,
  color = "#E31837",
  className = "",
  triggerEvent,
  areYouSure,
}) => {
  const [svgContent, setSvgContent] = useState(null);

  useEffect(() => {
    const fetchSvg = async () => {
      try {
        const response = await fetch(window.location.origin + iconConfig[name]);
        let text = await response.text();

        const parser = new DOMParser();
        const svgDoc = parser.parseFromString(text, "image/svg+xml");
        const svgElement = svgDoc.querySelector("svg");

        if (svgElement) {
          svgElement.setAttribute("fill", color);
          svgElement.setAttribute("width", "100%");
          svgElement.setAttribute("height", "100%");
        }
        const pathElements = svgDoc.querySelectorAll("path");

        if (pathElements) {
          pathElements.forEach((path) => {
            path.setAttribute("fill", `${color}`);
            path;
            path.setAttribute("height", "auto");
          });
        }

        text = new XMLSerializer().serializeToString(svgDoc);
        setSvgContent(text);
      } catch (error) {
        console.error("Error fetching SVG:", error);
      }
    };

    fetchSvg();
  }, [name, color]);

  const handleTriggerEvent = () => {
    triggerEvent(false);
  };

  if (!svgContent) {
    return null;
  }

  return (
    <div
      className={className}
      onClick={areYouSure ? handleTriggerEvent : undefined}
      style={{ width: size, height: size }}
      dangerouslySetInnerHTML={{ __html: svgContent }}
    />
  );
};

Icon.propTypes = {
  name: PropTypes.string,
  size: PropTypes.number,
  color: PropTypes.string,
  className: PropTypes.string,
  triggerEvent: PropTypes.func,
  areYouSure: PropTypes.bool,
};

export default Icon;
