import { Button, Container } from "../../components";
import iconConfig from "../../assets/iconsConfig";
import { useNavigate } from "react-router-dom";

const LeadGenSuccess = () => {
  const navigate = useNavigate();
  const onClickExploreProducts = () => {
    navigate(`../product`);
  };
  return (
    <Container className="px-4">
      <div className="w-full minHeight flex justify-center items-center">
        <div className="flex flex-col justify-between gap-12 w-[400px]">
          <div className="flex-1 mb-8">
            <div>
              <img
                className="h-8 w-80 lg:h-54 lg:w-6"
                src={window.location.origin + iconConfig.happyFace}
              />
            </div>
            <div className="flex items-center mb-8 lg:block">
              <p className="lg:text-[32px] font-bold tracking-wide leading-10 font-quicksand text-xl">
                Thank you for your intrest!
              </p>
            </div>
            <div className="flex items-center mb-8 bg-white lg:block">
              <p className="lg:text-[12px] tracking-wide leading-10 text-black-100 font-quicksand text-xl">
                We will get back to you shortly
              </p>
            </div>
            <div>
              <Button
                name="Explore Products"
                className="hover:opacity-85 w-full rounded-lg gap-8 mb-8 font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
                onClick={() => onClickExploreProducts()}
              />
            </div>
          </div>
        </div>
      </div>
    </Container>
  );
};

export default LeadGenSuccess;
