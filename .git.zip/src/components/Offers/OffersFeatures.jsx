import FeatureList from "../Common/FeaturesList";
import ThreeColDetails from "../Common/ThreeColDetails";
import PropTypes from "prop-types";
const OffersFeatures = ({ offerDetails, features }) => {
  return (
    <div>
      <ThreeColDetails data={offerDetails} />
      <FeatureList features={features} staticTitle={"About this loan"} />
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut in facilisis
        ex. Pellentesque vel euismod risus. Aenean mattis malesuada nisl, sit
        amet bibendum neque condimentum eu. Integer non auctor ante. Duis
        ullamcorper nec quam vel pulvinar. Aliquam at fermentum massa. Fusce ac
        elementum sapien. Curabitur semper leo non ipsum bibendum ultrices.
        Fusce eget placerat nulla. Vestibulum congue venenatis enim, id lobortis
        eros commodo a. Duis fermentum nisi a est bibendum congue. Sed pharetra,
        ipsum vel semper sodales, nibh eros pulvinar tellus, ut venenatis mi
        turpis et nibh. Vestibulum risus nisi, auctor ultricies vulputate eget,
        porttitor non ipsum. Nam porttitor aliquam fermentum. Quisque eu nibh
        sed velit auctor vehicula. Nam vulputate ligula diam, ut tincidunt nulla
        convallis porttitor. Curabitur nec orci sodales, feugiat mi et, cursus
        urna. Donec efficitur tincidunt fermentum. Mauris aliquam enim mi,
        placerat dignissim tortor feugiat feugiat. Nam eu ornare augue, quis
        luctus diam. Suspendisse tristique nec eros nec vulputate. Sed et
        dapibus diam. Sed bibendum metus sit amet tincidunt gravida. Vivamus
        fermentum velit eu est pretium, in porta eros mattis. Ut ac nibh eu dui
        euismod malesuada eu nec nunc. Nullam sagittis nisl id orci interdum
        bibendum. Nunc finibus velit tellus, vitae maximus libero cursus non.
        Sed volutpat neque diam, eu ornare diam congue in. In venenatis aliquet
        elit, nec sagittis dolor posuere pulvinar. Praesent sed laoreet ex.
        Donec nibh massa, imperdiet gravida ante at, auctor sagittis justo.
        Etiam nulla sapien, auctor quis varius eu, finibus id lacus. Quisque
        convallis pretium lectus a scelerisque. Etiam at condimentum risus.
        Donec eleifend sed arcu ut sodales. Ut erat turpis, semper vel varius
        eget, finibus sed felis. Nulla convallis magna in augue tincidunt, ac
        hendrerit magna egestas. Integer viverra massa sit amet pellentesque
        consectetur. Fusce a mi tempor, ullamcorper odio eget, molestie risus.
        Proin sagittis sapien neque, eget vulputate purus iaculis et.
        Pellentesque in imperdiet ipsum. Quisque lobortis porttitor dignissim.
        Nunc sollicitudin pharetra consectetur. Aliquam erat volutpat. Nam
        tempor varius massa rutrum viverra. Sed non blandit lectus, eget
        ullamcorper nulla. Donec varius tincidunt massa vel porttitor.
        Suspendisse non velit nec neque malesuada volutpat quis vel magna. Morbi
        efficitur orci at metus ultrices venenatis a id tortor. Morbi vehicula
        sollicitudin nibh vel mollis. Nullam maximus, leo nec rutrum fermentum,
        mi mi ullamcorper lacus, ac lacinia orci diam quis velit. Fusce enim
        lacus, ornare sed mauris quis, commodo varius erat. Etiam purus nunc,
        tristique at ante a, sollicitudin posuere nisl. Sed eget nunc at massa
        faucibus suscipit. Suspendisse rhoncus, elit facilisis sollicitudin
        venenatis, neque nibh iaculis eros, a porttitor erat arcu nec purus.
        Nunc id ante sed dolor tristique tempus vitae in sem. Fusce tempor
        elementum blandit. Etiam a turpis eget est elementum imperdiet. Sed
        nulla elit, tincidunt laoreet ullamcorper in, sagittis nec eros. Proin
        elit augue, faucibus ut dapibus eget, finibus nec odio. Nunc vel nunc in
        justo faucibus ultrices. Etiam vitae ipsum congue, laoreet elit vel,
        varius nisi. Praesent quis mauris aliquet, facilisis dolor et, interdum
        justo. Cras sed arcu malesuada, consectetur justo non, imperdiet arcu.
        Mauris sagittis, nulla ut auctor volutpat, sapien orci semper ligula,
        dictum consectetur nibh dui vel nulla. Donec aliquam varius lacus ut
        ultricies. Cras ut odio eu ligula sollicitudin maximus eget semper ex.
        Vestibulum ultrices mauris neque, sed finibus orci sollicitudin nec.
        Donec accumsan tellus eu quam sagittis, a suscipit augue auctor. Ut et
        ligula nec ante tincidunt tincidunt. Nulla sed sapien erat. Suspendisse
        semper sed quam nec auctor. Duis quis tellus sit amet erat rhoncus
        dictum. Nam eu nulla eget ante convallis sollicitudin. Duis eleifend non
        nisi rutrum posuere. Mauris fringilla sollicitudin risus, ac facilisis
        purus aliquam ac. Curabitur sodales elementum tempor. Vestibulum
        hendrerit ultrices nisl, non ornare libero. Pellentesque sit amet urna a
        enim interdum luctus. Nunc sit amet tellus justo. Ut in commodo ligula.
        Mauris placerat faucibus rhoncus. Donec varius, justo in venenatis
        gravida, libero diam elementum leo, eu auctor nulla nisl in diam.
        Integer interdum vitae ligula id eleifend. Aliquam vel nulla suscipit,
        malesuada magna et, aliquam lacus. Suspendisse aliquam cursus purus a
        rutrum. Ut efficitur, urna vitae gravida bibendum, dui arcu pretium
        ligula, quis malesuada turpis est accumsan eros. Sed at arcu eget lectus
        ornare lacinia sit amet vitae odio. Duis interdum vulputate auctor.
        Nulla facilisi. Ut dictum accumsan ligula in pulvinar. Ut in nibh velit.
        Proin a velit massa. Aliquam sollicitudin, lorem at interdum rhoncus,
        lectus nisl semper neque, ut consectetur ligula ante non ipsum. Duis
        rutrum velit vel nisi scelerisque vestibulum. Donec elementum tortor vel
        sapien placerat dignissim. Integer in lorem libero. Orci varius natoque
        penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam
        dapibus facilisis nisl vel pharetra. Phasellus quam justo, semper id
        tempor sit amet, pulvinar in quam. Aliquam ultrices sodales lacus eget
        tincidunt. Nullam sit amet enim accumsan, placerat orci a, gravida
        massa. Aliquam nec congue eros, nec tempor nulla. Ut finibus turpis a
        sapien porttitor euismod. Suspendisse malesuada lacus id molestie
        posuere. Cras semper mauris eget est luctus rhoncus. Cras maximus arcu
        eget sem interdum dictum. Donec laoreet eleifend accumsan. Integer vel
        dictum risus, sit amet fringilla massa. Pellentesque interdum dui quis
        nibh gravida, sed hendrerit neque ultricies. In eu aliquet eros. Nunc
        sollicitudin ante eu vulputate ultrices. Quisque imperdiet turpis a
        suscipit vehicula. Maecenas consectetur eros sed orci posuere, nec
        tempus lectus vestibulum. Integer facilisis finibus nulla et efficitur.
        In non efficitur arcu. Ut tortor sapien, interdum eu libero consequat,
        accumsan varius mauris. Cras lectus odio, vehicula at turpis eu, feugiat
        vulputate eros. Nulla vel urna nisi. Donec vel mauris mollis, semper sem
        id, scelerisque nibh. Fusce porttitor blandit augue. Aliquam erat
        volutpat. Suspendisse blandit hendrerit luctus. Donec pharetra elit in
        nunc eleifend, eu faucibus ipsum egestas. Praesent ut feugiat dolor, a
        porta nulla. Curabitur imperdiet risus sed iaculis suscipit. Nullam non
        turpis a turpis congue auctor sit amet ac ipsum. In malesuada sit amet
        erat sed ullamcorper. Vivamus rutrum diam sed placerat mattis. Nunc
        porta justo at pulvinar imperdiet. Morbi sed ultricies lacus. Sed
        imperdiet, erat vitae porta mollis, odio urna dictum tellus, vel
        condimentum lacus metus a nibh. Nunc mauris nibh, pretium eget erat non,
        interdum blandit nibh. Nulla accumsan neque at enim placerat, facilisis
        accumsan magna dapibus. Nullam et erat laoreet, sagittis dui eget,
        bibendum lacus. Duis egestas augue ac tortor sodales finibus. Nullam
        massa lectus, blandit ac est nec, cursus gravida nisi. Nullam venenatis
        interdum porttitor. Nam sed nulla eros. Pellentesque at libero eu enim
        vehicula laoreet. Vestibulum ante ipsum primis in faucibus orci luctus
        et ultrices posuere cubilia curae; Aliquam ac quam at tellus eleifend
        auctor. Proin iaculis odio nisi, at volutpat arcu facilisis non. Nunc
        nec porta lectus. Sed eget arcu sit amet odio tincidunt pellentesque vel
        vitae neque. Suspendisse in urna justo. Vivamus molestie neque in lacus
        semper lobortis. Morbi posuere, mi ornare euismod sollicitudin, enim
        lacus blandit eros, ut volutpat arcu lectus quis libero. Mauris magna
        tellus, malesuada vitae dui sed, dapibus eleifend ligula. Suspendisse
        sed porta augue, in tempus sapien. Vestibulum ac lectus non lacus
        facilisis efficitur rutrum non dolor. Pellentesque tincidunt sed magna
        at congue. Vivamus sit amet risus lacus. Pellentesque blandit dui vel
        tellus facilisis, ac luctus lorem pretium. Interdum et malesuada fames
        ac ante ipsum primis in faucibus. Aliquam tempor lectus posuere,
        bibendum neque sed, condimentum tellus.
      </p>
    </div>
  );
};

OffersFeatures.propTypes = {
  offerDetails: PropTypes.object,
  features: PropTypes.object,
};
export default OffersFeatures;
