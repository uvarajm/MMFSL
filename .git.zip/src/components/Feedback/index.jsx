import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { endpoints, makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import Modal from "../Modal";
import { FEEDBACK } from "../../const/common";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../Common/SvgIcon";
import "./feedback.scss";
import { useSelector } from "react-redux";

const { Unhappy, UnhappyRed, OkayRed, Okay, HappyRed, Happy, CloseModal } =
  iconConfig;

const Feedback = () => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(true);
  const [rating, setRating] = useState("");
  const [feedbackText, setFeedbackText] = useState("");
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const textareaRef = useRef(null);
  const [height, setHeight] = useState(30);
  const { superAppId } = useSelector((state) => state.login);
  const ratingResponse = {
    UNHAPPY: "unhappy",
    HAPPY: "happy",
    OKAY: "okay",
  };

  const ratingOptions = [
    {
      value: ratingResponse.UNHAPPY,
      icon: Unhappy,
      activeIcon: UnhappyRed,
      label: FEEDBACK.UNHAPPY,
    },
    {
      value: ratingResponse.OKAY,
      icon: Okay,
      activeIcon: OkayRed,
      label: FEEDBACK.OK,
    },
    {
      value: ratingResponse.HAPPY,
      icon: Happy,
      activeIcon: HappyRed,
      label: FEEDBACK.HAPPY,
    },
  ];

  const handleRatingChange = (event) => {
    setRating(event.target.value);
  };

  const handleInput = () => {
    const newHeight = textareaRef.current.scrollHeight;
    setHeight(newHeight);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = {
      superAppId: superAppId,
      feature: "payment",
      rating: FEEDBACK[rating] || 0,
      comment: feedbackText,
    };

    try {
      const response = await makeApiRequest(
        endpoints.rateUs,
        BACKEND_TOKEN,
        "POST",
        data,
      );
      if (response.code === "SUCCESS") {
        setShowSuccessPopup(true);
      } else {
        setShowSuccessPopup(false);
      }
      setIsModalOpen(false);
    } catch (error) {
      console.error("Error saving feedback:", error);
    }
  };

  const closeSuccessPopup = () => {
    setShowSuccessPopup(false);
    navigate("/");
  };

  return (
    <>
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        className="rounded-lg lg:w-[480px]"
      >
        <div onClick={(e) => e.stopPropagation()} className="p-6">
          <div className="modal-container">
            <div className="">
              <p className="modal-container_para headline headline_sm headline_primary dark:text-red-800">
                {FEEDBACK.INTRO}
              </p>
              <p className="title title_lg title_primary-dark">
                {FEEDBACK.PLEASE_RATE}
              </p>
            </div>
            <button
              onClick={() => setIsModalOpen(false)}
              className="modal-container_button shrink-0"
            >
              <SvgIcon url={CloseModal} className="h-[14px] w-[14px] block" />
            </button>
          </div>
          <div className="smiley-container">
            <div className="smiley-container-box">
              {ratingOptions.map((option) => (
                <label
                  key={option.value}
                  className="smiley-container-box_labels"
                >
                  <input
                    type="radio"
                    value={option.value}
                    checked={rating === option.value}
                    onChange={handleRatingChange}
                    className="hidden"
                  />
                  <div className="cursor-pointer">
                    <SvgIcon
                      url={
                        rating === option.value
                          ? option.activeIcon
                          : option.icon
                      }
                      className={`cursor-pointer block ${
                        rating && rating !== option.value
                          ? "opacity-50 transform scale-75"
                          : ""
                      }`}
                    />
                    <p
                      className={`text-xs text-grey-200 font-medium cursor-pointer text-center ${
                        rating && rating !== option.value
                          ? "opacity-50 transform"
                          : "text-grey-500"
                      }`}
                    >
                      {option.label}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>
          <form onSubmit={handleSubmit}>
            {rating && (
              <div className="mt-6">
                <label className="feedback-label">
                  {FEEDBACK.YOUR_FEEDBACK}
                </label>
                <textarea
                  ref={textareaRef}
                  className="custom-textarea"
                  style={{ height: `${height}px` }}
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  onInput={handleInput}
                ></textarea>
              </div>
            )}
            <div className="flex justify-center items-center mt-12">
              <button
                type="submit"
                disabled={!rating}
                className={`cursor-pointer max-w-[132px] lg:max-w-[308px] w-full text-sm font-bold p-[11px] rounded-lg transition disabled:bg-disable-red disabled:text-red-200 bg-red-500 text-white`}
              >
                {FEEDBACK.SUBMIT}
              </button>
            </div>
          </form>
        </div>
      </Modal>
      <Modal
        className="rounded-lg overflow-hidden max-w-[480px] w-full"
        isOpen={showSuccessPopup}
        onClose={closeSuccessPopup}
      >
        <div className="success-container">
          <p className="success-container_feedback-text">
            {FEEDBACK.THANK_YOU}
          </p>
          <p className="success-container_input-text">{FEEDBACK.YOUR_INPUT}</p>
          <button
            className="success-container_button"
            onClick={closeSuccessPopup}
          >
            {FEEDBACK.DONE}
          </button>
        </div>
      </Modal>
    </>
  );
};

export default Feedback;
