import { useState } from "react";
import ReactPlayer from "react-player";
import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import Card from "../../components/Card";
import iconConfig from "../../assets/iconsConfig";
import Modal from "../../components/Modal";
import FetchDynamicImage from "../../components/Common/FetchDynamicImage";
import { truncateText } from "../../utils/commonUtils";
import NoData from "../../components/Common/NoData";
import { FAQ_TYPE_URL } from "../../const/ProductConst";

const { play_circle } = iconConfig;

const HowToFaq = ({ howToFaqData, loading, error }) => {
  const [viewAll, setViewAll] = useState(false);
  const navigation = useNavigate();
  const [selectedVideo, setSelectedVideo] = useState(null);

  const closeModal = () => {
    setSelectedVideo(null);
  };
  const handleOnClick = (header) => {
    setViewAll(true);
    const productTitle = header.toLowerCase().split(" ").join("-");
    navigation(`/faqs/${FAQ_TYPE_URL}/${productTitle.toLowerCase()}`);
  };
  if (!howToFaqData) {
    return <NoData errorText="FAQ not Exist" />;
  }
  return (
    <HandleDataRendering data={howToFaqData} loading={loading} error={error}>
      <div className="w-full">
        {!howToFaqData?.length === 0
          ? "Video Not Available"
          : howToFaqData.map((howToItem, index) =>
              howToItem.video_types.map((type) => (
                <section key={`${index}-${type.id}`}>
                  <div className="flex justify-between">
                    <h4 className="subtitle">{type.header}</h4>
                    {!viewAll && type.videos.length > 1 && (
                      <button
                        className="mt-4 font-quicksand text-xs text-red-500 font-semibold"
                        onClick={() => handleOnClick(type.header)}
                      >
                        View all
                      </button>
                    )}
                  </div>
                  <div className="rounded p-2 pb-0 lg:p-4">
                    <Card className="!bg-transparent">
                      <div className="flex flex-wrap gap-3">
                        {(viewAll ? type.videos : type.videos.slice(0, 4)).map(
                          (video, idx) => (
                            <div
                              key={`${index}-${type.id}-${video.id || idx}`}
                              className="relative flex flex-col my-2 p-2 bg-lilac-light rounded-lg"
                            >
                              <div className="relative w-[148px] h-88">
                                <FetchDynamicImage
                                  src={video.thumbnail}
                                  alt={video.title}
                                ></FetchDynamicImage>
                                <img
                                  src={play_circle}
                                  alt="Play Icon"
                                  className="absolute inset-0 w-10 h-10 m-auto cursor-pointer"
                                  onClick={() => setSelectedVideo(video)}
                                />
                              </div>
                              <div className="font-quicksand text-xs text-red-800 font-semibold p-2">
                                {truncateText(video.sub_title, 25)}
                              </div>
                            </div>
                          ),
                        )}
                      </div>
                    </Card>
                  </div>
                </section>
              )),
            )}
      </div>

      <Modal
        isOpen={!!selectedVideo}
        className="rounded-lg md:max-w-[696px] w-full"
        onClose={closeModal}
      >
        <div className="w-full h-auto md:w-[696px] md:h-[485px] bg-white rounded-lg">
          {selectedVideo && (
            <>
              <ReactPlayer
                url={selectedVideo.video_url}
                width="100%"
                height="80%"
                controls={true}
                playing={true} // auto-play when modal opens
                style={{ borderRadius: "8px" }}
              />
              <div className="mt-3 ml-3">
                <h4 className="font-quicksand text-[22px] font-semibold text-red-800">
                  {selectedVideo.title}
                </h4>
                <p className="font-karla text-xs text-grey-500">
                  {selectedVideo.description}
                </p>
              </div>
            </>
          )}
        </div>
      </Modal>
    </HandleDataRendering>
  );
};

export default HowToFaq;
HowToFaq.propTypes = {
  howToFaqData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  loading: PropTypes.bool,
  error: PropTypes.object,
};
