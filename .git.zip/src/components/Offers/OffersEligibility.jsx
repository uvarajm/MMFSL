import PropTypes from "prop-types";

const OffersEligibility = ({ eligibilityList, title }) => {
  return (
    <div>
      <h1>{title}</h1>
      {eligibilityList.map((item, i) => (
        <p key={i}>{item}</p>
      ))}
    </div>
  );
};
OffersEligibility.propTypes = {
  eligibilityList: PropTypes.array,
  title: PropTypes.string,
};
export default OffersEligibility;
