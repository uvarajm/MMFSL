import PropTypes from "prop-types";
import { useState } from "react";
const RangeSelectorBar = ({ defaultValue, onChange, slots }) => {
  const [value, setValue] = useState(defaultValue);

  const handleChange = (event) => {
    const newValue = parseInt(event.target.value);
    setValue(newValue);
    onChange(newValue);
  };

  return (
    <div className="mt-4 relative">
      <input
        type="range"
        min={defaultValue}
        max={Math.max(...slots)}
        step={3}
        value={value}
        onChange={handleChange}
        className="slider appearance-none h-6 w-full lilacLight rounded-full outline-none"
      />
      <div className="flex justify-between mt-1">
        {slots.map((slot, index) => (
          <div
            key={index}
            className="absolute top-1.5 transform -translate-x-1/2 bg-button-bg-red h-1"
            style={{
              left: `${
                ((slot - defaultValue) / (Math.max(...slots) - defaultValue)) *
                100
              }%`,
              width: "2px",
            }}
          />
        ))}
      </div>
      <div className="flex justify-between mt-[-10] text-sm text-gray-600">
        {slots.map((slot, index) => (
          <div
            key={index}
            className="absolute left-0"
            style={{
              left: `${
                ((slot - defaultValue) / (Math.max(...slots) - defaultValue)) *
                100
              }%`,
              marginLeft: "-8px",
              marginTop: "0",
            }}
          >
            {slot}
          </div>
        ))}
      </div>
    </div>
  );
};

RangeSelectorBar.propTypes = {
  defaultValue: PropTypes.number,
  onChange: PropTypes.func,
  slots: PropTypes.array,
};

export default RangeSelectorBar;
