import { createSlice } from "@reduxjs/toolkit";
import { OFFERS } from "../actions/actions";
const initialState = {
  offers: {},
  loading: false,
  error: null,
};

const offersSlice = createSlice({
  name: OFFERS,
  initialState,
  reducers: {
    fetchOffers(state) {
      state.loading = true;
      state.error = null;
    },
    fetchOffersSuccess(state, action) {
      state.loading = false;
      state.offers = action.payload;
    },
    fetchOffersFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const { fetchOffers, fetchOffersSuccess, fetchOffersFailure } =
  offersSlice.actions;

export default offersSlice.reducer;
