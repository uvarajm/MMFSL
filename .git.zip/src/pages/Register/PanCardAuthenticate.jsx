import { Container } from "../../components";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { Input, Button, Alert, CheckBox } from "../../components";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import BackButton from "../../components/Common/BackButton";
import {
  termsAndConditionsValidation,
  validation,
} from "../../utils/validation";
import { REGISTRATION } from "../../const/common";
import { PAN_ACCOUNT_USER } from "../../store/actions/actions";
import HandleDataRendering from "../../components/Common/HandleDataRendering";

const PanCardAuthenticate = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [wrongAttempts, setWrongAttempts] = useState(0);
  const { mobileNumber } = useSelector((state) => state.register);
  const { panAccountUerData, loading, error } = useSelector(
    (state) => state.panAccount,
  );
  const [alertError, setAlertError] = useState(false);
  const register = useSelector((state) => state.register);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const initialValues = {
    panDetails: "",
    termsAndCondition: false,
  };
  const Attempts = 2;
  const validationSchema_pan = Yup.object({
    panDetails: validation("Enter Pan")
      .min(10, "Pan number should be 10 digits")
      .max(10, "Incorrect Pan number"),
    termsAndCondition: termsAndConditionsValidation("Accept Terms"),
  });
  const onSubmit = (values, { setFieldError }) => {
    const data = {
      authNumber: values?.panDetails,
      mobileNumber: mobileNumber,
      authType: 0,
      platform: "Web",
    };
    if (values.panDetails === "ABCDE1234F") {
      dispatch({ type: PAN_ACCOUNT_USER, payload: data });
    } else {
      setWrongAttempts((prevAttempts) => prevAttempts + 1);
      if (wrongAttempts >= Attempts) {
        setAlertError(true);
      } else {
        setFieldError(
          "panDetails",
          `Sorry you have entered invalid PAN number.${
            wrongAttempts == 0 ? wrongAttempts + 2 : wrongAttempts
          } attempts remaining.`,
        );
      }
    }
  };

  useEffect(() => {
    if (panAccountUerData?.data === "SUCCESS") {
      navigate("/register/enter-more-details");
    }
    if (panAccountUerData?.code === "FAILURE") {
      navigate("/register/pan-authenticate");
    }
  }, [navigate, panAccountUerData]);

  return (
    <>
      <Container>
        <HandleDataRendering
          data={panAccountUerData}
          loading={loading}
          error={error}
        >
          <div className="relative w-full max-w-md mx-auto flex flex-col p-4">
            <div className="mt-5 mb-[36px]">
              <div className="flex lg:block">
                <BackButton />
                <div className="headline headline_xl headline_primary w-full lg:mt-2">
                  {REGISTRATION.VERIFICATION}
                </div>
              </div>
              <div className="text-grey-500 h-[36px] mb-7 mt-3 content content_lg">
                {REGISTRATION.UNABLE_TO_AUTHENTICATE}
              </div>
              <div className="flex flex-col flex-1 space-y-6">
                <div className="flex-1">
                  <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema_pan}
                    onSubmit={onSubmit}
                  >
                    {(formik) => (
                      <Form className="flex flex-col gap-32 justify-between h-full">
                        <div className="mt-2">
                          <div>
                            <Input
                              name="panDetails"
                              label={REGISTRATION.PAN}
                              className=" text-grey-500 focus:border-red-600 "
                              formik={formik}
                              disabled={alertError}
                              maxLength={10}
                            />
                          </div>
                          <p className=" text-grey-500 content content_md pt-1">
                            {REGISTRATION.EG}
                          </p>
                          <div className="pt-3">
                            <CheckBox
                              checked={termsAccepted}
                              onChange={() => {
                                const newTermsAccepted = !termsAccepted;
                                setTermsAccepted(newTermsAccepted);
                                formik.setFieldValue(
                                  "termsAndCondition",
                                  newTermsAccepted,
                                );
                              }}
                              label={REGISTRATION.I_Agree}
                              className="font-karla font-normal text-grey-500 text-xs w-full"
                              name="termsAndCondition"
                            />
                          </div>

                          {panAccountUerData?.code === "FAILURE" && (
                            <div className="bg-white p-2 rounded-lg text-XS mt-[40px] font-karla font-normal leading-[18px] text-grey-500">
                              {panAccountUerData?.message}
                            </div>
                          )}

                          <div
                            className={`flex flex-col items-center  ${
                              panAccountUerData?.code === "FAILURE"
                                ? "lg:pt-6 pt-32"
                                : "lg:pt-10 pt-48"
                            }`}
                          >
                            <Button
                              type="submit"
                              name="Verify"
                              disabled={
                                !(formik.isValid && formik.dirty) ||
                                alertError ||
                                (!register.isPan && !termsAccepted)
                              }
                              className="h-[42px] font-quicksand font-bold text-white w-full rounded-md bg-red-500 disabled:bg-disable-red disabled:text-red-200"
                            >
                              {REGISTRATION.VERIFY}
                            </Button>
                          </div>
                        </div>
                      </Form>
                    )}
                  </Formik>
                  {alertError && (
                    <Alert errorMessage="we are unable to authenticate you as a customer, please visit a nearby branch for a resolution" />
                  )}
                </div>
              </div>
            </div>
          </div>
        </HandleDataRendering>
      </Container>
    </>
  );
};
export default PanCardAuthenticate;
