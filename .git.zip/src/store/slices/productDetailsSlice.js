import { createSlice } from "@reduxjs/toolkit";
import { PRODUCT_DETAILS } from "../actions/actions";
const initialState = {
  productDetails: {},
  loading: false,
  error: null,
};

const productDetailsSlice = createSlice({
  name: PRODUCT_DETAILS,
  initialState,
  reducers: {
    fetchProductDetailsStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchProductDetailsStatusDataSuccess(state, action) {
      state.loading = false;
      state.productDetails = action.payload;
    },
    fetchProductDetailsStatusDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchProductDetailsStatusData,
  fetchProductDetailsStatusDataSuccess,
  fetchProductDetailsStatusDataFailure,
} = productDetailsSlice.actions;

export default productDetailsSlice.reducer;
