import { takeLatest, call, put } from "redux-saga/effects";
import {
  fetchCPanAccountStatusData,
  fetchPanAccountDataSuccess,
  fetchPanAccountDataFailure,
} from "../slices/panValidateSlice";
import { PAN_ACCOUNT_USER } from "../actions/actions";
import { endpoints } from "../../utils/apiUtils";
function* fetchPanAccountUserStatus(data) {
  try {
    const { payload } = data;
    const { token, ...restPayload } = payload;
    yield put(fetchCPanAccountStatusData());
    const config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const response = yield call(
      endpoints.panAccount,
      "POST",
      restPayload,
      config,
    );

    // console.log(response?.data);
    yield put(fetchPanAccountDataSuccess(response?.data));
  } catch (error) {
    yield put(fetchPanAccountDataFailure(error.message));
  }
}
export function* watchFetchPanAccountUser() {
  yield takeLatest(PAN_ACCOUNT_USER, fetchPanAccountUserStatus);
}
