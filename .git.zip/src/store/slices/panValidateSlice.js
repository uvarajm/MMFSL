import { createSlice } from "@reduxjs/toolkit";
import { PAN_ACCOUNT_USER } from "../actions/actions";

const initialState = {
  panAccountUerData: {},
  loading: false,
  error: null,
};

const panValidateSlice = createSlice({
  name: PAN_ACCOUNT_USER,
  initialState,
  reducers: {
    fetchCPanAccountStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchPanAccountDataSuccess(state, action) {
      state.loading = false;
      state.panAccountUerData = action.payload;
    },
    fetchPanAccountDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchCPanAccountStatusData,
  fetchPanAccountDataSuccess,
  fetchPanAccountDataFailure,
} = panValidateSlice.actions;

export default panValidateSlice.reducer;
