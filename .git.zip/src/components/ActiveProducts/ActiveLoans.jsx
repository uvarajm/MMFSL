import PropTypes from "prop-types";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import {
  ACTIVE_LOAN_CONSTANTS,
  DDMMMYYYY,
  RUPEE_SYMBOL,
} from "../../const/common";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import moment from "moment";
import { setProductDetails } from "../../store/slices/productId";

const ActiveLoans = ({ showButton, data, type }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const details = {
    cifId: data.cif,
    ucic: data.ucic,
    sourceSystem: data.sourceSystem,
    loanNumber: data.loanAccountNumber,
    productCategory: data.productCategory,
  };
  const handleRedirection = () => {
    dispatch(setProductDetails(details));
    navigate(`/product-details/${type}`);
  };
  const { theme } = useSelector((state) => state.theme);
  return (
    <div className="w-full lg:w-2/4 lg:p-4 pb-3">
      <div className="rounded-lg bg-white p-4">
        <div
          className={`flex border-b pb-2 items-center cursor-pointer ${
            theme === "light"
              ? "border-light-border-color "
              : "border-dark-border-color "
          }`}
          onClick={() => handleRedirection()}
        >
          <svg
            width="56"
            height="56"
            viewBox="0 0 56 56"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect width="56" height="56" rx="8" fill="#EDE0E3" />
            <mask
              id="mask0_4216_7127"
              style={{ maskType: "alpha" }}
              maskUnits="userSpaceOnUse"
              x="5"
              y="7"
              width="46"
              height="45"
            >
              <rect
                x="5.59961"
                y="7"
                width="44.8"
                height="44.6634"
                fill="#D9D9D9"
              />
            </mask>
            <g mask="url(#mask0_4216_7127)"></g>
            <mask
              id="mask1_4216_7127"
              style={{ maskType: "alpha" }}
              maskUnits="userSpaceOnUse"
              x="8"
              y="8"
              width="40"
              height="40"
            >
              <rect x="8" y="8" width="40" height="40" fill="#D9D9D9" />
            </mask>
            <g mask="url(#mask1_4216_7127)">
              <path
                d="M18.1925 37.0297V38.5299C18.1925 38.9977 18.021 39.3952 17.6779 39.7226C17.3347 40.0501 16.9181 40.2138 16.4279 40.2138C15.9377 40.2138 15.5217 40.0501 15.1798 39.7226C14.8379 39.3952 14.667 38.9977 14.667 38.5299V27.2999C14.667 27.1346 14.6782 26.9693 14.7007 26.8039C14.7231 26.6386 14.7609 26.4803 14.8139 26.3289L17.7984 18.2682C17.9981 17.6949 18.3601 17.2291 18.8845 16.8708C19.4087 16.5124 19.9954 16.3333 20.6445 16.3333H37.0227C37.6718 16.3333 38.2585 16.5124 38.7828 16.8708C39.3071 17.2291 39.6691 17.6949 39.8688 18.2682L42.8533 26.3289C42.9064 26.4803 42.9441 26.6386 42.9666 26.8039C42.989 26.9693 43.0002 27.1346 43.0002 27.2999V38.5299C43.0002 38.9977 42.8287 39.3952 42.4855 39.7226C42.1424 40.0501 41.7257 40.2138 41.2356 40.2138C40.7454 40.2138 40.3294 40.0501 39.9875 39.7226C39.6456 39.3952 39.4747 38.9977 39.4747 38.5299V37.0297H18.1925ZM18.1797 24.416H39.4875L37.5131 19.0428C37.4704 18.9407 37.4063 18.8616 37.3208 18.8055C37.2353 18.7493 37.1338 18.7213 37.0163 18.7213H20.651C20.5334 18.7213 20.4319 18.7493 20.3465 18.8055C20.261 18.8616 20.1969 18.9407 20.1541 19.0428L18.1797 24.416ZM21.2733 32.8047C21.8797 32.8047 22.394 32.6019 22.816 32.1964C23.238 31.7909 23.449 31.2985 23.449 30.7192C23.449 30.1399 23.2367 29.6487 22.8122 29.2456C22.3877 28.8425 21.8722 28.6409 21.2657 28.6409C20.6593 28.6409 20.1451 28.8437 19.723 29.2492C19.301 29.6547 19.09 30.1471 19.09 30.7264C19.09 31.3057 19.3023 31.7969 19.7268 32.2C20.1514 32.6031 20.6668 32.8047 21.2733 32.8047ZM36.4015 32.8047C37.0079 32.8047 37.5222 32.6019 37.9442 32.1964C38.3662 31.7909 38.5772 31.2985 38.5772 30.7192C38.5772 30.1399 38.3649 29.6487 37.9404 29.2456C37.5159 28.8425 37.0004 28.6409 36.394 28.6409C35.7875 28.6409 35.2733 28.8437 34.8513 29.2492C34.4293 29.6547 34.2182 30.1471 34.2182 30.7264C34.2182 31.3057 34.4305 31.7969 34.855 32.2C35.2796 32.6031 35.7951 32.8047 36.4015 32.8047ZM17.167 34.6417H40.5003V26.8039H17.167V34.6417Z"
                fill="#691A1E"
              />
            </g>
          </svg>
          <div className={`flex flex-col pl-4 w-full  text-light-text-primary`}>
            <div className="flex justify-between items-center">
              <p className={`rounded label label_lg label_primary-dark`}>
                {data.productCategory}
              </p>
            </div>
            <p className="label label_lg label_primary-dark">
              {data.productName}
            </p>
          </div>
          <KeyboardArrowRightIcon className="text-red-500" />
        </div>
        <div className="flex justify-between flex-wrap mt-2">
          <div className="w-2/4 text-sm py-2">
            <div className={`label label_lg label_primary-dark`}>
              {ACTIVE_LOAN_CONSTANTS.LOAN_DETAILS.LOAN_NO}
            </div>
            <div className="content content_lg content_secondary-dark">
              {data.loanAccountNumber}
            </div>
          </div>
          <div className="w-2/4 text-sm py-2">
            <div className={`label label_lg label_primary-dark`}>
              {ACTIVE_LOAN_CONSTANTS.LOAN_DETAILS.EMI_AMOUNT}
            </div>
            <div className="content content_lg content_secondary-dark">
              {RUPEE_SYMBOL}
              {data.installmentAmount}
            </div>
          </div>
          <div className="w-2/4 text-sm py-2">
            <div className={`label label_lg label_primary-dark`}>
              {ACTIVE_LOAN_CONSTANTS.LOAN_DETAILS.REGISTRATION_NO}
            </div>
            <div className="content content_lg content_secondary-dark">
              {data.vehicleRegistration}
            </div>
          </div>
          <div className="w-2/4 text-sm py-2">
            <div className={`label label_lg label_primary-dark`}>
              {ACTIVE_LOAN_CONSTANTS.LOAN_DETAILS.NEXT_DUE_DATE}
            </div>
            <div className="content content_lg content_secondary-dark">
              {moment(data.nextDuedate).format(DDMMMYYYY)}
            </div>
          </div>
        </div>
        {showButton && (
          <div className="flex justify-between mt-4">
            <div className="w-2/4">
              {data.mandateStatus && (
                <div className="mr-4">
                  <Button
                    variant="outlined"
                    className=" w-full !text-sm !font-quicksand !capitalize !p-2.5 !text-red-500 !border-red-500 !rounded-[10px]"
                  >
                    {ACTIVE_LOAN_CONSTANTS.BUTTONS.MANDATE}
                  </Button>
                </div>
              )}
            </div>
            <div className="w-2/4">
              <div className="">
                <Button
                  variant="contained"
                  className="w-full !text-sm !font-quicksand !capitalize !p-2.5 !bg-red-500 !rounded-[10px]"
                >
                  {ACTIVE_LOAN_CONSTANTS.BUTTONS.PAY}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

ActiveLoans.propTypes = {
  showButton: PropTypes.bool,
  data: PropTypes.any,
  type: PropTypes.string,
};

export default ActiveLoans;
