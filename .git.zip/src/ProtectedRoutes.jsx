import React from "react";
import PropTypes from "prop-types";
import { Navigate } from "react-router-dom";

// Function to check if user is logged in
const isUserLoggedIn = () => true;

// HOC for protected routes
export const ProtectedRoute = ({ element, ...rest }) =>
  isUserLoggedIn() ? (
    React.cloneElement(element, rest)
  ) : (
    <Navigate to="/login" replace />
  );

ProtectedRoute.propTypes = {
  element: PropTypes.node.isRequired,
};

// HOC for non-protected routes
export const NonProtectedRoute = ({ element, ...rest }) =>
  !isUserLoggedIn() ? (
    React.cloneElement(element, rest)
  ) : (
    <Navigate to="/" replace />
  );

NonProtectedRoute.propTypes = {
  element: PropTypes.node.isRequired,
};
