import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./assets/styles/index.scss";
import "./assets/styles/fonts.scss";
import { Provider } from "react-redux";
import { store } from "./store/store";
import { ThemeProvider } from "./components/index.js";

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <ThemeProvider>
      <App />
    </ThemeProvider>
  </Provider>,
);
