import PropTypes from "prop-types";

const SearchInput = ({ query, setShowSearch, handleChange, handleKeyDown }) => (
  <>
    <input
      type="text"
      placeholder="Today I want to..."
      className="header__search_box w-full "
      onFocus={() => setShowSearch(true)}
      onChange={handleChange}
      onKeyDown={handleKeyDown}
      value={query}
    />
  </>
);

SearchInput.propTypes = {
  query: PropTypes.string.isRequired,
  setShowSearch: PropTypes.func.isRequired,
  handleChange: PropTypes.func.isRequired,
  handleKeyDown: PropTypes.func.isRequired,
};

export default SearchInput;
