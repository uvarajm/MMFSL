import { createBrowserRouter } from "react-router-dom";
import { lazy } from "react";

// Import layout components
import { PreLogin, ServicesLayout } from "./components";
import RootLayout from "./components/Layouts/RootLayout";
import SingleColumnLayout from "./components/Layouts/SingleColumnLayout/index.jsx";

// Import lazy-loaded pages
const lazyPages = {
  Home: lazy(() => import("./pages/Home")),
  Login: lazy(() => import("./pages/Login")),
  TermsAndConditions: lazy(() => import("./pages/TermsAndConditions")),
  PrivacyPolicy: lazy(() => import("./pages/PrivacyPolicy")),
  Services: lazy(() => import("./pages/Services")),
  ServiceDetails: lazy(() => import("./pages/Services/ServiceDetails")),
  Foreclosure: lazy(() => import("./pages/Services/Foreclosure")),
  Register: lazy(() => import("./pages/Register")),
  GetOtp: lazy(() => import("./pages/Register/GetOtp")),
  SetPassword: lazy(() => import("./pages/SetPassword")),
  RegDetails: lazy(() => import("./pages/Register/RegDetails")),
  PanLoanRegDetails: lazy(() => import("./pages/Register/PanLoanRegDetails")),
  UnRegisterMobileDetails: lazy(
    () => import("./pages/Register/UnRegisterMobileDetails"),
  ),
  PanCard: lazy(() => import("./pages/Register/PanCard")),
  LoanAccount: lazy(() => import("./pages/Register/LoanAccount")),
  CurrentPassword: lazy(() => import("./pages/CurrentPassword")),
  ManageDevices: lazy(() => import("./pages/ManageDevices")),
  Financials: lazy(() => import("./pages/Financials")),
  Products: lazy(() => import("./pages/Products")),
  ProductFeatures: lazy(() => import("./pages/ProductFeatures")),
  LeadGen: lazy(() => import("./pages/LeadGen/index")),
  LeadGenSuccess: lazy(() => import("./pages/LeadGen/leadGenSuccess")),
  Success: lazy(() => import("./pages/Status/Success")),
  RegistrationFailed: lazy(() => import("./pages/Register/RegistrationFailed")),
  PageNotFound: lazy(() => import("./components/PageNotFound")),
  EmiCalculator: lazy(() => import("./components/EmiCalculator")),
  Settings: lazy(() => import("./pages/Settings")),
  ProductDetails: lazy(() => import("./pages/ProductDetails")),
  PanCardAuthenticate: lazy(
    () => import("./pages/Register/PanCardAuthenticate"),
  ),
  ResetPassword: lazy(() => import("./pages/ResetPassword")),
  EnterMoreDetails: lazy(() => import("./pages/Register/EnterMoreDetails")),
  RateUs: lazy(() => import("./pages/RateUs")),
  LocateUs: lazy(() => import("./pages/LocateUs")),
  LocationDetails: lazy(() => import("./pages/LocateUs/LocationDetails")),
  Faqs: lazy(() => import("./pages/Faq")),
  AppFaq: lazy(() => import("./pages/Faq/AppFaq")),
  HowTo: lazy(() => import("./pages/Faq/HowtoFaqViewMore")),
  offers: lazy(() => import("./pages/Offers")),
  offersDetails: lazy(() => import("./pages/OffersDetails/index")),
};

// Create the router configuration
const routerConfig = [
  {
    path: "/",
    element: <RootLayout />,
    children: [
      { index: true, element: <lazyPages.Home /> },
      {
        path: "login",
        element: <lazyPages.Login />,
      },
      {
        path: "reset-password",
        element: <lazyPages.ResetPassword />,
      },
      {
        path: "terms-and-conditions",
        element: <lazyPages.TermsAndConditions />,
      },
      {
        path: "privacy-policy",
        element: <lazyPages.PrivacyPolicy />,
      },
      {
        path: "services",
        element: <ServicesLayout />,
        children: [
          { index: true, element: <lazyPages.Services /> },
          { path: ":srId", element: <lazyPages.ServiceDetails /> },
        ],
      },
      {
        path: "register",
        element: <PreLogin />,
        children: [
          { index: true, element: <lazyPages.Register /> },
          { path: "get-otp", element: <lazyPages.GetOtp /> },
          { path: "set-password", element: <lazyPages.SetPassword /> },
          { path: "get-register-details", element: <lazyPages.RegDetails /> },
          {
            path: "get-more-details",
            element: <lazyPages.PanLoanRegDetails />,
          },
          {
            path: "unregistermobile",
            element: <lazyPages.UnRegisterMobileDetails />,
          },
          { path: "pan-details", element: <lazyPages.PanCard /> },
          {
            path: "pan-authenticate",
            element: <lazyPages.PanCardAuthenticate />,
          },
          {
            path: "enter-more-details",
            element: <lazyPages.EnterMoreDetails />,
          },
          { path: "loan-details", element: <lazyPages.LoanAccount /> },
          {
            path: "register-failed",
            element: <lazyPages.RegistrationFailed />,
          },
        ],
      },
      {
        path: "reset-password",
        element: <lazyPages.SetPassword />,
      },
      {
        path: "change-password",
        element: <lazyPages.CurrentPassword />,
      },
      {
        path: "manage-devices",
        element: <lazyPages.ManageDevices />,
      },
      {
        path: "financial",
        element: <lazyPages.Financials />,
      },
      {
        path: "product-feature",
        children: [
          {
            path: ":loanType/:title",
            element: <lazyPages.ProductFeatures />,
          },
          {
            path: ":loanType/:title/leadgen",
            element: <lazyPages.LeadGen />,
          },
          {
            path: ":loanType/:title/leadgen/success",
            element: <lazyPages.LeadGenSuccess />,
          },
        ],
      },
      {
        path: "product-details",
        children: [
          {
            path: "active",
            element: <lazyPages.ProductDetails />,
          },
          {
            path: "completed",
            element: <lazyPages.ProductDetails />,
          },
        ],
      },
      {
        path: "product",
        element: <ServicesLayout />,
        children: [
          {
            index: true,
            element: <lazyPages.Products />,
          },
        ],
      },
      {
        path: "success",
        element: <lazyPages.Success />,
      },
      {
        path: "EmiCalculator",
        element: <lazyPages.EmiCalculator />,
      },
      {
        path: "Settings",
        element: <lazyPages.Settings />,
      },
      {
        path: "rate-us",
        element: <lazyPages.RateUs />,
      },
      {
        path: "locate-us",
        element: <ServicesLayout />,
        children: [
          { index: true, element: <lazyPages.LocateUs /> },
          {
            path: "details",
            element: <lazyPages.LocationDetails />,
          },
        ],
      },
      { path: "/*", element: <lazyPages.PageNotFound /> },
      {
        path: "faqs",
        element: <ServicesLayout />,
        children: [
          {
            index: true,
            element: <lazyPages.Faqs />,
          },
          {
            path: ":loanType",
            children: [
              {
                path: ":title",
                element: <lazyPages.AppFaq />,
              },
              {
                path: ":category",
                element: <lazyPages.HowTo />,
              },
            ],
          },
        ],
      },
      {
        path: "offers",
        element: <lazyPages.offers />,
      },
      {
        path: "offer-details/:offerId",
        element: <SingleColumnLayout />,
        children: [
          {
            index: true,
            element: <lazyPages.offersDetails />,
          },
        ],
      },
    ],
  },
];

// Create the router
const router = createBrowserRouter(routerConfig);

export default router;
