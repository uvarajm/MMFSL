import PropTypes from "prop-types";
import { Person2Outlined } from "@mui/icons-material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import Button from "../Button";
import ApplicationCompletedCard from "./ApplicationCompletedCard";
import "./card.css";
import { applicationStatus as status } from "../../const/common";
import ApplicationStatusNDetails from "./ApplicationStatusNDetails";

const ApplicationCard = ({ applicationData }) => {
  const checkCircleIcon = (applicationStatus) => {
    // finding the index position of application status. based on status changing color of Icon
    const checkCircleIconArr = [...new Array(5).fill("text-grey-600")];
    const applicationStatusIndex = Object.values(status)
      .map((appication) => appication.toLowerCase())
      .indexOf(applicationStatus.toLowerCase());
    for (let i = applicationStatusIndex; i >= 0; i--) {
      checkCircleIconArr[i] = "text-black-100";
    }
    return (
      <div className="flex items-center gap-0">
        {checkCircleIconArr.map((icon) => (
          <>
            <div className="check-circle-icon"></div>
            <CheckCircleIcon className={icon} />
          </>
        ))}
        <div className="check-circle-icon"></div>
      </div>
    );
  };
  return (
    <>
      {applicationData?.map((application) => (
        <div
          key={application.applicationNumber}
          className="max-w-[578px]  rounded overflow-hidden shadow-sm border-2 border-gray-200 mt-10"
        >
          <div className="flex border-solid border-b-[1px] p-4 #A5A5A5">
            <div className="card-icon">
              <Person2Outlined />
            </div>
            <div className="font-bold text-xl mb-2 pl-4">
              <h6 className="text-xs text-[#5B5B5B]">{application.loanType}</h6>
              <h2 className="text-xs text-[#1D1B20]">
                Application Id: {application.applicationNumber}
              </h2>
            </div>
          </div>
          {application.applicationStatus === status.COMPLETED ? (
            <ApplicationCompletedCard />
          ) : (
            <ApplicationStatusNDetails {...application} />
          )}
          <p className="text-xs p-4">Application Status as on date</p>
          {checkCircleIcon(application.applicationStatus)}
          <div className="mt-[-10px] flex flex-col py-4 w-full bg-[#E9F8EC]">
            <div className="flex items-center mb-4 bg-[#E9F8EC] w-full justify-around">
              <div className="text-size">Initiated</div>
              <div className="text-size">Under Process</div>
              <div className="text-size">Sanction</div>
              <div className="text-size">Post Sanction</div>
              <div className="text-size">Completed</div>
            </div>
            <div className="bg-[#E9F8EC] w-full">
              <Button
                name="See Details"
                className=" border-2 border-[#79747E] float-right  mr-4"
              />
            </div>
          </div>
        </div>
      ))}
    </>
  );
};

ApplicationCard.propTypes = {
  applicationData: PropTypes.any,
};

export default ApplicationCard;
