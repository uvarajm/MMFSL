import PropTypes from "prop-types";
import ProductItems from "../../components/ProductFeatures/ProductItems";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import { PRODUCTS } from "../../const/ProductConst";
import { compareStr } from "../../utils/commonUtils";
const ProductsFaqs = ({ AppFaqs, loading, error }) => {
  return (
    <HandleDataRendering data={AppFaqs} loading={loading} error={error}>
      {AppFaqs?.map((item, index) => {
        if (compareStr(item.faq_type, PRODUCTS)) {
          return (
            <ProductItems
              key={index}
              product_title={item.product_types[0].title}
              types={item.product_types[0].sub_types}
            />
          );
        }
      })}
    </HandleDataRendering>
  );
};

export default ProductsFaqs;
ProductsFaqs.propTypes = {
  AppFaqs: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  loading: PropTypes.bool,
  error: PropTypes.object,
};
