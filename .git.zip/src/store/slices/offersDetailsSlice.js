import { createSlice } from "@reduxjs/toolkit";
import { OFFERS_DETAILS } from "../actions/actions";
const initialState = {
  offers: {},
  loading: false,
  error: null,
};

const offersDetailsSlice = createSlice({
  name: OFFERS_DETAILS,
  initialState,
  reducers: {
    fetchOffersDetails(state) {
      state.loading = true;
      state.error = null;
    },
    fetchOffersDetailsSuccess(state, action) {
      state.loading = false;
      state.offersDetails = action.payload;
    },
    fetchOffersDetailsFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchOffersDetails,
  fetchOffersDetailsSuccess,
  fetchOffersDetailsFailure,
} = offersDetailsSlice.actions;

export default offersDetailsSlice.reducer;
