import { createSlice } from "@reduxjs/toolkit";
import { PRODUCT_CATEGORY } from "../actions/actions";
const initialState = {
  categoryProduct: {},
  loading: false,
  error: null,
};

const productCategorySlice = createSlice({
  name: PRODUCT_CATEGORY,
  initialState,
  reducers: {
    fetchProductCategoryStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchProductCategoryStatusDataSuccess(state, action) {
      state.loading = false;
      state.categoryProduct = action.payload;
    },
    fetchProductCategoryStatusDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchProductCategoryStatusData,
  fetchProductCategoryStatusDataSuccess,
  fetchProductCategoryStatusDataFailure,
} = productCategorySlice.actions;

export default productCategorySlice.reducer;
