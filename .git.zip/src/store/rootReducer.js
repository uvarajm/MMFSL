import loginReducer from "../pages/Login/loginFormSlice";
// import registerReducer from "../pages/Register/registerSlice";
import applicationStatusReducer from "./slices/applicationStatusSlice";
import sidebarReducer from "../store/slices/sidebarSlice";
import bookmarkEvent from "../store/slices/saveBranchesEvent";
import productDetailReducer from "../store/slices/productDetailSlice";
import productIdDetailsSlice from "../store/slices/productId";
import themeReducer from "../store/slices/themeSlice";
import productCategorySlice from "./slices/productCategorySlice";
import inProgressProductSlice from "./slices/inProgressProductSlice";
import tearmAndConditionPageSlice from "./slices/tearmAndConditionPageSlice";
import registerSlice from "./slices/registerSlice";
import validateOtpSlice from "./slices/validateOtpSlice";
import menuSliceReducer from "./slices/menuSlice";
import productDetailsSlice from "./slices/productDetailsSlice";
import loanListProducts from "./slices/loanListProductSlice";
import privacyPolicyPageSlice from "./slices/privacyPolicyPageSlice";
import leadGenSlice from "./slices/leadGenSlice";
import registerUserSlice from "./slices/registerUserSlice";
import panValidateSlice from "./slices/panValidateSlice";
import registrationUserStatusSlice from "./slices/registrationUserStatusSlice";
import createPasswordSlice from "./slices/createPasswordSlice";
import appFaqSlice from "./slices/appFaqSlice";
import paymentSlice from "./slices/paymentSlice";
import offersSlice from "./slices/offersSlice";
import offersDetails from "./slices/offersDetailsSlice";
import StateListSlice from "./slices/StateListSlice";
import pinCodeStatusSlice from "./slices/pinCodeStatusSlice";
import dealerPincodeSlice from "./slices/dealerPincodeSlice";
import branchStateCityCodeSlice from "./slices/branchStateCityCodeSlice";
import geoLocationSlice from "./slices/geoLocationSlice";
import latitudeLongitudeSlice from "./slices/latitudeLongitudeSlice";
import getSavedBookmarksSlice from "./slices/getSavedBookmarksSlice";
import updateBookmarkSlice from "./slices/updateBookmarkSlice";
import dealerStateCityCodeSlice from "./slices/dealerStateCityCodeSlice";
import serviceListSlice from "./slices/serviceListSlice";

export const reducer = {
  login: loginReducer,
  sidebar: sidebarReducer,
  menu: menuSliceReducer,
  productDetail: productDetailReducer,
  register: registerSlice,
  applicationStatus: applicationStatusReducer,
  theme: themeReducer,
  categoryProduct: productCategorySlice,
  progressData: inProgressProductSlice,
  termAndCondtionPageData: tearmAndConditionPageSlice,
  validateOtp: validateOtpSlice,
  createPassword: createPasswordSlice,
  loanListDataResponse: loanListProducts,
  privacyPolicypageData: privacyPolicyPageSlice,
  registerUser: registerUserSlice,
  panAccount: panValidateSlice,
  registerUserStatus: registrationUserStatusSlice,
  productDetails: productDetailsSlice,
  productIdDetails: productIdDetailsSlice,
  leadGenData: leadGenSlice,
  AppFaqs: appFaqSlice,
  payment: paymentSlice,
  offers: offersSlice,
  offersDetails: offersDetails,
  stateList: StateListSlice,
  pinCodeData: pinCodeStatusSlice,
  dealerPinCode: dealerPincodeSlice,
  branchStateCityCode: branchStateCityCodeSlice,
  geoLocation: geoLocationSlice,
  latitLongitude: latitudeLongitudeSlice,
  getBookmarks: getSavedBookmarksSlice,
  updateBookmark: updateBookmarkSlice,
  dealerCodeStateCity: dealerStateCityCodeSlice,
  services: serviceListSlice,
  bookmark: bookmarkEvent,
};
