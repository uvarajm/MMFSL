import { takeLatest, put, call } from "redux-saga/effects";
import { LOAN_LIST } from "../actions/actions";
import {
  fetchLoanListProductsStatusData,
  fetchLoanListProductsDataFailure,
  fetchLoanListProductsDataSuccess,
} from "../slices/loanListProductSlice";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";
function* fetchLoanList(action) {
  try {
    yield put(fetchLoanListProductsStatusData());
    // Make API request using the token name
    const response = yield call(
      makeApiRequest,
      endpoints.loanList,
      BACKEND_TOKEN,
      "POST",
      {
        ucic: action.payload,
      },
    );
    yield put(fetchLoanListProductsDataSuccess(response));
  } catch (error) {
    yield put(fetchLoanListProductsDataFailure(error.message));
  }
}

export function* watchFetchLoanListProducts() {
  yield takeLatest(LOAN_LIST, fetchLoanList);
}
