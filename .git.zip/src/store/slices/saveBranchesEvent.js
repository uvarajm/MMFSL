import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  bookmarkObj: {},
};

const saveBranchEventSlice = createSlice({
  name: "saveBranchEvent",
  initialState,
  reducers: {
    updateBookMarks: (state, action) => {
      state.bookmarkObj = {
        ...state.bookmarkObj,
        ...action.payload,
      };
    },
  },
});

export const { updateBookMarks } = saveBranchEventSlice.actions;

export default saveBranchEventSlice.reducer;
