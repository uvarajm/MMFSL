import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchRegisterStatusData,
  fetchRegisterDataSuccess,
  fetchRegisterDataFailure,
} from "../slices/registerSlice";
import { REGISTER_USER } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchRegisterStatus({ payload }) {
  try {
    yield put(fetchRegisterStatusData());

    const response = yield call(
      makeApiRequest,
      endpoints.sendOtp,
      BACKEND_TOKEN,
      "POST",
      payload,
    );
    yield put(fetchRegisterDataSuccess(response));
  } catch (error) {
    yield put(fetchRegisterDataFailure(error.message));
  }
}
export function* watchFetchRegister() {
  yield takeLatest(REGISTER_USER, fetchRegisterStatus);
}
