import PropTypes from "prop-types";
import moment from "moment";
import Button from "@mui/material/Button";
import {
  PRODUCT_DETAILS_CONSTANTS,
  ACTIVE_LOAN_CONSTANTS,
  RUPEE_SYMBOL,
} from "../../const/common";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../Common/SvgIcon";
import { isObjectBlank } from "../../utils";
import ThreeColDetails from "../Common/ThreeColDetails";
import CopyToClipboard from "../Common/CopyToClipboard";

const BasicDetails = ({ basicDetailsResponse, basicBankDetails }) => {
  const threeColDetailsData = [
    {
      label: PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.startDate,
      value: moment(basicDetailsResponse.startDate).format("DD MMM YY"),
    },
    {
      label: PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.endDate,
      value: moment(basicDetailsResponse.endDate).format("DD MMM YY"),
    },
    {
      label: PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.dueDate,
      value: moment(basicDetailsResponse.nextDueDate).format("DD MMM YY"),
    },
  ];

  return (
    <div className="loan_details " id={`tab-0`}>
      <div className="bg-white items-center rounded-lg p-4 flex relative pr-[70px] sm:pr-[110px] -mx-4 mb-4 lg:mb-[40px] lg:mx-0">
        <svg
          width="56"
          height="56"
          viewBox="0 0 56 56"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="mr-4"
        >
          <rect width="56" height="56" rx="8" fill="#EDE0E3" />
          <mask
            id="mask0_642_41819"
            style={{ maskType: "alpha" }}
            maskUnits="userSpaceOnUse"
            x="8"
            y="8"
            width="40"
            height="40"
          >
            <rect x="8" y="8" width="40" height="40" fill="#D9D9D9" />
          </mask>
          <g mask="url(#mask0_642_41819)">
            <path
              d="M18.1923 37.0297V38.5299C18.1923 38.9977 18.0207 39.3952 17.6776 39.7226C17.3345 40.0501 16.9178 40.2138 16.4277 40.2138C15.9375 40.2138 15.5214 40.0501 15.1796 39.7226C14.8377 39.3952 14.6667 38.9977 14.6667 38.5299V27.2999C14.6667 27.1346 14.678 26.9693 14.7004 26.8039C14.7229 26.6386 14.7606 26.4803 14.8137 26.3289L17.7982 18.2682C17.9979 17.6949 18.3599 17.2291 18.8842 16.8708C19.4085 16.5124 19.9952 16.3333 20.6443 16.3333H37.0225C37.6716 16.3333 38.2583 16.5124 38.7825 16.8708C39.3068 17.2291 39.6689 17.6949 39.8686 18.2682L42.8531 26.3289C42.9061 26.4803 42.9439 26.6386 42.9663 26.8039C42.9888 26.9693 43 27.1346 43 27.2999V38.5299C43 38.9977 42.8284 39.3952 42.4853 39.7226C42.1422 40.0501 41.7255 40.2138 41.2353 40.2138C40.7451 40.2138 40.3291 40.0501 39.9873 39.7226C39.6454 39.3952 39.4745 38.9977 39.4745 38.5299V37.0297H18.1923ZM18.1795 24.416H39.4872L37.5129 19.0428C37.4701 18.9407 37.406 18.8616 37.3205 18.8055C37.2351 18.7493 37.1336 18.7213 37.016 18.7213H20.6507C20.5332 18.7213 20.4317 18.7493 20.3462 18.8055C20.2607 18.8616 20.1966 18.9407 20.1539 19.0428L18.1795 24.416ZM21.273 32.8047C21.8795 32.8047 22.3937 32.6019 22.8157 32.1964C23.2377 31.7909 23.4487 31.2985 23.4487 30.7192C23.4487 30.1399 23.2365 29.6487 22.812 29.2456C22.3874 28.8425 21.8719 28.6409 21.2655 28.6409C20.6591 28.6409 20.1448 28.8437 19.7228 29.2492C19.3008 29.6547 19.0898 30.1471 19.0898 30.7264C19.0898 31.3057 19.3021 31.7969 19.7266 32.2C20.1511 32.6031 20.6666 32.8047 21.273 32.8047ZM36.4013 32.8047C37.0077 32.8047 37.5219 32.6019 37.944 32.1964C38.366 31.7909 38.577 31.2985 38.577 30.7192C38.577 30.1399 38.3647 29.6487 37.9402 29.2456C37.5156 28.8425 37.0002 28.6409 36.3937 28.6409C35.7873 28.6409 35.273 28.8437 34.851 29.2492C34.429 29.6547 34.218 30.1471 34.218 30.7264C34.218 31.3057 34.4303 31.7969 34.8548 32.2C35.2793 32.6031 35.7948 32.8047 36.4013 32.8047ZM17.1667 34.6417H40.5V26.8039H17.1667V34.6417Z"
              fill="#691A1E"
            />
          </g>
        </svg>
        <div className="w-full">
          <p className=" text-red-800 lg:font-karla mr-1 w-full text-sm lg:text-base flex">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.loanNo}{" "}
            <CopyToClipboard text={basicDetailsResponse.loanId} />
          </p>
          <p className="text-red-800 text-sm lg:text-[18px] mr-1 flex items-center font-semibold">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.registerNo}{" "}
            {basicDetailsResponse.vehicleRegistrationNumber}
          </p>
        </div>
        <div className="bg-lilac-light p-2 font-semibold rounded lg:rounded-lg absolute top-[16px] right-[16px] text-[11px] lg:text-sm">
          {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.Active}
        </div>
      </div>
      <div className="lg:flex -mx-2 mb-6">
        <div
          className={`${
            !isObjectBlank(basicBankDetails) ? "w-full" : "lg:w-2/4"
          } flex flex-wrap`}
        >
          <div className="lg:w-2/4 p-2">
            <div className="text-xs lg:font-semibold lg:text-sm ">
              {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.loanAmount}
            </div>
            <div className="font-semibold lg:font-medium lg:font-karla lg:text-grey-500 text-red-800 text-sm">
              {RUPEE_SYMBOL}
              {basicDetailsResponse.loanAmount}
            </div>
          </div>
          <div className="lg:w-2/4 p-2">
            <div className="text-xs lg:font-semibold lg:text-sm ">
              {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.totalOutAmount}
            </div>
            <div className="font-semibold lg:font-medium lg:font-karla lg:text-grey-500 text-red-800 text-sm">
              {RUPEE_SYMBOL}
              {basicDetailsResponse.totalOutstandingAmount}
            </div>
          </div>
          <div className="lg:w-2/4 p-2">
            <div className="text-xs lg:font-semibold lg:text-sm ">
              {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.emiPaid}
            </div>
            <div className="font-semibold lg:font-medium lg:font-karla lg:text-grey-500 text-red-800 text-sm">
              {basicDetailsResponse.numberOfPaidInstallments}
            </div>
          </div>
        </div>
        {!isObjectBlank(basicBankDetails) && (
          <div className="pay-reminder-wrapper rounded-[15px] bg-white lg:w-2/4 overflow-hidden mt-4 lg:mt-0">
            <div className="bg-lilac-light px-4 py-2 flex justify-between cursor-pointer">
              <div className="flex items-center">
                <SvgIcon url={iconConfig.Notification} />
                <span className="text-red-800 text-sm font-semibold ml-2">
                  {PRODUCT_DETAILS_CONSTANTS.COMMON.SET_REMINDER}
                </span>
              </div>
              <SvgIcon url={iconConfig.ChevronRight} />
            </div>
            <div className="flex py-[11px] px-4 justify-between">
              <div className="">
                <div className="text-sm text-medium text-red-800">
                  {PRODUCT_DETAILS_CONSTANTS.COMMON.TOTAL_PAYABLE}
                </div>
                <div className="text-xl font-semibold text-red-800">
                  {RUPEE_SYMBOL}
                  {basicDetailsResponse.instalmentAmount}
                </div>
              </div>
              <Button
                variant="contained"
                className="!shadow-none w-full !text-sm !font-quicksand max-w-[136px] !capitalize !p-2.5 !bg-red-500 !rounded-[10px]"
              >
                {ACTIVE_LOAN_CONSTANTS.BUTTONS.PAY}
              </Button>
            </div>
          </div>
        )}
      </div>
      <ThreeColDetails data={threeColDetailsData} />
      <div className="-m-2 flex flex-wrap mb-1">
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.chargesOverdue}
          </div>
          <div className="loan_details__label-value">
            {RUPEE_SYMBOL}
            {basicDetailsResponse.chargesOverdue}
          </div>
        </div>
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.totalAmountOverdue}
          </div>
          <div className="loan_details__label-value">
            {RUPEE_SYMBOL}
            {basicDetailsResponse.totalAmountOverdue}
          </div>
        </div>
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.emiOverdue}
          </div>
          <div className="loan_details__label-value">
            {basicDetailsResponse.installmentOverdue}
          </div>
        </div>
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.intRate}
          </div>
          <div className="loan_details__label-value">
            {basicDetailsResponse.interestRate}
          </div>
        </div>
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.emiAmount}
          </div>
          <div className="loan_details__label-value">
            {RUPEE_SYMBOL}
            {basicDetailsResponse.instalmentAmount}
          </div>
        </div>
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.frequency}
          </div>
          <div className="loan_details__label-value">
            {basicDetailsResponse.frequency}
          </div>
        </div>
        <div className="w-2/4 p-2 lg:w-1/4">
          <div className="loan_details__label">
            {PRODUCT_DETAILS_CONSTANTS.BASIC_DETAILS.repaymentMode}
          </div>
          <div className="loan_details__label-value">Mandate</div>
        </div>
      </div>
    </div>
  );
};

BasicDetails.propTypes = {
  basicDetailsResponse: PropTypes.object,
  basicBankDetails: PropTypes.object,
};

export default BasicDetails;
