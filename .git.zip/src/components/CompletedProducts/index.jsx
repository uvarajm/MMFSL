import PropTypes from "prop-types";
import ActiveLoans from "../ActiveProducts/ActiveLoans";
import NoData from "../Common/NoData";
import { isObjectBlank } from "../../utils";

const CompletedProducts = ({ completedApplications }) => {
  return (
    <>
      {completedApplications?.length === 0 ||
      isObjectBlank(completedApplications) ||
      !completedApplications ? (
        <div className="flex items-center justify-center my-2">
          <NoData errorText="You have no complete products" />
        </div>
      ) : (
        <div className="flex flex-wrap lg:-mx-4 h-full">
          {completedApplications?.map((detail) => (
            <ActiveLoans
              key={detail.mobileNumber}
              data={detail}
              showButton={true}
              type="Completed"
            />
          ))}
        </div>
      )}
    </>
  );
};

export default CompletedProducts;
CompletedProducts.propTypes = {
  completedApplications: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.array,
  ]),
};
