import PropTypes from "prop-types";
import scanner from "../../assets/download-scanner.png";
import Carousel from "../Carousel";

const Sidebar = ({
  showPreApproved = false,
  customClasses = "",
  stickyClass = "",
}) => {
  return (
    <div
      className={`offer-section flex flex-col items-center lg:max-w-[279px] lg:pl-6 lg:mt-6 w-full ${customClasses}`}
    >
      <div className={`w-full sticky top-[60px] ${stickyClass}`}>
        {showPreApproved ? (
          <div className="w-full">
            <Carousel />
          </div>
        ) : (
          ""
        )}
        <div className={`scanner ${showPreApproved ? "mt-4" : ""} w-[279px]`}>
          <div className="flex bg-white rounded-lg p-1 items-center justify-between">
            <div className="p-2">
              <p className="label label-primary-dark label_xl">
                Manage your finances on the go
              </p>
              <p className="content content_secondary-dark content_xl">
                Download now!
              </p>
            </div>
            <img src={scanner} alt="" />
          </div>
        </div>
      </div>
    </div>
  );
};

Sidebar.propTypes = {
  showPreApproved: PropTypes.bool,
  customClasses: PropTypes.string,
  stickyClass: PropTypes.string,
};

export default Sidebar;
