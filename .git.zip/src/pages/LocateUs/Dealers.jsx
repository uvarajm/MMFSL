import PropTypes from "prop-types";
import { useEffect, useLayoutEffect, useState } from "react";
import UseLazyLoading from "../../hooks/UseLazyLoading";
import { mergeBranchLists } from "../../utils/utils";

const Dealers = ({ getSavedBookmarksData, dealerPinCodeData }) => {
  const [dealerList, setDealerList] = useState([]);
  const [saveList, setSaveList] = useState([]);

  useLayoutEffect(() => {
    if (
      getSavedBookmarksData?.dealerList ||
      getSavedBookmarksData?.branchList
    ) {
      const { dealerList = [], branchList = [] } = getSavedBookmarksData;

      const dealerListWithSaved = dealerList.map((dealer) => ({
        ...dealer,
        saved: true,
      }));
      const branchListWithSaved = branchList.map((branch) => ({
        ...branch,
        saved: true,
      }));

      setSaveList(() => [...dealerListWithSaved, ...branchListWithSaved]);
    }
  }, []);

  useEffect(() => {
    const mergedBranchList = mergeBranchLists(
      dealerPinCodeData?.dealerList,
      saveList,
    );

    if (mergedBranchList.length > 0) setDealerList(mergedBranchList);
  }, [dealerPinCodeData, saveList]);

  return (
    <div className="w-full">
      <p className="title title_sm title_primary leading-[22px]">
        {dealerPinCodeData?.dealerList?.length} branches near you
      </p>
      <div className="pt-2 lg:w-[680px]">
        <UseLazyLoading data={dealerList} />
      </div>
    </div>
  );
};

Dealers.propTypes = {
  getSavedBookmarksData: PropTypes.object,
  dealerPinCodeData: PropTypes.object,
  superAppId: PropTypes.string,
  updateBookmarkData: PropTypes.any,
  saveLoading: PropTypes.any,
  loading: PropTypes.bool,
};

export default Dealers;
