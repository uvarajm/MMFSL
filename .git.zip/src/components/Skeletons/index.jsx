import PropTypes from "prop-types";
import { Skeleton, Stack } from "@mui/material";

const Skeletons = ({ width, height, variant, sx }) => {
  return (
    <Stack spacing={1} sx={{ padding: "5px" }}>
      <Skeleton variant={variant} width={width} height={height} sx={sx} />
    </Stack>
  );
};

Skeletons.propTypes = {
  width: PropTypes.number,
  height: PropTypes.number,
  variant: PropTypes.string,
  sx: PropTypes.object,
};

export default Skeletons;
