import PropTypes from "prop-types";
import FetchDynamicImage from "./FetchDynamicImage";
import DOMPurify from "dompurify";
const OffersBanner = ({
  image,
  primaryTitle,
  secondaryTitle,
  className = "",
}) => {
  const sanitizer = DOMPurify.sanitize;
  return (
    <div
      className={`mt-10 rounded-lg flex justify-between sm:items-center px-4 flex-col-reverse lg:bg-white sm:flex-row ${className}`}
    >
      <div className="py-[17px] sm:w-[75%] w-full">
        <p className="title sm:title-xl title-primary-dark text-2xl">
          {primaryTitle}
        </p>
        <p
          className="content sm:content-xl content-lg content-secondary-dark sm:leading-[22px] leading-[18px] pt-1"
          dangerouslySetInnerHTML={{
            __html: sanitizer(secondaryTitle),
          }}
        ></p>
      </div>
      <div className="sm:w-[25%] w-full pt-3 sm:pt-0">
        <FetchDynamicImage
          src={"https://api-dev.mmfsl.com/oneapp/secure-image?fid=39"}
          alt={image}
          className="w-full h-auto"
          customClasses="sm:w-full w-[50%]"
        />
      </div>
    </div>
  );
};

OffersBanner.propTypes = {
  image: PropTypes.string,
  primaryTitle: PropTypes.string,
  secondaryTitle: PropTypes.string,
  className: PropTypes.string,
};

export default OffersBanner;
