import PropTypes from "prop-types";
import { DDMMMYYYY } from "../../const/common";
import { dateFormat } from "../../utils/dateUntil";
import "./card.css";

const ApplicationStatusNDetails = ({
  applicantName,
  applicationDate,
  assetName,
  branchName,
}) => {
  return (
    <div className={`flex p-4 text-size`}>
      <div className="flex-1">
        <div className="flex flex-col">
          <label className="card-title-label">Name</label>
          <p className="card-details">{applicantName}</p>
        </div>
        <div className="flex flex-col">
          <label className="card-title-label">Date of Creation</label>
          <p className="card-details">
            {dateFormat(applicationDate, DDMMMYYYY)}
          </p>
        </div>
      </div>
      <div className="flex-1 pl-14 flex flex-col w-full">
        <div className="flex flex-col justify-end">
          <label className="card-title-label">Asset Name</label>
          <p className="card-details">{assetName}</p>
        </div>
        <div className="flex flex-col justify-end ">
          <label className="card-title-label">Branch Name</label>
          <p className="card-details">{branchName}</p>
        </div>
      </div>
    </div>
  );
};

ApplicationStatusNDetails.propTypes = {
  applicantName: PropTypes.any,
  applicationDate: PropTypes.any,
  assetName: PropTypes.string,
  branchName: PropTypes.string,
};

export default ApplicationStatusNDetails;
