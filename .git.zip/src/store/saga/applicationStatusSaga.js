// saga.js
import { takeLatest, call, put } from "redux-saga/effects";
import {
  fetchApplicationStatusData,
  fetchApplicationStatusDataSuccess,
  fetchApplicationStatusDataFailure,
} from "../slices/applicationStatusSlice";
import { APPLICATION_STATUS } from "../actions/actions";

function* fetchApplicationStatus() {
  try {
    yield put(fetchApplicationStatusData());
    const response = yield call(
      fetch,
      "https://jsonplaceholder.typicode.com/todos/1",
    );
    const data = yield response.json();
    yield put(fetchApplicationStatusDataSuccess(data));
  } catch (error) {
    yield put(fetchApplicationStatusDataFailure(error.message));
  }
}

export function* watchFetchApplicationStatus() {
  yield takeLatest(APPLICATION_STATUS, fetchApplicationStatus);
}
