import Notifications from "../../assets/icons/notifications.svg";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Typography from "@mui/material/Typography"; // Import Typography from Material-UI
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import jsonData from "../Notification/notifyData.json";
import SvgIcon from "../../components/Common/SvgIcon";

function Notification() {
  const [state, setState] = React.useState({
    right: false,
    selectedContent: "",
    confirmClear: false, // State to track the selected content
  });

  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };
  const handleNotificationsClick = () => {
    setState({ ...state, right: true });
  };

  const handleContentChange = (buttonDetails) => {
    // Filter the paymentNotifications based on the selected content
    const filteredNotifications = jsonData.paymentNotifications.filter(
      (notification) => notification.notificationindex === buttonDetails.id,
    );
    // Sort the filtered notifications by date
    const sortedNotifications = filteredNotifications.sort(
      (a, b) => new Date(b.date) - new Date(a.date),
    );

    // Group notifications by date
    const groupedNotifications = {};
    sortedNotifications.forEach((notification) => {
      const dateKey = new Date(notification.date).toLocaleDateString();
      if (!groupedNotifications[dateKey]) {
        groupedNotifications[dateKey] = [];
      }
      groupedNotifications[dateKey].push(notification);
    });

    const formattedContent = Object.entries(groupedNotifications).map(
      ([date, notifications]) => (
        <div key={date} className="text-left">
          <Typography variant="h4">
            {date === new Date().toLocaleDateString() ? "Today" : date}
          </Typography>
          {notifications.map((notification, index) => (
            <div key={notification.id}>
              {index === 0 && (
                <Typography variant="h6">{notification.message}</Typography>
              )}
              {/* Dynamically create buttons for each action */}
              <Button
                key={`${notification.id}_${index}`} // Unique key for each button
                variant="contained"
                color="primary"
                onClick={() => handleAction(notification.action)}
                style={{ marginTop: "8px" }} // Add spacing between buttons
              >
                {notification.action}
              </Button>
            </div>
          ))}
          <hr
            className="my-2 border-gray-400"
            style={{ marginTop: "16px", marginBottom: "16px" }}
          />
        </div>
      ),
    );

    // Set the generated content to state
    setState({
      ...state,
      selectedContent: formattedContent,
      drawerWidth: Math.min(window.innerWidth - 100, 600),
    });

    // //setState({ ...state, selectedContent: content });
  };

  const handleAction = (action) => {
    // Handle the action button click here
    console.log("Action clicked:", action);
  };

  const drawerWidth = jsonData.buttonData.length * 100; // Adjust the multiplier as needed

  //   const handleClearNotifications = () => {
  //     // Implement logic to clear notifications
  //     console.log("Clearing all notifications");
  //     // You can reset the selectedContent to clear notifications
  //     setState({ ...state, selectedContent: "" });
  //   };
  const handleClearNotifications = () => {
    // Show confirmation dialog
    setState({ ...state, confirmClear: true });
  };

  const handleCloseConfirmation = () => {
    // Close confirmation dialog
    setState({ ...state, confirmClear: false });
  };

  const handleConfirmClear = () => {
    // Implement logic to clear notifications
    console.log("Clearing all notifications");
    setState({ ...state, selectedContent: "", confirmClear: false });
  };
  return (
    <div>
      <div
        className="flex items-center cursor-pointer"
        onClick={handleNotificationsClick}
      >
        <SvgIcon url={Notifications} colorClass="" />
        <span className="label label_md label_primary hidden lg:block ml-1">
          Notification
        </span>
      </div>
      {/* Three-dot vertical icon for clearing notifications */}

      {/* Right Drawer */}
      <Drawer
        anchor="right"
        open={state.right}
        onClose={toggleDrawer("right", false)}
        sx={{ "& .MuiDrawer-paper": { width: state.drawerWidth } }}
      >
        <Box
          sx={{ width: drawerWidth }}
          role="presentation"
          // onClick={toggleDrawer("right", false)}
          onKeyDown={toggleDrawer("right", false)}
        >
          {/* Dynamically create buttons */}
          <div className="flex flex-wrap">
            {jsonData.buttonData.map((button) => (
              <button
                key={button.id}
                onClick={() => handleContentChange(button)}
                className="px-4 py-2 border-[1px] border-[#C6C6C6] bg-[#F1F1F1] hover:bg-gray-200 rounded-md mr-2 mb-2 flex-grow-0"
                // Add styling to the button
              >
                {button.label}
              </button>
            ))}
            <div style={{ position: "absolute", top: 0, right: 0 }}>
              <IconButton onClick={handleClearNotifications}>
                <MoreVertIcon />
              </IconButton>
            </div>
            <Dialog
              open={state.confirmClear}
              onClose={handleCloseConfirmation}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
            >
              <DialogTitle id="alert-dialog-title">
                Confirm Clear Notifications
              </DialogTitle>
              <DialogContent>
                <Typography variant="body1" gutterBottom>
                  Are you sure you want to clear all notifications?
                </Typography>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleCloseConfirmation} color="primary">
                  Cancel
                </Button>
                <Button onClick={handleConfirmClear} color="primary" autoFocus>
                  Confirm
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        </Box>

        {/* Content based on selectedContent */}
        <Typography variant="h6">{state.selectedContent}</Typography>
      </Drawer>
    </div>
  );
}

export default Notification;
