export const truncateText = (text, maxLength) => {
  if (text.length > maxLength) {
    return text.substring(0, maxLength) + "...";
  }
  return text;
};
export const compareStr = (strFirst, strSecond) =>
  strFirst
    .toLowerCase()
    .replace(/[-\s]+/g, " ")
    .trim() ===
  strSecond
    .toLowerCase()
    .replace(/[-\s]+/g, " ")
    .trim();

export const isArrayEmpty = (arr) => {
  return !Array.isArray(arr) || arr.length === 0;
};

export const areObjectsEqual = (obj1, obj2) => {
  if (
    typeof obj1 === "object" &&
    obj1 !== null &&
    typeof obj2 === "object" &&
    obj2 !== null
  ) {
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);

    if (keys1.length !== keys2.length) {
      return false;
    }

    for (const key of keys1) {
      if (!keys2.includes(key) || !areObjectsEqual(obj1[key], obj2[key])) {
        return false;
      }
    }

    return true;
  } else {
    return obj1 === obj2;
  }
};

export const removeDuplicates = (array) => {
  return array.filter(
    (item, index) =>
      array.findIndex((otherItem) => areObjectsEqual(item, otherItem)) ===
      index,
  );
};
