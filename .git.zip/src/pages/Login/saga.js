import { put, select, takeLatest } from "redux-saga/effects";
import { USER_LOGIN } from "./types";
import {
  getUserLoginSuccessAction,
  getUserLoginFailureAction,
} from "./loginFormSlice";
import { loginSelector } from "../../store/selector";
import { makeApiRequest } from "../../utils/apiUtils";

// Generator function
function* getLoginSaga(data) {
  try {
    // You can also export the axios call as a function.
    const loginSelectorValues = yield select(loginSelector);
    const payload = {
      mobileNumber: loginSelectorValues.mobileNumber,
      passWord: data.payload,
    };
    const response = yield makeApiRequest("/posts", "POST", payload);
    yield put(getUserLoginSuccessAction(response.data));
    // yield put(getUserLoginSuccessAction({}));
  } catch (error) {
    yield put(getUserLoginFailureAction(error));
  }
}
// Generator function
export function* watchGetLogin() {
  yield takeLatest(USER_LOGIN, getLoginSaga);
}
