import { PRODUCTS } from "../../const/ProductConst";
import { compareStr } from "../../utils/commonUtils";
export const findMatchingTypes = (data, title) => {
  for (const { faq_type, product_types } of data) {
    if (compareStr(faq_type, PRODUCTS)) {
      for (const { sub_types } of product_types) {
        const matchingSubType = sub_types.find((subType) =>
          compareStr(subType.screen_title, title),
        );
        if (matchingSubType) {
          return matchingSubType.types;
        }
      }
    }
  }
  return null;
};
