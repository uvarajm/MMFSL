import * as Yup from "yup";

export const validation = (str) => Yup.string().required(str);

export const mobileNumberValidation = (str) => {
  return Yup.string()
    .matches(/^[6-9]\d{9}$/, "Enter a valid mobile number")
    .max(10, "Mobile number can't be longer than 10 digits")
    .required(str);
};

export const passwordValidation = (str) => {
  return Yup.string().required(str).min(10);
};

export const pinCodeValidation = () => {
  return Yup.string()
    .matches(
      /^[1-9]{1}[0-9]{2}\s{0,1}[0-9]{3}$/,
      "Enter a valid  pincode number",
    )
    .max(6, "Pincode can't be longer than 6 digits");
};

export const passwordWithStrengthValidation = (str) => {
  return validation(str)
    .min(10)
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?!.*(123|234|345|456|567|678|789|012))[a-zA-Z\d]{10,}$/,
      "Password should only contain below mentioned characters",
    );
};

export const termsAndConditionsValidation = (str) => {
  return Yup.boolean().required(str);
};

export const getOtpValidation = (str) => {
  return Yup.number()
    .typeError(str)
    .required("Enter OTP")
    .min(0, "OTP must be 6 digits")
    .max(9, "OTP must be 6 digits");
};

export const cityValidation = () => {};
export const stateValidation = () => {};
