import PropTypes from "prop-types";
import FaqAccordion from "../../components/Accordion/FaqAccordion";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import NoData from "../../components/Common/NoData";

const GeneralFaq = ({ generalFaqData, loading, error }) => {
  if (!generalFaqData) {
    return <NoData errorText="FAQ not Exist" />;
  }

  return (
    <HandleDataRendering data={generalFaqData} loading={loading} error={error}>
      <div className="flex flex-wrap lg:flex-nowrap w-full">
        <div className="w-full">
          {generalFaqData?.length === 0 ? (
            <div>No general FAQs available</div>
          ) : (
            generalFaqData.map((generalItem, index) =>
              generalItem.general_types.map((type) => (
                <section key={`${index}-${type.id}`}>
                  <h4 className="subtitle">{type.header}</h4>
                  <div className="bg-white rounded p-2 pb-0 lg:p-4">
                    <FaqAccordion items={type.faq} />
                  </div>
                </section>
              )),
            )
          )}
        </div>
      </div>
    </HandleDataRendering>
  );
};

GeneralFaq.propTypes = {
  generalFaqData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  error: PropTypes.object,
  loading: PropTypes.bool,
};

export default GeneralFaq;
