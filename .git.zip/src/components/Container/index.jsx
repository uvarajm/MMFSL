import PropTypes from "prop-types";

const Container = ({ className = "", children }) => {
  return (
    <section className={`flex justify-center lg:items-center ${className}`}>
      {children}
    </section>
  );
};

Container.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
};

export default Container;
