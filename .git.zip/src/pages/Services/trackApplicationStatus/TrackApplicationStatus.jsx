import { MainContainer } from "../../../components";
import Breadcrumb from "../../../components/Breadcrumb";
// import { APPLICATION_STATUS } from "../../../store/actions/actions";
import ApplicationCard from "../../../components/Card/ApplicationCard";
import jsonData from "../../../Data/applicationstatus.json";
const TrackApplicationStatus = () => {
  // [Todo][Yogesh]  use this functionality when you calling API Data.
  // const dispatch = useDispatch();
  // const { applicationStatus, loading, error } = useSelector(
  //   (state) => state.applicationStatus
  // );

  // useEffect(() => {
  //   dispatch({ type: APPLICATION_STATUS }); // Dispatch action to fetch data
  // }, [dispatch]);
  // if (loading) {
  //   return <div>Loading...</div>;
  // }

  // if (error) {
  //   return <div>Error: {error}</div>;
  // }
  return (
    <MainContainer className="p-4">
      <Breadcrumb />
      <ApplicationCard applicationData={jsonData.data} />
    </MainContainer>
  );
};
export default TrackApplicationStatus;

// const MyComponent = () => {
//   const dispatch = useDispatch();
//   const { data, loading, error } = useSelector((state) => state.data);

//   useEffect(() => {
//     dispatch(fetchDataStart());
//   }, [dispatch]);

//   if (loading) {
//     return <div>Loading...</div>;
//   }

//   if (error) {
//     return <div>Error: {error}</div>;
//   }

//   return (
//     <div>
//       {data.map((item) => (
//         <div key={item.applicationNumber}>
//           <p>{item.applicantName}</p>
//           {/* Render other data here */}
//         </div>
//       ))}
//     </div>
//   );
// };

// export default MyComponent;
