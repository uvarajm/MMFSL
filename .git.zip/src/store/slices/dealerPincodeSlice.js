import { createSlice } from "@reduxjs/toolkit";
import { DEALER_PINCODE_DATA } from "../actions/actions";

const initialState = {
  dealerPinCodeData: {},
  loading: false,
  error: null,
};

const dealerPincodeSlice = createSlice({
  name: DEALER_PINCODE_DATA,
  initialState,
  reducers: {
    fetchDealerPinCodeStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchDealerPinCodeDataSuccess(state, action) {
      state.loading = false;
      state.dealerPinCodeData = action.payload;
    },
    fetchDealerPinCodeDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchDealerPinCodeStatusData,
  fetchDealerPinCodeDataSuccess,
  fetchDealerPinCodeDataFailure,
} = dealerPincodeSlice.actions;

export default dealerPincodeSlice.reducer;
