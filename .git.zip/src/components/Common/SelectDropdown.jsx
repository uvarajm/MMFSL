import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  styled,
} from "@mui/material";
import PropTypes from "prop-types";
import { KeyboardArrowDown, KeyboardArrowUp } from "@mui/icons-material";
import { useState } from "react";
import { capitalizeWords } from "../../utils/utils";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    sx: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: "180px",
      backgroundColor: "#ffffff",
      boxShadow: "1px 1px 3px 0 rgba(186, 143, 148, 0.4)",
      borderRadius: "8px",
      "& .MuiMenuItem-root": {
        color: "#333333",
        fontFamily: "Karla",
        fontWeight: 400,
        lineHeight: "22px",
        fontSize: 16,
        "&:hover": {
          backgroundColor: "#EDE0E3",
        },
        "&:focus": {
          backgroundColor: "transparent",
          boxShadow: "none",
        },
      },
    },
  },
};

const CustomSelect = styled(Select)({
  backgroundColor: "transparent",
  "&.MuiSelect-root:focus": {
    backgroundColor: "transparent",
  },
  "&.MuiSelect-root.MuiInputBase-root.MuiInput-root:focus": {
    backgroundColor: "none",
  },
  "&.MuiInputBase-root.MuiInput-root::before": {
    borderBottom: "1px solid #691A1E",
    paddingBottom: "17px",
  },
  "&.MuiInputBase-root.MuiInput-root:hover:not(.Mui-disabled)::before": {
    borderBottom: "1px solid #691A1E",
    paddingBottom: "17px",
  },
  "&.MuiInputBase-root.MuiInput-root.Mui-focused::after": {
    borderBottom: "1px solid #691A1E",
    backgroundColor: "transparent",
    paddingBottom: "17px",
    boxShadow: "none",
  },
  "&.MuiInputLabel-root.Mui-focused::after": {
    color: "#691A1E",
    pl: 0,
    backgroundColor: "transparent",
  },
  "&.MuiInputBase-input": {
    backgroundColor: "transparent",
    paddingLeft: 10,
    paddingBottom: "13px",
    fontFamily: "Karla",
    // cursor: "not-allowed"
  },
  "&.Mui-disabled": {
    opacity: 0.5,
  },
});

const CustomInputLabel = styled(InputLabel)({
  color: "#691A1E",
  fontWeight: 600,
  "&.Mui-focused": {
    color: "#691A1E",
  },
});

const SelectDropdown = ({
  label,
  minWidth,
  options,
  optionLabelProp,
  optionValueProps,
  selectedValue = "",
  setSelectedValue,
  disabled,
}) => {
  const [open, setOpen] = useState(false);

  return (
    <FormControl variant="standard" sx={{ width: minWidth }}>
      <CustomInputLabel
        id="demo-simple-select-standard-label"
        className="text-red-800"
        sx={{
          color: disabled ? "" : "#691A1E",
          opacity: disabled ? "0.6" : "1",
          fontSize: 16,
          fontFamily: "Quicksand",
          fontWeight: 600,
          pl: "12px",
        }}
      >
        {label}
      </CustomInputLabel>
      <CustomSelect
        disabled={disabled}
        labelId="demo-simple-select-standard-label"
        id="demo-simple-select-standard"
        value={selectedValue}
        onChange={(e) => setSelectedValue(e.target.value)}
        label={label}
        IconComponent={
          open
            ? (props) => <KeyboardArrowUp {...props} sx={{ fill: "#691A1E" }} />
            : (props) => (
                <KeyboardArrowDown {...props} sx={{ fill: "#691A1E" }} />
              )
        }
        MenuProps={MenuProps}
        sx={{
          margin: "0px",
          boxShadow: "none",
          cursor: disabled ? "not-allowed" : "pointer",
          "& .MuiInputBase-input": {
            cursor: disabled ? "not-allowed" : "pointer",
          },
        }}
      >
        {options.length > 0 ? (
          options?.map((item) => (
            <MenuItem
              key={item[optionValueProps]}
              value={item[optionValueProps]}
              onOpen={() => setOpen(true)}
              onClose={() => setOpen(false)}
            >
              {capitalizeWords(item[optionLabelProp])}
            </MenuItem>
          ))
        ) : (
          <MenuItem
            disabled
            sx={{
              color: "#691A1E",
              fontSize: 16,
              fontFamily: "Quicksand",
              fontWeight: 600,
            }}
          >
            No data found
          </MenuItem>
        )}
      </CustomSelect>
    </FormControl>
  );
};

SelectDropdown.propTypes = {
  label: PropTypes.string,
  minWidth: PropTypes.string,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      stateName: PropTypes.string,
    }),
  ),
  optionLabelProp: PropTypes.string,
  selectedValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  setSelectedValue: PropTypes.func,
  optionValueProps: PropTypes.string,
  disabled: PropTypes.bool,
};

export default SelectDropdown;
