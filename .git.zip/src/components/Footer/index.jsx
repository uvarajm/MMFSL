import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { FOOTER } from "../../const/common";

const Footer = () => {
  const { theme } = useSelector((state) => state.theme);
  return (
    <div
      className={`height border-t-[1px] px-4 lg:px-[48px] border-lilac-light footer-light lg:z-[11] ${
        theme === "light" ? "footer-light" : "footer-dark"
      }`}
    >
      <div className="max-w-full mx-auto flex justify-center lg:items-center lg:justify-between h-full text-grey-500 font-normal text-sm max-lg:flex-col-reverse ">
        <p className="content content_md content_secondary">
          &#169; {new Date().getFullYear()}{" "}
          <span className="content content_md content_secondary">
            {FOOTER.TITLE}
          </span>
        </p>

        <div className="space-x-5">
          <Link
            to={"/terms-and-conditions"}
            className="content content_md content_primary"
          >
            {FOOTER.TERMS_CONDITION}
          </Link>
          <Link
            to={"/privacy-policy"}
            className="content content_md content_primary"
          >
            {FOOTER.PRIVACY_POLICY}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Footer;
