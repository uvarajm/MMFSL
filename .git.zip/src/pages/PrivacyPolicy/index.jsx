import DOMPurify from "dompurify";
import { MainContainer } from "../../components";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import OfferSidebar from "../../components/OfferSidebar";
import usePrivacyPolicyContent from "./usePrivacyPolicyContent";
const PrivacyPolicy = () => {
  const sanitizer = DOMPurify.sanitize;
  const { privacyPolicyPageContent, loading, error } =
    usePrivacyPolicyContent();

  return (
    <MainContainer className={"px-6 pb-6"}>
      <HandleDataRendering
        data={privacyPolicyPageContent}
        loading={loading}
        error={error}
      >
        <div className={`sidebar-width`}>
          <div className="w-full">
            <div className={`dark:bg-dark-coral`}>
              <h1
                className={`font-medium text-[24px] text-red-800 dark:text-white leading-[30px] font-quicksand`}
              >
                Privacy Policy
              </h1>
            </div>
            <div className="">
              <div
                dangerouslySetInnerHTML={{
                  __html: privacyPolicyPageContent
                    ? sanitizer(privacyPolicyPageContent)
                    : "something went wrong",
                }}
              />
            </div>
          </div>
        </div>
        <OfferSidebar />
      </HandleDataRendering>
    </MainContainer>
  );
};
export default PrivacyPolicy;
