import { createSlice } from "@reduxjs/toolkit";
import { REGISTER_USER } from "../actions/actions";

const initialState = {
  registerUser: {},
  loading: false,
  error: null,
  mobileNumber: "",
  tncFlag: 0,
};

const registerSlice = createSlice({
  name: REGISTER_USER,
  initialState,
  reducers: {
    fetchRegisterStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchRegisterDataSuccess(state, action) {
      state.loading = false;
      state.registerUser = action.payload;
    },
    fetchRegisterDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    setMobileNumber(state, action) {
      state.mobileNumber = action.payload;
    },
    setTermsCondition(state, action) {
      state.tncFlag = action.payload;
    },
  },
});

export const {
  fetchRegisterStatusData,
  fetchRegisterDataSuccess,
  fetchRegisterDataFailure,
  setMobileNumber,
  setTermsCondition,
} = registerSlice.actions;

export default registerSlice.reducer;
