import PropTypes from "prop-types";
import { useState } from "react";
import { Drawer } from "@mui/material";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
import { FaTimes } from "react-icons/fa";
import CustomAccordion from "../Accordion";
import { items } from "../../utils/utils";

const Help = (props) => {
  const [open, setOpen] = useState(false);

  const { helpHeading = "", helpTitle = "" } = props;

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div className="">
      <div
        className="flex items-center gap-1 justify-end label label_md cursor-pointer text-black-100"
        onClick={() => setOpen(true)}
      >
        <p>Help</p>
        <span className="text-sm">
          <HelpOutlineIcon fontSize="" />
        </span>
      </div>

      <Drawer anchor="right" open={open} onClose={handleClose}>
        <div className="py-6 px-4 w-[100vw] lg:w-[600px]">
          <div className="flex flex-col gap-6">
            <div className="flex justify-between items-center">
              <h1 className="text-xl font-semibold">{helpHeading}</h1>
              <FaTimes
                onClick={handleClose}
                className="cursor-pointer hover:border rounded-md p-1 text-2xl"
              />
            </div>
            <div className="flex flex-col gap-4">
              <h4 className="text-xl font-semibold border-b-2 pb-1 border-[#3C3B3B]">
                {helpTitle}
              </h4>
              <CustomAccordion items={items} />
            </div>
          </div>
        </div>
      </Drawer>
    </div>
  );
};

Help.propTypes = {
  helpTitle: PropTypes.string,
  helpHeading: PropTypes.string,
};

export default Help;
