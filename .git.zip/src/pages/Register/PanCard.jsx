import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useSelector } from "react-redux";
import { Input, Button, Alert } from "../../components";
import { Container } from "../../components";
import {
  termsAndConditionsValidation,
  validation,
} from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";
import { REGISTRATION } from "../../const/common";
function PanCard() {
  const navigate = useNavigate();
  const [wrongAttempts, setWrongAttempts] = useState(0);
  const [alertError, setAlertError] = useState(false);
  const register = useSelector((state) => state.register);
  const termsAccepted = false;
  const initialValues = {
    panDetails: "",
    termsAndCondition: false,
  };
  const validationSchema_pan = Yup.object({
    panDetails: validation("Enter Pan").min(10),
    termsAndCondition: termsAndConditionsValidation("Accept Terms"),
  });
  const loanClick = () => {
    navigate("/register/loan-details");
  };
  const onSubmit = (values, { setFieldError }) => {
    if (values.panDetails === "ABCDE1234F") {
      navigate("/register/set-password");
    } else {
      setWrongAttempts((prevAttempts) => prevAttempts + 1);
      if (wrongAttempts >= 2) {
        setAlertError(true);
      } else {
        setFieldError(
          "panDetails",
          `Sorry you have entered an invalid PAN number. ${
            wrongAttempts == 0 ? wrongAttempts + 2 : wrongAttempts
          } attempts remaining.`,
        );
      }
    }
  };
  return (
    <Container>
      <div className="relative w-full max-w-md mx-auto flex flex-col p-4">
        <div className="mt-5 mb-[36px]">
          <div className="flex flex-col flex-1 gap-2 lg:pt-4">
            <div className="flex lg:block">
              <BackButton />
              <h1 className="headline headline_xl headline_primary">
                {REGISTRATION.VERIFICATION}
              </h1>
            </div>
            <p className="mb-4 sm:text-base content content_lg content_secondary">
              {REGISTRATION.PLEASE_VERIFY}
            </p>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema_pan}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="flex flex-col space-y-6">
                  <div className="flex flex-col space-y-2">
                    <Input
                      name="panDetails"
                      label={REGISTRATION.PAN}
                      placeholder=""
                      formik={formik}
                      disabled={alertError}
                      maxLength={10}
                      className={`label label_md border-red ${
                        alertError
                          ? "text-disable-red border-disable-red "
                          : "text-grey-500 border-red-100"
                      }`}
                    />
                    <p
                      className={`content content_md content_secondary ${
                        alertError ? "text-disable-red" : "text-grey-500"
                      }`}
                    >
                      {REGISTRATION.EG_AB}
                    </p>
                  </div>
                  {!alertError && (
                    <div className="lg:pt-10 pt-44">
                      <Button
                        type="submit"
                        name={REGISTRATION.BTN_VERI}
                        disabled={
                          !(formik.isValid && formik.dirty) ||
                          alertError ||
                          (!register.isPan && !termsAccepted)
                        }
                        className=" text-white w-full  h-[42px] text-[14px] rounded-md bg-red-500 disabled:bg-disable-red disabled:text-red-200 disabled:cursor-not-allowed"
                      >
                        {REGISTRATION.BTN_VERI}
                      </Button>
                    </div>
                  )}
                  {alertError && (
                    <Alert
                      className="bg-white rounded-sm text-grey-500 text-[12px]   font-karla"
                      errorMessage=""
                    >
                      {REGISTRATION.ERROR_MESSAGE}{" "}
                      <span className="text-red-500">
                        {REGISTRATION.NEAR_BRANCH}
                      </span>{" "}
                      {REGISTRATION.RES}
                    </Alert>
                  )}
                  <button
                    type="button"
                    name={REGISTRATION.TRY_LOAN}
                    className={`mt-6 w-full  h-[42px] py-2 rounded-md text-[14px] font-quicksand font-bold ${
                      alertError
                        ? "bg-red-500 text-white"
                        : "text-red-500 border border-red-500 dark:border-red-700 dark:text-red-700"
                    }`}
                    onClick={loanClick}
                  >
                    {REGISTRATION.TRY_LOAN}
                  </button>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </Container>
  );
}
export default PanCard;
