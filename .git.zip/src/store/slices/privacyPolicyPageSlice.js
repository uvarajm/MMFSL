import { createSlice } from "@reduxjs/toolkit";
import { GET_PRIVACY_POLICY } from "../actions/actions";
const initialState = {
  privacyPolicyPageContent: [],
  loading: false,
  error: null,
};
const privacyPolicyPageSlice = createSlice({
  name: GET_PRIVACY_POLICY,
  initialState,
  reducers: {
    fetchPrivacyPolicyPageData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchPrivacyPolicyPageDataSuccess(state, { payload }) {
      state.loading = false;
      state.privacyPolicyPageContent = payload;
    },
    fetchPrivacyPolicypageDataFailure(state, { payload }) {
      state.loading = false;
      state.error = payload;
    },
  },
});

export const {
  fetchPrivacyPolicyPageData,
  fetchPrivacyPolicyPageDataSuccess,
  fetchPrivacyPolicypageDataFailure,
} = privacyPolicyPageSlice.actions;

export default privacyPolicyPageSlice.reducer;
