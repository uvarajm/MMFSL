import { createSlice } from "@reduxjs/toolkit";
import { LEAD_GEN } from "../actions/actions";

const initialState = {
  leadGenData: {},
  loading: false,
  error: null,
};
const leadGenSlice = createSlice({
  name: LEAD_GEN,
  initialState,
  reducers: {
    fetchLeadGenStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchLeadGenDataSuccess(state, action) {
      state.loading = false;
      state.leadGenData = action.payload;
    },
    fetchLeadGenDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchLeadGenStatusData,
  fetchLeadGenDataSuccess,
  fetchLeadGenDataFailure,
  setFullName,
  setPincode,
  setProductSubCategory,
} = leadGenSlice.actions;

export default leadGenSlice.reducer;
