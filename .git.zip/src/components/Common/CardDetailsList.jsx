import PropTypes from "prop-types";
import moment from "moment";
import { DDMMMYYYY } from "../../const/common";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import SvgIcon from "./SvgIcon";
import iconConfig from "../../assets/iconsConfig";

const CardDetailsList = ({ details, handleRedirection }) => {
  const { ServiceIcon } = iconConfig;
  const handleCallBack = (dynamicRouteValue) => {
    handleRedirection(dynamicRouteValue);
  };
  return (
    <div className="w-full lg:w-2/4 lg:p-2 pb-3 lg:-m-2 ">
      <div className="rounded-lg bg-white p-3">
        <div
          className={`flex border-b pb-4 items-center cursor-pointer border-light-border-color dark:border-dark-border-color`}
          onClick={() => handleCallBack(details.caseNumber)}
        >
          <SvgIcon url={ServiceIcon} />
          <div className={`flex flex-col pl-2 w-full  text-light-text-primary`}>
            <div className="flex justify-between items-center">
              <p className={`text-sm font-medium`}>Service request</p>
            </div>
            <p className="text-sm font-semibold">{details.caseNumber}</p>
          </div>
          <KeyboardArrowRightIcon className="text-red-500" />
        </div>
        <div className="flex justify-between flex-wrap mt-2">
          <div className="w-2/4 text-sm py-1">
            <div className={`text-light-text-primary font-semibold`}>
              Category
            </div>
            <div className="text-grey-500 font-karla">{details.category}</div>
          </div>
          <div className="w-2/4 text-sm py-1">
            <div className={`text-light-text-primary font-semibold`}>
              Product
            </div>
            <div className="text-grey-500 font-karla">
              {details.productName}
            </div>
          </div>
          <div className="w-2/4 text-sm py-1">
            <div className={`text-light-text-primary font-semibold`}>
              Created on
            </div>
            <div className="text-grey-500 font-karla">
              {moment(details.caseCreatedAt).format(DDMMMYYYY)}
            </div>
          </div>
          <div className="w-2/4 text-sm py-1">
            <div className={`text-light-text-primary font-semibold`}>
              Last updated
            </div>
            <div className="text-grey-500 font-karla">
              {moment(details.caseUpdatedAt).format(DDMMMYYYY)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardDetailsList;

CardDetailsList.propTypes = {
  details: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  handleRedirection: PropTypes.func,
};
