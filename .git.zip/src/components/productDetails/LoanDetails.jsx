import PropTypes from "prop-types";
import moment from "moment";
import {
  DDMMMYY,
  PRODUCT_DETAILS_CONSTANTS,
  RUPEE_SYMBOL,
} from "../../const/common";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import Info from "./Info";
import { isObjectBlank, hasBlankValue } from "../../utils";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../Common/SvgIcon";

const LoanDetails = (props) => {
  return (
    <>
      <div
        className={` ${
          props?.title == "Insurance details"
            ? ""
            : "border-b border-lilac-light "
        }`}
        id={props?.id}
      >
        <div className="text-base font-semibold lg:text-[20px] mb-2 lg:mb-[18px] flex justify-between">
          {props?.title}
          {props?.title === "Bank Details" ? (
            <span className="text-red-500 font-semibold text-xs lg:text-base flex items-center cursor-pointer">
              {PRODUCT_DETAILS_CONSTANTS.COMMON.MODIFY_MANDATE}{" "}
              <ChevronRightIcon />
            </span>
          ) : (
            ""
          )}
        </div>
        {!isObjectBlank(props?.basicDetailsResponse) ? (
          <>
            <div className="flex flex-wrap -mx-2 mb-6">
              {Object.entries(props?.basicDetailsResponse)
                .filter(
                  ([key]) =>
                    !PRODUCT_DETAILS_CONSTANTS.EXCLUDED_KEYS.includes(key),
                )
                .map(([key, value], index) => {
                  if (key) {
                    return (
                      <div
                        key={`${key}-${index}`}
                        className="lg:w-1/4 w-1/2 p-2"
                      >
                        <div className="loan_details__label">
                          {PRODUCT_DETAILS_CONSTANTS.OTHER_DETAILS[key]}
                        </div>
                        <div className="text-xs primary-description break-all">
                          {PRODUCT_DETAILS_CONSTANTS.OTHER_DETAILS[key] ===
                          PRODUCT_DETAILS_CONSTANTS.OTHER_DETAILS
                            .POLICY_START_DATE
                            ? `${moment(
                                props?.basicInsuranceDetails.POLICY_START_DATE,
                              ).format(DDMMMYY)} - ${moment(
                                props?.basicInsuranceDetails.POLICY_EXPIRY_DATE,
                              ).format(DDMMMYY)}`
                            : PRODUCT_DETAILS_CONSTANTS.SHOW_RUPEE_SYMBOL.includes(
                                  key,
                                )
                              ? RUPEE_SYMBOL + " " + value
                              : value == ""
                                ? "-"
                                : value}
                        </div>
                      </div>
                    );
                  }
                })}
            </div>
          </>
        ) : (
          ""
        )}
        {props?.sectionKey == "basicBankDetails" &&
        hasBlankValue(props.basicDetailsResponse) ? (
          <Info
            icon={<SvgIcon url={iconConfig.Notification} />}
            text={PRODUCT_DETAILS_CONSTANTS.COMMON.BANK_DETAILS_INFO}
            redirectText={"Set mandate"}
            redirectLink={"#"}
          />
        ) : (
          ""
        )}
        {props.sectionKey === "basicAssetDetails" &&
        hasBlankValue(props.basicDetailsResponse) ? (
          <Info
            icon={<SvgIcon url={iconConfig.Reminder} />}
            text={PRODUCT_DETAILS_CONSTANTS.COMMON.VEHICLE_DETAILS_INFO}
            redirectText={"Update"}
            redirectLink={"#"}
          />
        ) : (
          ""
        )}
        {props.sectionKey === "basicInsuranceDetails" &&
        isObjectBlank(props.basicDetailsResponse) ? (
          <Info
            icon={<SvgIcon url={iconConfig.Reminder} />}
            text={PRODUCT_DETAILS_CONSTANTS.COMMON.INSURANCE_DETAILS_INFO}
            redirectText={"Explore now"}
            redirectLink={"#"}
          />
        ) : (
          ""
        )}
      </div>
    </>
  );
};

LoanDetails.propTypes = {
  title: PropTypes.string,
  id: PropTypes.string,
  basicDetailsResponse: PropTypes.object,
  sectionKey: PropTypes.string,
  basicInsuranceDetails: PropTypes.shape({
    POLICY_START_DATE: PropTypes.string,
    POLICY_EXPIRY_DATE: PropTypes.string,
  }),
};

export default LoanDetails;
