import PropTypes from "prop-types";
import { Checkbox } from "@mui/material";
import { useSelector } from "react-redux";

const CheckBox = (props) => {
  const { theme } = useSelector((state) => state.theme);
  const { label, checked, onChange, ...rest } = props;
  return (
    <div className="flex items-center gap-1">
      <Checkbox
        checked={checked}
        onChange={onChange}
        label={label}
        {...rest}
        sx={{
          width: "18px",
          height: "18px",
          // color: "#691A1E",
          color: theme === "dark" ? "#EDE0E3" : "#691A1E",
          "&.Mui-checked": {
            color: theme === "dark" ? "#EDE0E3" : "#691A1E",
          },
        }}
      />
      <span className="pl-2 content content_md content_secondary leading-4 ">
        {label}
      </span>
    </div>
  );
};

CheckBox.propTypes = {
  label: PropTypes.string,
  checked: PropTypes.bool,
  onChange: PropTypes.func,
};

export default CheckBox;
