import PropTypes from "prop-types";

const ThreeColDetails = ({ data }) => {
  return (
    <div className="bg-lilac-light rounded-lg py-[13px] px-[17px] flex mb-[20px] lg:mb-[28px]">
      {data.map((item, index) => (
        <div
          key={index}
          className="w-1/3 p-2 flex items-center justify-center flex-col border-r border-disable-red last:border-none"
        >
          <div className="text-xs text-red-800 lg:text-sm mb-2 lg:font-medium">
            {item.label}
          </div>
          <div className="text-sm text-red-800 font-semibold lg:text-[20px]">
            {item.value}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ThreeColDetails;

ThreeColDetails.propTypes = {
  data: PropTypes.array,
};
