import { createSlice } from "@reduxjs/toolkit";
import { BRANCH_STATE_CITY_CODE } from "../actions/actions";

const initialState = {
  branchStateCityCodeData: {},
  loading: false,
  error: null,
};

const branchStateCityCodeSlice = createSlice({
  name: BRANCH_STATE_CITY_CODE,
  initialState,
  reducers: {
    fetchBranchStateCityStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchBranchStateCityDataSuccess(state, action) {
      state.loading = false;
      state.branchStateCityCodeData = action.payload;
    },
    fetchBranchStateCityDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchBranchStateCityStatusData,
  fetchBranchStateCityDataSuccess,
  fetchBranchStateCityDataFailure,
} = branchStateCityCodeSlice.actions;

export default branchStateCityCodeSlice.reducer;
