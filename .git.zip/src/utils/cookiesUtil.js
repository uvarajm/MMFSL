export const getTokenFromCookies = (tokenName) => {
  const cookies = document.cookie.split(";").map((cookie) => cookie.trim());
  const tokenCookie = cookies.find((cookie) =>
    cookie.startsWith(`${tokenName}=`),
  );
  if (tokenCookie) {
    const tokenValue = tokenCookie.split("=")[1];
    const tokenParts = tokenValue.split("|");
    if (tokenParts.length === 2) {
      return tokenParts[0];
    }
  }
  return null;
};

export const setTokenInCookies = (tokenName, token, expiresIn) => {
  const now = new Date();
  now.setTime(now.getTime() + expiresIn * 1000);
  const expires = now.toUTCString();
  document.cookie = `${tokenName}=${token}|${expires}; expires=${expires}; path=/; secure; SameSite=Strict;`;
};

export const isTokenExpired = (tokenName) => {
  const cookies = document.cookie.split(";").map((cookie) => cookie.trim());
  const tokenCookie = cookies.find((cookie) =>
    cookie.startsWith(`${tokenName}=`),
  );
  if (tokenCookie) {
    const tokenValue = tokenCookie.split("=")[1];
    const tokenParts = tokenValue.split("|");
    if (tokenParts.length === 2) {
      const expiryDate = new Date(tokenParts[1]);
      return new Date() > expiryDate;
    }
  }
  return true;
};

export const removeTokenFromCookies = (tokenName) => {
  document.cookie = `${tokenName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; secure; SameSite=Strict;`;
};
