import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchValidateOtpStatusData,
  fetchValidateOtpDataSuccess,
  fetchValidateOtpDataFailure,
} from "../slices/validateOtpSlice";
import { VALIDATE_OTP } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";
function* fetchValidateOtpStatus({ payload }) {
  try {
    yield put(fetchValidateOtpStatusData());
    const response = yield call(
      makeApiRequest,
      endpoints.validateOtp,
      BACKEND_TOKEN,
      "POST",
      payload,
    );
    yield put(fetchValidateOtpDataSuccess(response?.data));
  } catch (error) {
    yield put(fetchValidateOtpDataFailure(error.message));
  }
}
export function* watchFetchValidateOtp() {
  yield takeLatest(VALIDATE_OTP, fetchValidateOtpStatus);
}
