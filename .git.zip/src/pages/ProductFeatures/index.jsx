import { useState, useEffect, useRef } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { Breadcrumb, MainContainer } from "../../components";
import FeaturesList from "../../components/Common/FeaturesList";
import EmiCalculator from "../../components/EmiCalculator";
import Eligibility from "../../components/Common/Eligibility";
import StepperTitle from "../../components/Common/StepperTitle";
import Faq from "./Faq";
import { useNavigate } from "react-router-dom";
import BackButton from "../../components/Common/BackButton";
import Sidebar from "../../components/OfferSidebar";
import Button from "@mui/material/Button";
import Feedback from "../../components/Feedback";
import { isObjectBlank } from "../../utils";
import PreApprovedOfferBanner from "./PreApprovedOfferBanner";

const ProductFeatures = () => {
  const [activeTab, setActiveTab] = useState(1);
  const [isSticky, setIsSticky] = useState(false);
  const [productDetail, setProductDetail] = useState({});
  const [showFeedback, setShowFeedback] = useState(false);
  const { theme } = useSelector((state) => state.theme);
  const orderedTabs = [
    "Features and Benefits",
    "EMI Calculator",
    "Eligibility & Documents",
    "How to Apply",
    "FAQs",
  ];
  const navigate = useNavigate();
  const contentRefs = useRef([]);
  const { categoryProduct: fullProductFeatures } = useSelector(
    (state) => state.categoryProduct,
  );
  const { title, loanType } = useParams();

  const findTabsDetails = (productSubType) => {
    const foundItem = fullProductFeatures.product_feature.find(
      (item) => item.product_type === loanType,
    );
    if (foundItem) {
      const foundType = foundItem.types.find(
        (type) => type.product_sub_type === productSubType,
      );
      if (foundType) {
        return foundType;
      }
    }
    return null;
  };
  useEffect(() => {
    if (isObjectBlank(fullProductFeatures)) {
      navigate("/product");
      return;
    }
    setProductDetail(findTabsDetails(title));
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const headerOffset = 150; // Adjusted for sticky header

      // Calculate the positions of each content section relative to the document
      const sectionPositions = contentRefs.current.map((ref) => {
        return {
          index: parseInt(ref.id.split("-")[1], 10),
          position: ref.offsetTop - headerOffset,
        };
      });

      // Find the index of the section closest to the top of the viewport
      const activeTabIndex = sectionPositions.reduce(
        (closestIndex, section, currentIndex) => {
          // Ensure sectionPositions[closestIndex] is defined before accessing its properties
          if (sectionPositions[closestIndex]) {
            const isCloser =
              Math.abs(section.position - scrollPosition) <
              Math.abs(
                sectionPositions[closestIndex].position - scrollPosition,
              );
            return isCloser ? currentIndex : closestIndex;
          } else {
            return currentIndex;
          }
        },
        0,
      );

      setActiveTab(activeTabIndex);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
    const tabElement = document.getElementById(`tab-${tabId}`);
    const headerOffset = 230;
    const { top } = tabElement.getBoundingClientRect();
    window.scrollTo({
      top: window.scrollY + top - headerOffset,
      behavior: "smooth",
    });
  };

  let sortedTabs = [];
  if (!isObjectBlank(productDetail)) {
    sortedTabs = productDetail?.tabs_details.slice().sort((a, b) => {
      return (
        orderedTabs.indexOf(a.tab_title) - orderedTabs.indexOf(b.tab_title)
      );
    });
  }
  const onClickApplyNow = () => {
    navigate(`leadgen`);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    if (activeTab === 5) {
      const feedbackTimeout = setTimeout(() => {
        setShowFeedback(true);
      }, 1000);

      return () => clearTimeout(feedbackTimeout);
    } else {
      setShowFeedback(false);
    }
  }, [activeTab]);

  return (
    <MainContainer className={`flex flex-col lg:p-4 p-0`}>
      <div
        className={`sticky top-[64px] sm:top-[63px] right-0 z-10 ${
          isSticky ? "bg-white" : ""
        } w-full dark:bg-black-200`}
      >
        <Breadcrumb />
        <div className="pt-3 capitalize font-semibold flex items-center text-[22px] lg:text-[28px] dark:text-white">
          <BackButton />
          {productDetail?.type_name} {productDetail?.product_title}
        </div>
      </div>

      <div
        className={`lg:w-[100%] sticky top-[145px] lg:top-[150px] z-10 ${
          isSticky ? "bg-white" : ""
        } overflow-x-auto dark:bg-black-200 w-full`}
      >
        <div
          className={`flex justify-between border-b shadow-custom-primary overflow-x-auto border-light-border-color dark:border-dark-border-color`}
        >
          <div className="flex">
            {!isObjectBlank(productDetail) &&
              sortedTabs?.map((tab, index) => {
                if (index !== 0) {
                  return (
                    <button
                      key={tab.tab_title}
                      className={`p-4 pb-[14px] first:pl-0 title title_sm title_primary relative flex-shrink-0 ${
                        activeTab === index
                          ? "dark:text-white font-bold"
                          : theme === "light"
                            ? "text-light-text-primary font-semibold"
                            : "text-white font-semibold"
                      }`}
                      onClick={() => handleTabClick(index)}
                    >
                      {tab.tab_title}
                      {activeTab === index && (
                        <div
                          className={`rounded-se-full rounded-ss-full active-border  h-[3px] bg-red-500 absolute right-[16px] bottom-0 ${
                            index !== 1 ? "left-[16px] " : "left-0"
                          }`}
                        ></div>
                      )}
                    </button>
                  );
                }
              })}
          </div>
          <div className="fixed bottom-0 left-0 right-0 p-5 flex items-center justify-center bg-white lg:bg-transparent lg:static lg:flex lg:items-end lg:p-0 w-auto lg:max-w-[175px] lg:w-full lg:mb-1">
            <Button
              variant="contained"
              className="!max-w-[175px] !w-full label label_lg !font-quicksand !capitalize  !bg-red-500 !rounded-[10px] justify-self-end mb-[6px] !p-[8px] !shadow-none"
              onClick={onClickApplyNow}
            >
              Apply now
            </Button>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap lg:flex-nowrap">
        <div className="w-full space-y-6 pt-2 lg:pt-4">
          {!isObjectBlank(productDetail) &&
            sortedTabs?.map((tab, index) => {
              if (index !== 0) {
                return (
                  <div
                    key={index}
                    id={`tab-${index}`}
                    className={``}
                    ref={(el) => (contentRefs.current[index] = el)}
                  >
                    {tab.tab_title === "Features and Benefits" && (
                      <>
                        <FeaturesList
                          features={tab?.tab_details.features_title}
                          staticTitle={"About this loan"}
                        ></FeaturesList>
                        <PreApprovedOfferBanner />
                      </>
                    )}
                    {tab.tab_title === "EMI Calculator" && (
                      <EmiCalculator
                        title={tab?.tab_title}
                        details={tab?.tab_details}
                      />
                    )}
                    {tab.tab_title === "Eligibility & Documents" && (
                      <Eligibility
                        title={tab?.tab_title}
                        details={tab?.tab_details}
                      />
                    )}
                    {tab.tab_title === "How to Apply" && (
                      <StepperTitle
                        title={tab?.tab_title}
                        details={tab?.tab_details}
                      />
                    )}
                    {tab.tab_title === "FAQs" && (
                      <Faq title={tab?.tab_title} details={tab?.tab_details} />
                    )}
                    {tab.tab_title === "FAQs" && showFeedback && <Feedback />}
                  </div>
                );
              }
            })}
        </div>
        <Sidebar showPreApproved={false} customClasses="lg:mt-4" />
      </div>
    </MainContainer>
  );
};

export default ProductFeatures;
