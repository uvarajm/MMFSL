import { createSlice } from "@reduxjs/toolkit";
import { GET_SAVED_BOOKMARKS_DATA } from "../actions/actions";

const initialState = {
  getSavedBookmarksData: {},
  loading: false,
  error: null,
};

const getSavedBookmarksSlice = createSlice({
  name: GET_SAVED_BOOKMARKS_DATA,
  initialState,
  reducers: {
    fetchGetSavedBookmarksStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchGetSavedBookmarksDataSuccess(state, action) {
      state.loading = false;
      state.getSavedBookmarksData = action.payload;
    },
    fetchGetSavedBookmarksDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchGetSavedBookmarksStatusData,
  fetchGetSavedBookmarksDataSuccess,
  fetchGetSavedBookmarksDataFailure,
} = getSavedBookmarksSlice.actions;

export default getSavedBookmarksSlice.reducer;
