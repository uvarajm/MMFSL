import PropTypes from "prop-types";
import { useState } from "react";
import ActiveLoans from "./ActiveLoans";
import HandleDataRendering from "../Common/HandleDataRendering";
import { ACTIVE_LOAN_CONSTANTS } from "../../const/common";
import NoData from "../Common/NoData";

const ActiveProducts = ({
  loanListDataResponse,
  error,
  loading,
  noData = false,
}) => {
  const [showAll, setShowAll] = useState(false);

  return (
    <HandleDataRendering
      data={loanListDataResponse}
      loading={loading}
      error={error}
    >
      <div className="w-full">
        {noData ? (
          <NoData errorText="No Active loan" />
        ) : (
          <>
            {/* TODO Dropdown needed when insurance and investment api are added */}
            {/* {formattedOptions.length > 1 && (
              <Dropdown options={formattedOptions} onSelect={handleSelect} />
            )} */}
            <div className={`mb-4 `}>
              <div className={`title title_lg title_primary `}>Loans</div>
              <div className="flex flex-wrap lg:-mx-4">
                {loanListDataResponse
                  ?.slice(0, showAll ? loanListDataResponse.length : 2)
                  .map((detail, index) => (
                    <ActiveLoans
                      key={`${detail.mobileNumber}-${index}`}
                      data={detail}
                      showButton={true}
                      type="Active"
                    />
                  ))}
              </div>
              {!showAll && loanListDataResponse?.length > 2 && (
                <div
                  className="flex show-more underline font-semibold text-red-800 justify-center py-4"
                  onClick={() => setShowAll(true)}
                >
                  <span className="text-base cursor-pointer p-2">
                    {ACTIVE_LOAN_CONSTANTS.SHOW_MORE_TEXT}
                  </span>
                </div>
              )}
            </div>
          </>
        )}
      </div>
      {/* <div
              className={` border-b mb-4 ${
                theme === "light"
                  ? "border-light-border-color "
                  : "border-dark-border-color "
              }`}
            >
              <div className="flex items-center pt-4">
                <div className="title text-red-800 text-xl font-semibold ">
                  Fixed Deposit
                </div>
                <div className="flex text-red-500 underline text-sm ml-2">
                  <div className="px-2 cursor-pointer">Start New FD</div>
                  <div className="border-l border-[#EDE0E3] px-2 cursor-pointer">
                    Summary
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap lg:-mx-4">
                <ActiveLoans showButton={false} />
                <ActiveLoans showButton={false} />
              </div>
              <div className="flex show-more underline font-semibold text-red-800  justify-center  py-4">
                <span className="text-base cursor-pointer p-2">+5 More</span>
              </div>
            </div> */}
    </HandleDataRendering>
  );
};

ActiveProducts.propTypes = {
  loanListDataResponse: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.array,
  ]),
  error: PropTypes.object,
  loading: PropTypes.bool,
  noData: PropTypes.bool,
};

export default ActiveProducts;
