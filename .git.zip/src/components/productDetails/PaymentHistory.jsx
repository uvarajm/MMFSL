import PropTypes from "prop-types";
import { DDMMMYYYY, PRODUCT_DETAILS_CONSTANTS } from "../../const/common";
import moment from "moment";
import Info from "./Info";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../Common/SvgIcon";

const paymentHistory = (data) => {
  const transactionList = data.data;
  return (
    <div id={`tab-1`}>
      <div className="text-base font-semibold lg:text-[20px] mb-2 lg:mb-[18px] flex justify-between">
        Payment history
        <span className="text-red-500 font-semibold text-xs lg:text-base flex items-center cursor-pointer">
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mr-2"
          >
            <path
              d="M7.99997 11.4115C7.87946 11.4115 7.76728 11.3923 7.66345 11.3538C7.5596 11.3154 7.46088 11.2493 7.3673 11.1557L4.2577 8.04615C4.10898 7.89743 4.03559 7.7234 4.03753 7.52405C4.03944 7.3247 4.11283 7.14746 4.2577 6.99232C4.41283 6.83721 4.59103 6.75708 4.7923 6.75195C4.99358 6.74682 5.17179 6.82182 5.32692 6.97695L7.25 8.90003V1.25C7.25 1.03718 7.32179 0.858984 7.46537 0.715401C7.60896 0.571801 7.78716 0.5 7.99997 0.5C8.21279 0.5 8.39099 0.571801 8.53458 0.715401C8.67816 0.858984 8.74995 1.03718 8.74995 1.25V8.90003L10.673 6.97695C10.8217 6.82823 10.9983 6.75483 11.2028 6.75675C11.4073 6.75868 11.5871 6.83721 11.7422 6.99232C11.8871 7.14746 11.9621 7.3231 11.9672 7.51925C11.9724 7.7154 11.8974 7.89103 11.7422 8.04615L8.63265 11.1557C8.53907 11.2493 8.44035 11.3154 8.3365 11.3538C8.23267 11.3923 8.12049 11.4115 7.99997 11.4115ZM2.3077 15.5C1.80257 15.5 1.375 15.325 1.025 14.975C0.675 14.625 0.5 14.1974 0.5 13.6923V11.7307C0.5 11.5179 0.5718 11.3397 0.7154 11.1961C0.858983 11.0525 1.03718 10.9808 1.25 10.9808C1.46282 10.9808 1.64102 11.0525 1.7846 11.1961C1.92818 11.3397 1.99997 11.5179 1.99997 11.7307V13.6923C1.99997 13.7692 2.03202 13.8397 2.09612 13.9038C2.16024 13.9679 2.23077 14 2.3077 14H13.6922C13.7692 14 13.8397 13.9679 13.9038 13.9038C13.9679 13.8397 14 13.7692 14 13.6923V11.7307C14 11.5179 14.0718 11.3397 14.2154 11.1961C14.3589 11.0525 14.5371 10.9808 14.75 10.9808C14.9628 10.9808 15.141 11.0525 15.2845 11.1961C15.4281 11.3397 15.5 11.5179 15.5 11.7307V13.6923C15.5 14.1974 15.325 14.625 14.975 14.975C14.625 15.325 14.1974 15.5 13.6922 15.5H2.3077Z"
              fill="#E31837"
            />
          </svg>
          Download
        </span>
      </div>
      <div className="bg-white rounded-lg lg:pt-4 lg:px-8 lg:pb-7 p-[12px]">
        <p className="text-sm font-karla mb-4">Last 10 Transactions </p>
        <ul>
          {transactionList.length > 0 &&
            transactionList.map((item, index) => {
              return (
                <li
                  className="flex justify-between items-center mb-4 last:mb-0"
                  key={`${item}-${index}`}
                >
                  <div className="flex items-center">
                    <svg
                      width="13"
                      height="13"
                      viewBox="0 0 13 13"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M11.1491 2.80426L1.81635 12.1274C1.67789 12.2658 1.50385 12.3335 1.29425 12.3303C1.08464 12.327 0.910603 12.2562 0.772153 12.1178C0.633686 11.9793 0.564453 11.8069 0.564453 11.6005C0.564453 11.3941 0.633686 11.2216 0.772153 11.0832L10.0953 1.75044H1.89905C1.68655 1.75044 1.50843 1.67854 1.36468 1.53474C1.22094 1.39092 1.14908 1.21272 1.14908 1.00014C1.14908 0.787539 1.22094 0.609448 1.36468 0.465865C1.50843 0.322281 1.68655 0.250488 1.89905 0.250488H11.7452C12.0013 0.250488 12.2159 0.337106 12.3892 0.510339C12.5624 0.683573 12.649 0.89823 12.649 1.15431V11.0005C12.649 11.213 12.5771 11.3911 12.4333 11.5348C12.2895 11.6786 12.1113 11.7504 11.8987 11.7504C11.6861 11.7504 11.508 11.6786 11.3645 11.5348C11.2209 11.3911 11.1491 11.213 11.1491 11.0005V2.80426Z"
                        fill="#E31837"
                      />
                    </svg>
                    <div className="ml-4">
                      <p className="text-sm font-semibold lg:text-sm lg:font-medium text-red-800">
                        Loan repayment
                      </p>
                      <p className="text-xs font-karla text-grey-500">
                        {moment(item.date).format(DDMMMYYYY)}
                      </p>
                    </div>
                  </div>
                  <div className="text-red-800 text-xs ">
                    -{item.instalmentAmount} ₹
                  </div>
                </li>
              );
            })}
        </ul>
      </div>
      <Info
        icon={<SvgIcon url={iconConfig.Notification} />}
        text={PRODUCT_DETAILS_CONSTANTS.COMMON.BANK_DETAILS_INFO}
        redirectText={"Set mandate"}
        redirectLink={"#"}
      />
    </div>
  );
};

paymentHistory.propTypes = {
  data: PropTypes.object,
};

export default paymentHistory;
