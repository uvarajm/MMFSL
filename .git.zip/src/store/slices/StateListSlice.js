import { createSlice } from "@reduxjs/toolkit";
import { STATE_LIST } from "../actions/actions";

const initialState = {
  stateAllList: {
    state: {},
    city: {},
  },
  loading: false,
  error: null,
};

const StateListSlice = createSlice({
  name: STATE_LIST,
  initialState,
  reducers: {
    fetchStateListStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchStateListDataSuccess(state, { payload }) {
      state.loading = false;
      state.stateAllList.state = payload.state;
      state.stateAllList.city = payload.city;
    },
    fetchStateListDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchStateListStatusData,
  fetchStateListDataSuccess,
  fetchStateListDataFailure,
} = StateListSlice.actions;

export default StateListSlice.reducer;
