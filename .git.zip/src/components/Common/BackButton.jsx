import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

const BackButton = ({ isModalOpen = true, setIsModalOpen, handleCallback }) => {
  const navigate = useNavigate();

  const handleBackPages = () => {
    if (handleCallback) {
      handleCallback();
    } else {
      if (isModalOpen) {
        navigate(-1);
      } else {
        setIsModalOpen(true);
      }
    }
  };

  return (
    <ArrowBackIcon
      className="text-red-500 mr-2 cursor-pointer dark:text-white"
      onClick={handleBackPages}
    />
  );
};

BackButton.propTypes = {
  isModalOpen: PropTypes.bool,
  setIsModalOpen: PropTypes.func,
  handleCallback: PropTypes.func,
};

export default BackButton;
