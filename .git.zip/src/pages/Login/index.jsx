import { Formik, Form } from "formik";
import * as Yup from "yup";
import { Link, useNavigate } from "react-router-dom";
import {
  Input,
  Password,
  CheckBox,
  Button,
  Alert,
  Container,
} from "../../components";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUserLoginAction } from "./loginFormSlice";
import { USER_LOGIN } from "./types";
import { COMMON_HEADING_LABEL, DEMO_USER_MAPPING } from "../../const/common";
import {
  mobileNumberValidation,
  passwordValidation,
} from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";

const initialValues = {
  mobileNumber: "",
  password: "",
  rememberMe: false,
};

const validationSchema = Yup.object({
  mobileNumber: mobileNumberValidation("Enter mobile number"),
  password: passwordValidation("Enter password").min(10),
  rememberMe: Yup.boolean(),
});

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // use later
  // eslint-disable-next-line no-unused-vars
  const { mobileNumber } = useSelector((state) => state.login);
  const alertError = false;
  const [showPassword, setShowPassword] = useState(false);

  const findUserDetails = (number) => {
    const user = DEMO_USER_MAPPING.find((user) => user.number == number);
    if (user) {
      return { name: user.name, ucic: user.ucic };
    } else {
      return null;
    }
  };

  const onSubmit = (values) => {
    try {
      let details = findUserDetails(values.mobileNumber);
      details.number = values.mobileNumber;
      dispatch(getUserLoginAction(details));
      dispatch({ type: USER_LOGIN, payload: values.password });
      navigate("/product");
    } catch (error) {
      alert("Please enter valid user details");
      // setAlertError(true);
    }
  };

  return (
    <Container className="px-4">
      <div className="w-full minHeight flex justify-center items-center">
        <div className="flex flex-col justify-between w-[400px]">
          <div className="flex items-center lg:block pb-4">
            <BackButton />
            <p className="tracking-wide lg:pt-3 headline headline_md headline_primary">
              {COMMON_HEADING_LABEL?.label}
            </p>
          </div>
          <div className="flex-1">
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="flex flex-col">
                  <div className="pb-[15px] w-full relative">
                    <Input
                      type="number"
                      name="mobileNumber"
                      label="Mobile number"
                      placeholder="Mobile number"
                      formik={formik}
                      inputClassName="px-3 pl-3"
                      disabled={alertError}
                      maxLength="10"
                    />
                    <div className="absolute left-0 top-[28px] text-grey-500 content content_xl content_primary leading-[22px]">
                      +91
                    </div>
                  </div>
                  <div className="pb-[15px] w-full">
                    <Password
                      label="Password"
                      name="password"
                      placeholder="Enter password"
                      formik={formik}
                      showConfirmPassword={showPassword}
                      setShowConfirmPassword={setShowPassword}
                      disabled={alertError}
                    />
                  </div>

                  <div className="flex justify-between items-center pb-[15px]">
                    <CheckBox
                      label="Remember Me"
                      name="rememberMe"
                      disabled={alertError}
                      className={`${
                        alertError ? "text-[#696969]" : "text-black-100"
                      }`}
                    />

                    <Link
                      to={
                        alertError
                          ? ""
                          : {
                              pathname: "/reset-password",
                            }
                      }
                      className={` content content_primary-red content_md${
                        alertError ? "text-red-500" : ""
                      }`}
                    >
                      Forgot Password?
                    </Link>
                  </div>

                  <div className="flex justify-center w-full pt-10 lg:pt-0 mt-20 lg:mt-[53px]">
                    <Button
                      type="submit"
                      name="Login"
                      disabled={!(formik.isValid && formik.dirty) || alertError}
                      className="hover:opacity-85 w-full rounded-lg gap-2 font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark dark:bg-red-500 dark:text-white dark:disabled:bg-grey-900 dark:disabled:text-grey-100"
                    />
                  </div>
                </Form>
              )}
            </Formik>

            {alertError && <Alert errorMessage="Check your password" />}
            <p className="flex items-center  py-4 text-grey-500 label label_md label_secondary mt-10">
              New to Fin2go ? &nbsp;
              <Link
                to="/register"
                className="flex justify-center label label_md label_primary-red"
              >
                Register now
              </Link>
            </p>
          </div>
        </div>
      </div>
    </Container>
  );
};

export default Login;
