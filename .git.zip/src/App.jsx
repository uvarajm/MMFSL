import { useEffect } from "react";
import { Suspense } from "react";
import { RouterProvider } from "react-router-dom";
import router from "./routes";
import Loader from "./components/Common/Loader";
import generateToken from "./api/tokenGenerator";
import { BACKEND_TOKEN, CMS_TOKEN } from "./const/common";

const App = () => {
  useEffect(() => {
    const generateTokens = async () => {
      try {
        // Generate backend token if not already exists
        await generateToken(
          import.meta.env.VITE_BACKEND_CLIENT_ID,
          import.meta.env.VITE_BACKEND_CLIENT_SECRETE,
          import.meta.env.VITE_BACKEND_TOKEN_END_POINT,
          BACKEND_TOKEN,
        );

        // Generate CMS token if not already exists
        await generateToken(
          import.meta.env.VITE_CMS_CLIENT_ID,
          import.meta.env.VITE_CMS_CLIENT_SECRETE,
          import.meta.env.VITE_CMS_TOKEN_END_POINT,
          CMS_TOKEN,
        );
      } catch (error) {
        console.error("Error generating tokens:", error);
      }
    };

    // Call the function to generate tokens
    generateTokens();
  }, []);

  return (
    <Suspense fallback={<Loader />}>
      <RouterProvider router={router} />
    </Suspense>
  );
};

export default App;
