import { createSlice } from "@reduxjs/toolkit";
import { UPDATE_BOOKMARKS } from "../actions/actions";

const initialState = {
  updateBookmarkData: {},
  loading: false,
  error: null,
};

const updateBookmarkSlice = createSlice({
  name: UPDATE_BOOKMARKS,
  initialState,
  reducers: {
    fetchUpdateBookmarkDataStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchUpdateBookmarkDataDataSuccess(state, action) {
      state.loading = false;
      state.updateBookmarkData = action.payload;
    },
    fetchUpdateBookmarkDataDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchUpdateBookmarkDataStatusData,
  fetchUpdateBookmarkDataDataSuccess,
  fetchUpdateBookmarkDataDataFailure,
} = updateBookmarkSlice.actions;

export default updateBookmarkSlice.reducer;
