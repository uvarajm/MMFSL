import { Outlet } from "react-router-dom";

const PreLogin = () => {
  return (
    <>
      <section className="flex relative">
        <div className="w-full flex justify-between minHeight">
          <div className="prelogin-bg-image">
            <Outlet />
          </div>
        </div>
      </section>
    </>
  );
};

export default PreLogin;
