import PropTypes from "prop-types";
import ForeclosureCard from "./ForeclosureCard";
import {
  ArrowForwardIosOutlined,
  ErrorOutlineOutlined,
} from "@mui/icons-material";

const ForeclosureItem = ({
  foreclosureProceedBtnActive,
  buttonText,
  middleLeftDataMiddle,
  middleRightDateHeader,
  middleLeftHeaderMiddle,
  foreclosureCardDetail,
  Person2Outlined,
  periodTime,
  errorDescription,
  middleLeftHeader,
  middleLeftData,
  middleRightHeader,
  middleRightData,
  loneType,
  loanFor,
}) => {
  return (
    <ForeclosureCard className="md:w-[34rem] h-[280px] rounded-[15px] border-[1px] border-[#A5A5A5]">
      <div className="w-full p-2">
        <div className="w-full flex items-center">
          <div className="w-full flex items-center">
            <p className="bg-[#A5A5A5] w-14 h-14 rounded-[50%] flex justify-center items-center">
              <Person2Outlined sx={{ fontSize: "30px" }} />
            </p>
            <div className="pl-2 flex flex-col">
              <p className="text-[#5B5B5B] font-normal text-[12px]">
                {loneType}
              </p>
              <p className="text-[#1D1B20] font-normal text-[12px]">
                {loanFor}
              </p>
            </div>
          </div>

          <p className="bg-[#D9D9D9] w-14 h-12 rounded-[50%] flex justify-center items-center">
            <ArrowForwardIosOutlined />
          </p>
        </div>

        <hr className="px-2 my-5 h-2" />

        <div className="w-full flex items-center justify-between">
          <div>
            <p className="text-[#5B5B5B] font-normal text-[12px]">
              {middleLeftHeader}
            </p>
            <p className="text-[#1D1B20] font-normal text-[14px]">
              {middleLeftData.toLocaleString("en-IN")}
            </p>
          </div>
          <div>
            <p className="text-[#5B5B5B] font-normal text-[12px]">
              {middleRightHeader}
            </p>
            <p className="text-[#1D1B20] font-normal text-[14px]">
              {middleRightData.toLocaleString("en-IN")}
            </p>
          </div>
        </div>

        <div className="w-full py-5">
          {foreclosureCardDetail ? (
            <div className="w-full flex">
              <ErrorOutlineOutlined sx={{ color: "#A10101" }} />
              <div className="w-80">
                <p className="text-[#A10101] font-normal text-[12px] text-wrap pl-2">
                  {errorDescription}
                </p>
              </div>
            </div>
          ) : (
            <div className="w-full flex items-center justify-between">
              <div>
                <p className="text-[#5B5B5B] font-normal text-[12px]">
                  {middleLeftHeaderMiddle}
                </p>
                <p className="text-[#1D1B20] font-normal text-[14px]">
                  {middleLeftDataMiddle}
                </p>
              </div>
              <div className="pr-16">
                <p className="text-[#5B5B5B] font-normal text-[12px]">
                  {middleRightDateHeader}
                </p>
                <p className="text-[#1D1B20] font-normal text-[14px]">
                  {middleRightData.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          )}
          <div className="w-full flex items-baseline justify-between">
            <p className="text-[#000000] text-[12px] text-wrap pt-5 font-medium">
              {periodTime}
            </p>
            <button
              className={`flex px-10 py-3 ml-auto mr-5 rounded-[50px] ${
                foreclosureProceedBtnActive
                  ? "text-white bg-[#322F35]"
                  : "text-white bg-[#C1C1C1]"
              } text-[14px] font-normal`}
            >
              {buttonText}
            </button>
          </div>
        </div>
      </div>
    </ForeclosureCard>
  );
};

ForeclosureItem.propTypes = {
  foreclosureProceedBtnActive: PropTypes.bool.isRequired,
  buttonText: PropTypes.string.isRequired,
  middleLeftDataMiddle: PropTypes.string,
  middleRightDateHeader: PropTypes.string,
  middleLeftHeaderMiddle: PropTypes.string,
  foreclosureCardDetail: PropTypes.bool.isRequired,
  Person2Outlined: PropTypes.elementType.isRequired,
  periodTime: PropTypes.string.isRequired,
  errorDescription: PropTypes.string.isRequired,
  middleLeftHeader: PropTypes.string.isRequired,
  middleLeftData: PropTypes.number.isRequired,
  middleRightHeader: PropTypes.string.isRequired,
  middleRightData: PropTypes.number.isRequired,
  loneType: PropTypes.string.isRequired,
  loanFor: PropTypes.string.isRequired,
};

export default ForeclosureItem;
