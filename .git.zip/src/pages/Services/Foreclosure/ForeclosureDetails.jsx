import { useNavigate } from "react-router-dom";
import Breadcrumb from "../../../components/Breadcrumb";
import { ArrowBack, Person2Outlined } from "@mui/icons-material";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import { FaIndianRupeeSign } from "react-icons/fa6";
import { Button, Select } from "../../../components";
import { foreclosureOptions } from "../../../utils";
import { useState } from "react";

// Select Foreclosure Reason

const initialValues = {
  foreclosure_amount: "",
  foreclosure_reason: "",
};

const validationSchema = Yup.object({
  foreclosure_amount: Yup.string().required("Enter foreclosure amount"),
  foreclosure_reason: Yup.string().required("Please select foreclosure reason"),
});

const ForeclosureDetails = () => {
  const navigate = useNavigate();
  const [alertError, setAlertError] = useState(false);

  const handleBackward = () => {
    navigate("..");
  };

  const onSubmit = () => {
    try {
      // console.log(values);
    } catch (error) {
      setAlertError(true);
    }
  };

  return (
    <div className="w-full p-5">
      <Breadcrumb />

      <div className="w-full pt-2">
        <div className="flex items-center">
          <ArrowBack
            sx={{ color: "#1B438B", fontSize: "32px", cursor: "pointer" }}
            onClick={handleBackward}
          />
          <p className="text-[#322F35] font-semibold text-[22px] pl-2">
            Foreclosure
          </p>
        </div>

        <div className="pl-12 pt-2">
          <div className="flex items-center">
            <div className="bg-[#A5A5A5] w-[50px] h-[50px] rounded-[50%] flex justify-center items-center">
              <Person2Outlined sx={{ color: "#111827", fontSize: "32px" }} />
            </div>
            <div className="pl-5">
              <p className="text-[#5B5B5B] font-normal text-[15px]">
                <span>Personal Loan </span>|<span> PL124578</span>
              </p>
              <p className="text-[#1D1B20] font-normal text-[17px]">
                Lorem Epsum nkniovakv
              </p>
            </div>
          </div>

          <div className="pt-8">
            <p className="text-[14px] text-[#000000] font-medium">
              Foreclosure amount
            </p>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="w-[428px]">
                  <div>
                    <div className="flex gap-2 items-center w-full border border-[#79747E] py-2 px-4 rounded-md">
                      <FaIndianRupeeSign />
                      <input
                        type="number"
                        name="foreclosure_amount"
                        placeholder="Enter amount"
                        className="focus:outline-none w-full text-[18px]"
                      />
                    </div>
                    <p className="text-[#49454F] text-[12px] pt-1">
                      Disclaimer : Foreclosure details mentioned below are as on
                      DD-MM-YYYY.
                    </p>
                  </div>

                  <div className="pt-4">
                    <Select
                      formik={formik}
                      name={"foreclosure_reason"}
                      options={foreclosureOptions}
                    />
                  </div>

                  <div className="flex-1 justify-center w-full mt-48">
                    <Button
                      type="submit"
                      name="Proceed"
                      disabled={!(formik.isValid && formik.dirty) || alertError}
                      className="bg-black-100 hover:opacity-85 text-white w-full h-12"
                    />
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForeclosureDetails;
