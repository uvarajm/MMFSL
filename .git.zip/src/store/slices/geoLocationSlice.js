import { createSlice } from "@reduxjs/toolkit";
import { GEO_LOCATION } from "../actions/actions";

const initialState = {
  latitude: 0,
  longitude: 0,
};

const geoLocationSlice = createSlice({
  name: GEO_LOCATION,
  initialState,
  reducers: {
    setGeoLocation: (state, action) => {
      state.latitude = action.payload.latitude;
      state.longitude = action.payload.longitude;
    },
  },
});

export const { setGeoLocation } = geoLocationSlice.actions;

export default geoLocationSlice.reducer;
