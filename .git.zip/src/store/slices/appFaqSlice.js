import { createSlice } from "@reduxjs/toolkit";
import { APP_FAQS } from "../actions/actions";
const initialState = {
  AppFaqs: [],
  loading: false,
  error: null,
};

const appFaqSlice = createSlice({
  name: APP_FAQS,
  initialState,
  reducers: {
    appFaqStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    appFaqDataSuccess(state, { payload }) {
      state.loading = false;
      state.AppFaqs = payload.data.categories;
    },
    appFaqDataFailure(state, { payload }) {
      state.loading = false;
      state.error = payload;
    },
  },
});

export const { appFaqStatusData, appFaqDataSuccess, appFaqDataFailure } =
  appFaqSlice.actions;

export default appFaqSlice.reducer;
