import PropTypes from "prop-types";
import { GoogleMap, Marker, useJsApiLoader } from "@react-google-maps/api";
import { useCallback, useLayoutEffect, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Locate from "../../assets/icons/location.svg";
import {
  DEALER_PINCODE_DATA,
  GET_SAVED_BOOKMARKS_DATA,
  LATITUDE_LONGITUDE_DATA,
  UPDATE_BOOKMARKS,
} from "../../store/actions/actions";
import ProductPageDetails from "../../pages/Products/ProductPageDetails";
import { LOCATE } from "../../const/common";
import Branches from "../../pages/LocateUs/Branches";
import Dealers from "../../pages/LocateUs/Dealers";
import Saved from "../../pages/LocateUs/Saved";
import { capitalizeWords } from "../../utils/utils";
import HandleDataRendering from "../Common/HandleDataRendering";
import { isNumber } from "../../utils";
import CashCollectionPoints from "../LocateUs/CashCollectionPoints";

const [BRANCHES, DEALERS, CASH_COLLECTIONS_POINTS, SAVED] = LOCATE.PRODUCT_TABS;

const Map = ({ handleCallBack }) => {
  const dispatch = useDispatch();
  const { latitudeLongitudeData, loading, error } = useSelector(
    (state) => state.latitLongitude,
  );
  const { dealerPinCodeData } = useSelector((state) => state.dealerPinCode);
  const { getSavedBookmarksData } = useSelector((state) => state.getBookmarks);
  const { bookmarkObj } = useSelector((state) => state.bookmark);
  const { updateBookmarkData } = useSelector((state) => state.updateBookmark);
  const { latitude, longitude } = useSelector((state) => state.geoLocation);
  const { superAppId } = useSelector((state) => state.login);
  const [locations, setLocation] = useState([]);
  const [saveList, setSaveList] = useState([]);
  const [containerStyle, setContainerStyle] = useState({
    width: "678px",
    height: "362px",
    position: "relative",
    paddingTop: "24px",
  });

  const center = {
    lat: latitude,
    lng: longitude,
  };
  const [map, setMap] = useState(null);
  useEffect(() => {
    setTimeout(() => {
      map?.setZoom(9);
    }, 100);
  }, [map]);

  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_API_KEY,
  });

  const onLoad = useCallback(
    function callback(map) {
      const bounds = new window.google.maps.LatLngBounds(center);
      map.fitBounds(bounds);
      setMap(map);
    },
    [center],
  );

  const onUnmount = useCallback(function callback() {
    setMap(null);
  }, []);
  useEffect(() => {
    const checkBranchDealer = isNumber(bookmarkObj.code);
    dispatch({
      type: UPDATE_BOOKMARKS,
      payload: {
        code: `${checkBranchDealer ? "D" : "B"}-${bookmarkObj.code}`,
        saveBranch: bookmarkObj.isBookmarks,
        superAppId: superAppId,
      },
    });
    const filterUnSavedData = saveList?.filter(
      (item) => item.code !== bookmarkObj.code,
    );
    setSaveList(filterUnSavedData);
  }, [bookmarkObj]);

  useEffect(() => {
    dispatch({
      type: GET_SAVED_BOOKMARKS_DATA,
      payload: { superAppId: superAppId },
    });
  }, [updateBookmarkData]);

  let defaultActiveTab = BRANCHES;
  const renderTabContent = (activeTab) => {
    const tabContentMap = {
      [BRANCHES]: (
        <Branches
          pinCodeData={latitudeLongitudeData}
          getSavedBookmarksData={getSavedBookmarksData}
        />
      ),
      [DEALERS]: <Dealers dealerPinCodeData={dealerPinCodeData} />,
      [CASH_COLLECTIONS_POINTS]: <CashCollectionPoints />,
      [SAVED]: (
        <Saved
          latitudeLongitudeData={latitudeLongitudeData}
          getSavedBookmarksData={getSavedBookmarksData}
          setSaveList={setSaveList}
          saveList={saveList}
        />
      ),
    };

    return tabContentMap[activeTab];
  };

  useLayoutEffect(() => {
    if (latitude && longitude) {
      dispatch({
        type: LATITUDE_LONGITUDE_DATA,
        payload: { lat: latitude, lon: longitude },
      });
      dispatch({
        type: GET_SAVED_BOOKMARKS_DATA,
        payload: { superAppId: superAppId },
      });
      dispatch({
        type: DEALER_PINCODE_DATA,
        payload: { lat: latitude, lon: longitude },
      });
    }
  }, []);

  useLayoutEffect(() => {
    if (latitudeLongitudeData?.branchList) {
      const filterDataLatitudeLongitude = latitudeLongitudeData?.branchList.map(
        (branch) => ({
          lat: branch.lat,
          lng: branch.lon,
        }),
      );

      setLocation(filterDataLatitudeLongitude);
    }
  }, [latitudeLongitudeData?.branchList]);

  useEffect(() => {
    const updateContainerStyle = () => {
      const width = window.innerWidth;
      if (width <= 480) {
        setContainerStyle({
          width: "100%",
          height: "200px",
          position: "relative",
        });
      } else if (width <= 768) {
        setContainerStyle({
          width: "100%",
          height: "300px",
          position: "relative",
        });
      } else {
        setContainerStyle({
          width: "678px",
          height: "362px",
          position: "relative",
        });
      }
    };

    window.addEventListener("resize", updateContainerStyle);
    updateContainerStyle();

    return () => window.removeEventListener("resize", updateContainerStyle);
  }, []);
  return isLoaded ? (
    <>
      <HandleDataRendering
        data={latitudeLongitudeData}
        loading={loading}
        error={error}
      >
        <div className="flex flex-col w-full map-container">
          <GoogleMap
            mapContainerStyle={containerStyle}
            center={center}
            zoom={0}
            minZoom={0}
            maxZoom={0}
            onLoad={onLoad}
            onUnmount={onUnmount}
          >
            {latitudeLongitudeData?.branchList && (
              <div className="w-[335px] flex flex-col absolute top-4 left-4">
                <div className="flex items-center">
                  <div
                    className="w-[295px] bg-white px-4 py-[10px] rounded-lg relative cursor-pointer"
                    onClick={() => handleCallBack()}
                  >
                    <div className="w-6 h-6 absolute left-4 -top-[2px]">
                      <img src={Locate} alt="locate" className="pt-2" />
                    </div>
                    <p className="pl-7 pr-2 content content_lg !leading-[18px] content_secondary">
                      {latitudeLongitudeData?.branchList
                        ? capitalizeWords(
                            latitudeLongitudeData?.branchList[0]?.location,
                          )
                        : ""}
                    </p>
                  </div>
                </div>
              </div>
            )}
            {locations &&
              locations?.map((location, index) => (
                <Marker key={index} position={location}></Marker>
              ))}
          </GoogleMap>

          <div className="pt-4 w-full">
            <ProductPageDetails
              renderTabContent={renderTabContent}
              productDetails={LOCATE}
              defaultActiveTab={defaultActiveTab}
              showBeforeLogin={true}
              isHeaderSticky={true}
              stickyValue={500}
              headerStyle={"lg:max-w-[678px] w-full"}
            />
          </div>
        </div>
      </HandleDataRendering>
    </>
  ) : (
    <></>
  );
};

Map.propTypes = {
  handleCallBack: PropTypes.func,
};

export default Map;
