// saga.js
import { takeLatest, put, call, all } from "redux-saga/effects";
import {
  fetchProductDetailsStatusData,
  fetchProductDetailsStatusDataSuccess,
  fetchProductDetailsStatusDataFailure,
} from "../slices/productDetailsSlice";
import { PRODUCT_DETAILS } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchProductDetailsStatus(actions) {
  try {
    yield put(fetchProductDetailsStatusData());
    const { cifId, ucic, loanNumber, sourceSystem } =
      actions.details.payload.productIdDetails;
    const payload = {
      loanNumber: loanNumber,
      sourceSystem: sourceSystem,
    };

    const [response, response1, response2] = yield all([
      call(makeApiRequest, endpoints.productDetails, BACKEND_TOKEN, "POST", {
        cifId: cifId,
        ucic: ucic,
        ...payload,
      }),
      call(
        makeApiRequest,
        endpoints.paymentHistory,
        BACKEND_TOKEN,
        "POST",
        payload,
      ),
      call(
        makeApiRequest,
        endpoints.productDetailsDocument,
        BACKEND_TOKEN,
        "POST",
        payload,
      ),
    ]);
    // Combine all responses
    const combinedResponse = {
      loanDetails: response,
      paymentHistory: response1,
      documentDetails: response2,
    };

    yield put(fetchProductDetailsStatusDataSuccess(combinedResponse));
  } catch (error) {
    yield put(fetchProductDetailsStatusDataFailure(error.message));
  }
}

export function* watchFetchProductDetailsStatus() {
  yield takeLatest(PRODUCT_DETAILS, fetchProductDetailsStatus);
}
