import PropTypes from "prop-types";
import Card from "../Card";
import ChevronRight from "../../assets/icons/chevron_right.svg";
import FetchDynamicImage from "../Common/FetchDynamicImage";
import { Link } from "react-router-dom";
import DOMPurify from "dompurify";
const OffersCard = ({ offer, offerHeader }) => {
  const sanitizer = DOMPurify.sanitize;

  return (
    <Card className="p-3 rounded-lg ml-3">
      <div className="flex flex-col">
        <div className="offer_header">
          <FetchDynamicImage
            src={offer.image}
            alt={offer.name}
            customClasses="w-[50] h-[40]"
          />
        </div>
        <div className="offer_body pt-4">
          <h4 className="label label_primary-dark">{offerHeader}</h4>
          <p
            className="content"
            dangerouslySetInnerHTML={{
              __html: sanitizer(offer?.sub_header),
            }}
          ></p>
        </div>
        <div className="offer_footer inline-flex flex-col label pt-1">
          <Link
            to={{
              pathname: `/offer-details/${offer?.offer_id}`,
            }}
          >
            {offer.button_name}
            <img className="inline" src={ChevronRight} alt="right" />
          </Link>
        </div>
      </div>
    </Card>
  );
};
OffersCard.propTypes = {
  offer: PropTypes.object,
  offerHeader: PropTypes.string,
};
export default OffersCard;
