import { createSlice } from "@reduxjs/toolkit";
import { PIN_CODE_DATA } from "../actions/actions";

const initialState = {
  pinCodeData: {},
  loading: false,
  error: null,
};

const pinCodeStatusSlice = createSlice({
  name: PIN_CODE_DATA,
  initialState,
  reducers: {
    fetchPinCodeStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchPinCodeDataSuccess(state, action) {
      state.loading = false;
      state.pinCodeData = action.payload;
    },
    fetchPinCodeDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    resetDealerPinCodeData() {
      return initialState; // Reset state to initialState
    },
  },
});

export const {
  fetchPinCodeStatusData,
  fetchPinCodeDataSuccess,
  fetchPinCodeDataFailure,
  resetDealerPinCodeData,
} = pinCodeStatusSlice.actions;

export default pinCodeStatusSlice.reducer;
