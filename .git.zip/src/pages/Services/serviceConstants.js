const DETAILS_LABLE = {
  REQUEST_DETAILS: "Request Details",
  REQUEST_SERVICE: "Service request no.",
  RAISED: "Raised on",
  CATEGORY: "Category",
  PRODUCT: "Product",
  QUERY: "Query",
  STATUS: "Status",
  LAST_UPDATED: "Last updated on",
};

export { DETAILS_LABLE };
