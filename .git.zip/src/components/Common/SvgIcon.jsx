import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import DOMPurify from "dompurify";
import { capitalizeTitle } from "../../utils/utils";

const SvgIcon = ({ className, colorClass, url, customClickCallback }) => {
  const sanitizer = DOMPurify.sanitize;
  const [svgContent, setSvgContent] = useState(null);
  const finalColorClass = `${colorClass} dark:fill-white`;

  useEffect(() => {
    const fetchSvg = async () => {
      if (!url) {
        console.warn("SVG URL is not defined.");
        setSvgContent(null);
        return;
      }

      const svgUrl = capitalizeTitle(url);

      try {
        const response = await fetch(svgUrl);
        if (!response.ok) {
          throw new Error(
            `Network response was not ok: ${response.statusText}`,
          );
        }

        const svgText = await response.text();

        // Parse the SVG content and add the colorClass to each child element
        const parser = new DOMParser();
        const svgDoc = parser.parseFromString(svgText, "image/svg+xml");
        const svgElement = svgDoc.documentElement;

        const addFillColorClass = (element) => {
          if (finalColorClass) {
            // Split the colorClass into individual classes, filter out empty strings, and add them
            finalColorClass
              .split(" ")
              .filter((cls) => cls) // Filter out any empty strings
              .forEach((cls) => element.classList.add(cls));
          }
          // Recursively add the colorClass to all children
          Array.from(element.children).forEach(addFillColorClass);
        };

        // Start the recursive function with the root SVG element
        addFillColorClass(svgElement);
        // Serialize the modified SVG content back to a string
        const serializer = new XMLSerializer();
        const updatedSvgText = serializer.serializeToString(svgElement);

        setSvgContent(updatedSvgText);
      } catch (error) {
        console.error(`Failed to load SVG: ${error}`);
        setSvgContent(null);
      }
    };

    fetchSvg();
  }, [url, finalColorClass]);

  if (!svgContent) {
    return null;
  }

  return (
    <div
      className={`${className} custom-svg-wrapper`}
      onClick={customClickCallback}
      dangerouslySetInnerHTML={{ __html: sanitizer(svgContent) }}
    ></div>
  );
};

SvgIcon.propTypes = {
  className: PropTypes.string,
  url: PropTypes.string,
  colorClass: PropTypes.string,
  customClickCallback: PropTypes.func,
};

export default SvgIcon;
