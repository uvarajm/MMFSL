import PropTypes from "prop-types";
import { useState, useEffect } from "react";
import "./EmiCalculator.scss";
import CircularProgressBar from "./CircularProgressBar";
import { EMI } from "../../const/common";

const EmiCalculator = (props) => {
  const { title, details } = props;
  const { emi_details = {} } = details;
  const parseLoanAmount = (value) =>
    typeof value === "string"
      ? Number(value.replace(/[^\d.]/g, ""))
      : Number(value);
  const parsedEmiDetails = Object.entries(emi_details).reduce(
    (acc, [key, value]) => ({ ...acc, [key]: parseLoanAmount(value) }),
    {},
  );

  const {
    minLoanAmount,
    maxLoanAmount,
    minRateOfInterest,
    maxRateOfInterest,
    minTenure,
    maxTenure,
  } = parsedEmiDetails;

  const [principal, setPrincipal] = useState(Number(minLoanAmount) * 100000);
  const [rate, setRate] = useState(Number(minRateOfInterest));
  const [tenure, setTenure] = useState(Number(minTenure));
  const [monthlyEmi, setMonthlyEmi] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);
  const [totalInterest, setTotalInterest] = useState(0);

  const formatNumberInThousands = (value) => {
    if (+value >= 1000) {
      const formattedValue = Math.floor(+value).toLocaleString();
      return `${formattedValue}`;
    }
    return +value.toLocaleString();
  };

  useEffect(() => {
    if (tenure === 0) {
      setMonthlyEmi(0);
    } else {
      const monthlyRate = rate / 12 / 100;
      const emi =
        (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) /
        (Math.pow(1 + monthlyRate, tenure) - 1);
      setMonthlyEmi(isNaN(emi) || !isFinite(emi) ? 0 : emi.toFixed(0));
    }
  }, [principal, rate, tenure]);

  useEffect(() => {
    const total = monthlyEmi * tenure;
    setTotalAmount(total.toFixed(0));
  }, [monthlyEmi, tenure]);

  useEffect(() => {
    const interest = totalAmount - principal;
    setTotalInterest(isNaN(interest) ? 0 : Math.max(0, interest).toFixed(0));
  }, [totalAmount, principal]);

  const handlePrincipalChange = (e) => {
    const value = e.target.value.replace(/,/g, "");
    const numericValue = Number(value);

    if (numericValue === "0") {
      setPrincipal("");
    }

    setPrincipal(+numericValue);
  };

  const handleTennuarChange = (e) => {
    const value = e.target.value.replace(/,/g, "");
    const numericValue = Number(value);
    if (numericValue === "0") {
      setTenure("");
    }
    setTenure(numericValue);
  };

  const handleRateChange = (e) => {
    const value = e.target.value;
    // Allow only valid number input with up to 2 decimal places
    const regex = /^\d*\.?\d{0,2}$/;

    if (regex.test(value)) {
      setRate(value);
    }
  };

  const handleBlur = () => {
    let parsedValue = parseFloat(rate);

    if (isNaN(parsedValue)) {
      setRate(minRateOfInterest.toFixed(2));
    } else if (parsedValue < minRateOfInterest) {
      setRate(minRateOfInterest.toFixed(2));
    } else if (parsedValue > maxRateOfInterest) {
      setRate(maxRateOfInterest.toFixed(2));
    } else {
      setRate(parsedValue.toFixed(2));
    }
  };
  return (
    <div className="flex flex-col justify-start items-start">
      <p className="title title_xl title_primary mb-3">{title}</p>
      <section className="lg:border lg:border-lilac-light rounded-md flex flex-col md:flex-row  w-full md:w-[882px]">
        <div className="lg:p-4 flex-1 flex flex-col gap-4">
          {/* Principal input */}
          <div className="mb-5 mt-2">
            <div className="flex justify-between label label_lg label_primary">
              <span>{EMI.LOAN_AMOUNT}</span>
              <div className="label label_sm label_primary-dark lg:bg-lilac-light rounded-b-none lg:border-red-100 mb-1 p-1 rounded-md lg:border-b-2 w-[94px] flex justify-center">
                <span>{EMI.RUPEE}</span>
                <input
                  type="text"
                  value={
                    principal !== null ? formatNumberInThousands(principal) : ""
                  }
                  onChange={handlePrincipalChange}
                  className="max-w-[70px] bg-transparent border-none outline-none title title_sm title_primary-dark ml-1 text-ellipsis overflow-hidden w-full"
                />
              </div>
            </div>
            <input
              type="range"
              min={Number(minLoanAmount) * 100000}
              max={Number(maxLoanAmount) * 100000}
              step={10000}
              value={principal}
              onChange={(e) => setPrincipal(parseFloat(e.target.value))}
              className="w-full h-1 border-red-800 bg-red-400 text-ellipsis overflow-hidden"
            />
            <div className="flex justify-between label label_sm label_primary">
              <p>
                {EMI.RUPEE} <span>{minLoanAmount}</span>
                {EMI.LACK}
              </p>
              <p>
                {EMI.RUPEE} <span>{maxLoanAmount}</span>
                {EMI.LACK}
              </p>
            </div>
          </div>
          {/* Rate of Interest input */}
          <div className="mb-5">
            <div className="flex justify-between label label_lg label_primary">
              <span>{EMI.ROI}</span>
              <div className="title title_xs title_primary-dark lg:bg-lilac-light rounded-b-none lg:border-red-100 p-1 mb-1 rounded-md lg:border-b-2 font-quicksand font-semibold w-[60px]">
                <span>
                  <input
                    type="text" // Change to text to handle regex validation
                    value={rate}
                    onChange={handleRateChange}
                    onBlur={handleBlur}
                    className="bg-transparent border-none outline-none text-center title title_sm title_primary-dark mr-0 text-ellipsis overflow-hidden"
                    style={{ width: "40px" }} // Adjust width as needed
                    min={Number(minRateOfInterest)}
                    max={Number(maxRateOfInterest)}
                  />

                  {EMI.PERCENT}
                </span>
              </div>
            </div>
            <input
              type="range"
              min={Number(minRateOfInterest)}
              max={Number(maxRateOfInterest)}
              step={0.1}
              value={rate}
              onChange={(e) => setRate(parseFloat(e.target.value))}
              className="w-full h-1 bg-red-100 "
            />
            <div className="flex justify-between label label_sm label_primary">
              <p>
                <span>{minRateOfInterest}</span> {EMI.PERCENT}
              </p>
              <p>
                <span>{maxRateOfInterest}</span> {EMI.PERCENT}
              </p>
            </div>
          </div>
          {/* Tenure input */}
          <div className="mb-5">
            <div className="flex justify-between label label_lg label_primary">
              <span className="label label_lg label_primary ">
                {EMI.TENURE}
              </span>
              <div className="title title_sm title_primary-dark lg:bg-lilac-light rounded-b-none lg:border-red-100  mb-1 p-1 rounded-md lg:border-b-2">
                <span>
                  <input
                    type="text"
                    value={
                      tenure !== null ? formatNumberInThousands(tenure) : ""
                    }
                    onChange={handleTennuarChange}
                    className=" bg-transparent border-none outline-none text-right title title_sm title_primary-dark  mr-1 text-ellipsis overflow-hidden"
                    style={{ width: "20px" }} // Adjust width as needed
                  />
                  {EMI.MONTHS}{" "}
                </span>
              </div>
            </div>
            <input
              type="range"
              min={Number(minTenure)}
              max={Number(maxTenure)}
              step={1}
              value={tenure}
              onChange={(e) => setTenure(parseInt(e.target.value))}
              className="w-full h-1 bg-red-100 text-ellipsis overflow-hidden"
            />
            <div className="flex justify-between label label_sm label_primary">
              <p>
                <span>{minTenure}</span> {EMI.MONTHS}
              </p>
              <p>
                <span>{maxTenure}</span> {EMI.MONTHS}
              </p>
            </div>
          </div>
        </div>
        <div className="flex">
          <div className="w-6/12 lg:w-full ">
            <div className="lg:mt-20-md w-full lg:p-10 mt-10 lg:mt-10">
              <CircularProgressBar
                progress={((principal / totalAmount) * 100).toFixed(2)}
                color="#E31837"
                trackColor="#EDE0E3"
              />
            </div>
          </div>
          <div className="w-6/12 lg:w-full">
            <div className="flex-2 p-4">
              <div className="mt-4 md:mt-14">
                <div className="sm:border lg:border-none border-b-red-100 border-none w-full">
                  <ul className="space-y-4">
                    <li className="mb-[21px]">
                      <div className="flex flex-row items-center">
                        <span className="h-3 w-3  rounded-full inline-block bg-gray-200 border border-gray-400"></span>
                        <p className="label label_lg label_primary font-normal px-2">
                          {EMI.TOTAL_INTEREST}
                        </p>
                      </div>
                      <span className="title title_lg title_primary font-normal px-2">
                        {EMI.RUPEE} {formatNumberInThousands(totalInterest)}
                      </span>
                    </li>
                    <li className="mb-7">
                      <div className="flex flex-row items-center">
                        <span className="h-3 w-3 rounded-full inline-block bg-red-500 "></span>
                        <p className="label label_lg label_primary font-normal px-1 lg:px-2">
                          {EMI.PRINCIPAL_AMOUNT}
                        </p>
                      </div>
                      <span className="flex items-center title title_lg title_primary font-normal px-2 mb-5 ">
                        <p>
                          {EMI.RUPEE} {formatNumberInThousands(principal)}
                        </p>
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="lg:border-none border border-t-red-500 w-full lg:flex flex-row justify-start items-start hidden">
                <div className="">
                  <p className=" px-2 label label_xl label_primary">
                    {EMI.MONTHLY_EMI}
                  </p>
                  <span className="headline headline_xl headline_primary lg:text-[32px]">
                    {EMI.RUPEE} {formatNumberInThousands(monthlyEmi)}
                  </span>
                </div>
              </div>
            </div>
          </div>
          {/* Display section */}
        </div>
      </section>
      <hr className="border border-lilac-light mt-[6px] mb-[16px] w-full lg:hidden"></hr>
      <div className="border-t-red-500 w-full flex flex-row justify-between items-center lg:hidden">
        <div className="text-red-800 mt">
          <p className="font-semibold text-[16px] px-2 font-quicksand">
            {EMI.MONTHLY_EMI}
          </p>
        </div>
        <div className="text-red-800">
          <span className="font-semibold font-quicksand text-[20px]">
            {EMI.RUPEE} {formatNumberInThousands(monthlyEmi)}
          </span>
        </div>
      </div>
    </div>
  );
};

EmiCalculator.propTypes = {
  title: PropTypes.string,
  details: PropTypes.shape({
    emi_details: PropTypes.shape({
      minLoanAmount: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      maxLoanAmount: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      minRateOfInterest: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
      ]),
      maxRateOfInterest: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
      ]),
      minTenure: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      maxTenure: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    }),
  }).isRequired,
};

export default EmiCalculator;
