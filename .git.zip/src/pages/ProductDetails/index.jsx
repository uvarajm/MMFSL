import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { PRODUCT_DETAILS } from "../../store/actions/actions";
import { Breadcrumb, MainContainer } from "../../components";
import { isObjectBlank } from "../../utils";
import {
  PRODUCT_DETAILS_CONSTANTS,
  DOWNLOAD_APP_CONSTANT,
} from "../../const/common";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import PaymentHistory from "../../components/productDetails/PaymentHistory";
import Documents from "../../components/productDetails/Documents";
import LoanDetails from "../../components/productDetails/LoanDetails";
import BackButton from "../../components/Common/BackButton";
import BasicDetails from "../../components/productDetails/BasicDetails";
import Sidebar from "../../components/OfferSidebar";
import ScrollToTop from "../../components/Common/BackToTop";
// import productDetails from "./mockData.json";
import { Button } from "@mui/material";
import PreApprovedOffer from "../../components/Common/PreApprovedOffer";

const ProductDetails = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isSticky, setIsSticky] = useState(false);
  const payload = useSelector((state) => state.productIdDetails);
  useEffect(() => {
    dispatch({
      type: PRODUCT_DETAILS,
      details: { payload },
    });
  }, [dispatch, payload]);

  const handleBack = () => {
    navigate("/product");
  };

  useEffect(() => {
    if (isObjectBlank(payload.productIdDetails)) handleBack();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payload, navigate]);

  const { productDetails, loading, error } = useSelector((state) => {
    return state.productDetails;
  });
  // const loading = false;
  // const error = false;
  const { documentDetails, loanDetails, paymentHistory } = productDetails || {};
  const { basicDetailsResponse, basicInsuranceDetails, basicBankDetails } =
    loanDetails || {};
  const [activeTab, setActiveTab] = useState(0);
  const { theme } = useSelector((state) => state.theme);
  const contentRefs = useRef([]);
  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
    const tabElement = document.getElementById(`tab-${tabId}`);
    const headerOffset = 230;
    const { top } = tabElement.getBoundingClientRect();
    window.scrollTo({
      top: window.scrollY + top - headerOffset,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const headerOffset = 150; // Adjusted for sticky header

      // Calculate the positions of each content section relative to the document
      const sectionPositions = contentRefs.current.map((ref) => {
        return {
          index: parseInt(ref.id.split("-")[1], 10),
          position: ref.offsetTop - headerOffset,
        };
      });

      // Find the index of the section closest to the top of the viewport
      const activeTabIndex = sectionPositions.reduce(
        (closestIndex, section, currentIndex) => {
          // Ensure sectionPositions[closestIndex] is defined before accessing its properties
          if (sectionPositions[closestIndex]) {
            const isCloser =
              Math.abs(section.position - scrollPosition) <
              Math.abs(
                sectionPositions[closestIndex].position - scrollPosition,
              );
            return isCloser ? currentIndex : closestIndex;
          } else {
            return currentIndex;
          }
        },
        0,
      );

      setActiveTab(activeTabIndex);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  let sortedTabs = { ...PRODUCT_DETAILS_CONSTANTS.SORTED_TABS };

  if (documentDetails && Object.keys(documentDetails).length > 0) {
    const newSortedTabs = {};
    for (const [key, value] of Object.entries(sortedTabs)) {
      newSortedTabs[key] = value;
      if (key === "paymentHistory") {
        newSortedTabs["documentDetails"] = "Documents";
      }
    }
    sortedTabs = newSortedTabs;
  }

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return (
    <MainContainer className={`flex flex-col lg:p-4 p-0`}>
      <HandleDataRendering
        data={productDetails}
        loading={loading}
        error={error}
      >
        {loanDetails?.code == "FAILURE" ? (
          <div className="text-red-500 text-sm font-semibold my-4">
            {loanDetails.message}
          </div>
        ) : (
          <div className="flex flex-wrap lg:flex-nowrap w-full">
            <div className="w-full pb-2 lg:pb-0">
              <div className="flex flex-wrap">
                <div
                  className={`sticky top-[64px] sm:top-[63px] right-0 z-10  ${
                    isSticky ? "bg-white" : ""
                  } w-full dark:bg-black-200`}
                >
                  <Breadcrumb />
                  <div className="pt-3 capitalize font-semibold flex items-center text-[22px] lg:text-[28px] dark:text-white pb-[22px] lg:pb-[27px]">
                    <BackButton />
                    {basicInsuranceDetails?.POLICY_TYPE
                      ? basicInsuranceDetails?.POLICY_TYPE
                      : payload?.productIdDetails?.productCategory}
                  </div>
                </div>
                <div
                  className={`lg:w-full sticky top-[145px] lg:top-[150px] z-10 ${
                    isSticky ? "bg-white" : ""
                  } overflow-x-auto dark:bg-black-200 w-full`}
                >
                  <div
                    className={`flex justify-between shadow-custom-primary overflow-x-auto `}
                  >
                    <div className="flex">
                      {!isObjectBlank(productDetails) &&
                        Object.entries(sortedTabs).map(
                          ([key, value], index) => {
                            if (
                              loanDetails[key] ||
                              key === "paymentHistory" ||
                              key === "documentDetails"
                            )
                              return (
                                <button
                                  key={value}
                                  className={`p-4 text-sm relative flex-shrink-0 ${
                                    activeTab === index
                                      ? "text-red-500 font-bold"
                                      : theme === "light"
                                        ? "text-light-text-primary font-semibold"
                                        : "text-white font-semibold"
                                  }`}
                                  onClick={() => handleTabClick(index)}
                                >
                                  {value}
                                  {activeTab === index && (
                                    <div
                                      className={`rounded-se-full rounded-ss-full active-border  h-[3px] bg-red-500 absolute right-[16px] bottom-0 left-[16px]`}
                                    ></div>
                                  )}
                                </button>
                              );
                          },
                        )}
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap">
                  <div className=" sidebar-width">
                    {basicDetailsResponse && (
                      <div ref={(el) => (contentRefs.current[0] = el)}>
                        {Object.entries(basicDetailsResponse).length > 0 && (
                          <BasicDetails
                            basicDetailsResponse={basicDetailsResponse}
                            basicBankDetails={basicBankDetails}
                          />
                        )}
                      </div>
                    )}
                    <PreApprovedOffer />
                    {paymentHistory && documentDetails ? (
                      <>
                        {paymentHistory && (
                          <div
                            className="pt-[24px]"
                            ref={(el) => (contentRefs.current[1] = el)}
                          >
                            <PaymentHistory
                              data={paymentHistory.paymentHistory}
                            />
                          </div>
                        )}
                        {documentDetails &&
                          documentDetails?.kfs &&
                          documentDetails?.repaymnetSchedule &&
                          documentDetails?.autofininterestPrincipalBreakup && (
                            <div
                              className="pt-6 lg:pt-[40px]"
                              ref={(el) => (contentRefs.current[2] = el)}
                            >
                              <Documents data={documentDetails} />
                            </div>
                          )}
                      </>
                    ) : (
                      <div className="bg-white p-4 lg:px-[50px] lg:py-8 flex flex-wrap sm:flex-nowrap rounded-lg lg:mt-8 mt-4">
                        <div className="max-w-[480px] w-full">
                          <p className="font-semibold text-red-800 text-base md:text-[22px] mb-4">
                            {DOWNLOAD_APP_CONSTANT.GET_ACCESS}
                          </p>
                          <p className="font-karla text-md md:text-base text-grey-500">
                            {DOWNLOAD_APP_CONSTANT.DESCRIPTION}
                          </p>
                        </div>
                        <div className="sm:ml-6 w-full mt-2 sm:mt-0">
                          <p className="text-base text-grey-500 font-karla mb-2">
                            {DOWNLOAD_APP_CONSTANT.DOWNLOAD}
                          </p>
                          <div className="flex w-full">
                            <Button
                              variant="contained"
                              className="max-w-[112px] w-full !text-sm !font-quicksand !capitalize !p-2.5 !bg-red-500 !rounded-[10px]"
                            >
                              Android
                            </Button>
                            <Button
                              variant="outlined"
                              className="max-w-[112px] w-full !text-sm !font-quicksand !capitalize !p-2.5 !text-red-500 !border-red-500 !rounded-[10px] !ml-3"
                            >
                              IOS
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}

                    {Object.entries(
                      PRODUCT_DETAILS_CONSTANTS.RENDERING_SEQ,
                    ).map(([key, value], index) => {
                      if (loanDetails && loanDetails[key]) {
                        return (
                          <div
                            className="pt-[24px]"
                            ref={(el) => (contentRefs.current[3 + index] = el)}
                            key={`${key}-${index}`}
                          >
                            <LoanDetails
                              id={`tab-${index + 3}`}
                              basicDetailsResponse={loanDetails[key]}
                              title={value}
                              basicInsuranceDetails={basicInsuranceDetails}
                              sectionKey={key}
                            />
                          </div>
                        );
                      } else {
                        return null;
                      }
                    })}
                  </div>
                  <Sidebar
                    customClasses="lg:!mt-10"
                    showPreApproved={false}
                    stickyClass="!top-[220px]"
                  />
                </div>
              </div>
              <ScrollToTop
                parentClass="flex justify-center my-4"
                childClass="text-red-500 text-base font-semibold"
                buttonText="Back on top"
              />
            </div>
          </div>
        )}
      </HandleDataRendering>
    </MainContainer>
  );
};

export default ProductDetails;
