import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchLatiLongiStatusData,
  fetchLatiLongiDataSuccess,
  fetchLatiLongiDataFailure,
} from "../slices/latitudeLongitudeSlice";
import { LATITUDE_LONGITUDE_DATA } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchLatitudeLongitudeStatus({ payload }) {
  try {
    yield put(fetchLatiLongiStatusData());

    const response = yield call(
      makeApiRequest,
      endpoints.latitudeLongitude,
      BACKEND_TOKEN,
      "POST",
      payload,
    );
    yield put(fetchLatiLongiDataSuccess(response));
  } catch (error) {
    yield put(fetchLatiLongiDataFailure(error.message));
  }
}
export function* watchFetchLatitudeLongitude() {
  yield takeLatest(LATITUDE_LONGITUDE_DATA, fetchLatitudeLongitudeStatus);
}
