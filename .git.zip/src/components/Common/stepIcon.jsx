import PropTypes from "prop-types";
const CustomStepIcon = (props) => {
  const { active, completed } = props;

  return (
    <>
      {active ? (
        <div
          className={` w-[16px] h-[16px] rounded-full active-stepper relative top-[-3px] flex justify-center items-center`}
        >
          <div className={`w-[7px] h-[7px] rounded bg-[#E31837]`}></div>
        </div>
      ) : (
        <div
          className={` w-[16px] h-[16px] rounded-full relative top-[-3px] flex justify-center items-center`}
        >
          <div className={` w-[7px] h-[7px] rounded bg-lilac-light`}>
            {completed ? (
              <div className={`w-[7px] h-[7px] rounded bg-[#E31837]`}></div>
            ) : (
              <div>{/* Optionally add content here */}</div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

CustomStepIcon.propTypes = {
  active: PropTypes.bool,
  completed: PropTypes.bool,
};

export default CustomStepIcon;
