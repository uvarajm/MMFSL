import DOMPurify from "dompurify";
import { MainContainer } from "../../components";
import HandleDataRendering from "../../components/Common/HandleDataRendering";
import OfferSidebar from "../../components/OfferSidebar";
import useFetchTermAndConditionContent from "./useFetchTermAndConditionContent";
const TermsAndConditions = () => {
  const sanitizer = DOMPurify.sanitize;
  const { termAndConditionPageContent, loading, error } =
    useFetchTermAndConditionContent();

  return (
    <MainContainer className={"px-6 pb-6"}>
      <HandleDataRendering
        data={termAndConditionPageContent}
        loading={loading}
        error={error}
      >
        <div className={`sidebar-width`}>
          <div className="w-full">
            <div className={`dark:bg-dark-coral`}>
              <h1
                className={`font-semibold text-[28px] text-red-800 dark:text-white leading-[36px] font-Quicksand`}
              >
                Terms and Conditions
              </h1>
            </div>
            <div className="">
              <div
                dangerouslySetInnerHTML={{
                  __html: termAndConditionPageContent
                    ? sanitizer(termAndConditionPageContent.data)
                    : null,
                }}
              />
            </div>
          </div>
        </div>
        <OfferSidebar />
      </HandleDataRendering>
    </MainContainer>
  );
};

export default TermsAndConditions;
