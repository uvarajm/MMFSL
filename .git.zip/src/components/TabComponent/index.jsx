import PropTypes from "prop-types";
import { Tab, Tabs } from "@mui/material";
import { TabsNumber } from "../../utils";

const TabComponent = ({ foreclosureActive, setForeclosureActive }) => {
  // const [foreclosureActive, setForeclosureActive] = useState(0);

  const handleActiveTabChange = (event, newValue) => {
    setForeclosureActive(newValue);
  };

  return (
    <Tabs
      value={foreclosureActive}
      onChange={handleActiveTabChange}
      aria-label="disabled tabs example"
      TabIndicatorProps={{ style: { borderBottom: "2px solid black" } }}
    >
      {TabsNumber &&
        TabsNumber.map((item) => (
          <Tab
            key={item?.id}
            label={item?.content}
            sx={{ textTransform: "capitalize", fontSize: 14, fontWeight: 500 }}
          />
        ))}
    </Tabs>
  );
};

TabComponent.propTypes = {
  foreclosureActive: PropTypes.bool,
  setForeclosureActive: PropTypes.func,
};

export default TabComponent;
