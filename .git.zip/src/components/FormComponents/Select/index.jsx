import PropTypes from "prop-types";
import { ErrorMessage, Field } from "formik";
import TextError from "../TextError";

const Select = (props) => {
  const { label, name, options, customClassName, ...rest } = props;
  return (
    <div className="flex flex-col gap-1">
      <label
        htmlFor={name}
        className={
          customClassName
            ? "text-red-800 text-xs font-semibold font-quicksand"
            : "capitalize text-gray-800 text-lg"
        }
      >
        {label}
      </label>
      <Field
        as="select"
        id={name}
        name={name}
        {...rest}
        className={
          customClassName
            ? customClassName
            : "border-b border-gray-500 bg-transparent focus:outline-none rounded-tl-sm rounded-tr-sm py-2 px-4"
        }
      >
        {options.map((option) => {
          return (
            <option key={option.value} value={option.value}>
              {option.key}
            </option>
          );
        })}
      </Field>
      <ErrorMessage name={name} component={TextError} />
    </div>
  );
};

Select.propTypes = {
  label: PropTypes.string,
  name: PropTypes.string,
  options: PropTypes.array,
  customClassName: PropTypes.string,
};

export default Select;
