import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { GET_PRIVACY_POLICY } from "../../store/actions/actions";

const usePrivacyPolicyContent = () => {
  const dispatch = useDispatch();
  const { privacyPolicyPageContent, loading, error } = useSelector(
    (state) => state.privacyPolicypageData,
  );
  useEffect(() => {
    if (privacyPolicyPageContent.length === 0)
      dispatch({
        type: GET_PRIVACY_POLICY,
        payload: privacyPolicyPageContent,
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { privacyPolicyPageContent, loading, error };
};

export default usePrivacyPolicyContent;
