import PropTypes from "prop-types";
import Card from "../Card";
import ChevronRight from "../../assets/icons/chevron_right.svg";
import FetchDynamicImage from "../Common/FetchDynamicImage";
import DOMPurify from "dompurify";
import { Link } from "react-router-dom";
const GenericOffersCard = ({ genericOffer, header }) => {
  const sanitizer = DOMPurify.sanitize;
  return (
    <Card className="p-3 w-full lg:w-1/2 rounded-lg ">
      <div className="flex flex-nowrap items-end text-justify">
        <div className="header flex-1">
          <h4 className="label label_primary-dark pb-2">{header}</h4>
          <p
            className="content"
            dangerouslySetInnerHTML={{
              __html: sanitizer(genericOffer?.sub_header),
            }}
          ></p>
          <Link
            className="label pt-1"
            to={{
              pathname: `/offer-details/${genericOffer?.offer_id}`,
            }}
          >
            {genericOffer.button_name}
            <img className="inline" src={ChevronRight} alt="right" />
          </Link>
        </div>
        <div className="px-1">
          <FetchDynamicImage
            src={genericOffer.image}
            alt={genericOffer.name}
            customClasses="w-[100px] h-[100px]"
          />
        </div>
      </div>
    </Card>
  );
};

GenericOffersCard.propTypes = {
  genericOffer: PropTypes.object,
  header: PropTypes.string,
};
export default GenericOffersCard;
