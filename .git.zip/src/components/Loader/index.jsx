import Skeletons from "../Skeletons";
import CardSkeleton from "./CardSkeleton";

const Loader = () => {
  return (
    <>
      <div className="w-full bg-[#f1f1f1] px-4 p-4">
        <div className="w-full mb-4">
          <Skeletons
            variant="text"
            width="30%"
            height={10}
            sx={{ fontSize: "1rem" }}
          />
          <Skeletons
            variant="text"
            width="20%"
            height={7}
            sx={{ fontSize: "1rem" }}
          />
        </div>
        <div className="w-full flex items-center">
          <Skeletons
            variant="rounded"
            width="50%"
            height="20%"
            sx={{ borderRadius: "10px", marginTop: "20px", fontSize: "1rem" }}
          />
          <div className="w-full">
            <div className="w-full">
              <Skeletons
                variant="text"
                width="80%"
                height={13}
                sx={{ fontSize: "1rem" }}
              />
              <Skeletons
                variant="text"
                width="75%"
                height={10}
                sx={{ fontSize: "1rem" }}
              />
              <Skeletons
                variant="text"
                width="92%"
                height={7}
                sx={{ fontSize: "1rem" }}
              />
            </div>
            <div className="mb-3 w-full">
              <Skeletons
                variant="text"
                width="80%"
                height={13}
                sx={{ fontSize: "1rem", marginLeft: "auto" }}
              />
              <Skeletons
                variant="text"
                width="75%"
                height={10}
                sx={{ fontSize: "1rem" }}
              />
              <Skeletons
                variant="text"
                width="88%"
                height={7}
                sx={{ fontSize: "1rem", marginLeft: "auto" }}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="w-full flex max-lg:flex-col items-center pt-3 max-md:space-y-2">
        <div className="w-[70%] h-[55vh] max-lg:h-[100%] bg-[#F1F1F1] p-4 rounded-[10px] mr-2 max-lg:w-full max-lg:space-y-2">
          <div className="lg:w-56 h-5 bg-[#49454F] rounded-[10px] max-lg:w-[30%]"></div>
          <div className="pt-3">
            <div className="w-full space-y-2">
              <div className="w-full flex justify-between items-center max-md:flex-col max-md:space-y-2">
                <CardSkeleton />
                <CardSkeleton />
              </div>
              <div className="w-full flex justify-between items-center max-md:flex-col max-md:space-y-2">
                <CardSkeleton />
                <CardSkeleton />
              </div>
            </div>
          </div>
        </div>
        <div className="w-[30%] h-[55vh] max-lg:h-[100%] bg-[#F1F1F1] p-4 rounded-[10px] max-lg:w-full space-y-2 max-lg:space-y-2 max-lg:mt-3">
          <div className="w-[50%] h-5 bg-[#49454F] rounded-[10px] max-lg:w-[30%]"></div>
          <div className="w-[30%] h-5 bg-[#49454F] rounded-[10px] max-lg:w-[12%]"></div>
        </div>
      </div>
      <div className="w-full flex max-md:flex-col items-center pt-3 max-md:space-y-2">
        <div className="w-[70%] flex items-center max-md:w-full max-sm:flex-col max-sm:items-center-[unset] max-sm:flex-col-[unset]">
          <div className="w-[20%] max-md:w-[40%] max-sm:w-[100%] flex justify-start">
            <div className="w-[100%] h-5 bg-[#49454F] rounded-[10px] max-lg:w-[90%] max-sm:w-[100%]"></div>
          </div>
          <div className="w-[80%] px-10 max-md:[60%] max-sm:w-[100%] max-sm:px-[0px]">
            <Skeletons
              variant="text"
              width="100%"
              height={7}
              sx={{ fontSize: "0.1rem" }}
            />
            <Skeletons
              variant="text"
              width="100%"
              height={7}
              sx={{ fontSize: "0.1rem" }}
            />
          </div>
        </div>
        <div className="flex items-center w-[30%] max-md:w-[100%] max-sm:flex-col">
          <div className="w-[50%] max-sm:w-full">
            <div className="w-[70%] h-5 bg-[#49454F] rounded-[10px] max-lg:w-[30%] max-md:w-[60%] max-sm:w-full"></div>
            <Skeletons
              variant="text"
              width="50%"
              height={7}
              sx={{ fontSize: "0.1rem" }}
            />
          </div>
          <div className="w-[50%] max-sm:w-full">
            <div className="w-[70%] h-5 bg-[#49454F] rounded-[10px] max-lg:w-[30%] max-md:w-[60%] max-sm:w-full"></div>
            <Skeletons
              variant="text"
              width="50%"
              height={7}
              sx={{ fontSize: "0.1rem" }}
            />
          </div>
        </div>
      </div>
      <div className="w-full flex max-md:flex-col items-center pt-3 max-md:space-y-2">
        <div className="w-[70%] h-[16vh] max-lg:h-[100%] bg-[#F1F1F1] p-4 rounded-[10px] mr-2 max-md:w-full max-lg:space-y-2"></div>
        <div className="w-[30%] h-[16vh] max-lg:h-[100%] flex max-lg:flex-col justify-between items-center space-x-2 max-md:w-full">
          <div className="w-[50%] h-[16vh] max-lg:h-[100%] bg-[#F1F1F1] rounded-[10px]"></div>
          <div className="w-[50%] h-[16vh] max-lg:h-[100%] bg-[#F1F1F1] rounded-[10px]"></div>
        </div>
      </div>
    </>
  );
};

export default Loader;
