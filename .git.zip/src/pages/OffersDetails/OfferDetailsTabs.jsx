import { useEffect, useRef, useState } from "react";
import { Breadcrumb } from "../../components";
import BackButton from "../../components/Common/BackButton";
import { useSelector } from "react-redux";
import { isObjectBlank } from "../../utils";
import OffersFeatures from "../../components/Offers/OffersFeatures";
import OffersEligibility from "../../components/Offers/OffersEligibility";
import OffersBanner from "../../components/Common/OffersBanner";
import PropTypes from "prop-types";
const OfferDetailsTabs = ({ offer, offerDetails }) => {
  const [activeTab, setActiveTab] = useState(0);
  const [isSticky, setIsSticky] = useState(false);
  const { theme } = useSelector((state) => state.theme);
  const contentRefs = useRef([]);
  const [loanDetails, setLoanDetails] = useState([]);
  const [headerH1, setHeaderH1] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const headerOffset = 150; // Adjusted for sticky header

      //Calculate the positions of each content section relative to the document
      const sectionPositions = contentRefs.current.map((ref) => {
        return {
          index: parseInt(ref.id.split("-")[1], 10),
          position: ref.offsetTop - headerOffset,
        };
      });

      // Find the index of the section closest to the top of the viewport
      const activeTabIndex = sectionPositions.reduce(
        (closestIndex, section, currentIndex) => {
          // Ensure sectionPositions[closestIndex] is defined before accessing its properties
          if (sectionPositions[closestIndex]) {
            const isCloser =
              Math.abs(section.position - scrollPosition) <
              Math.abs(
                sectionPositions[closestIndex].position - scrollPosition,
              );
            return isCloser ? currentIndex : closestIndex;
          } else {
            return currentIndex;
          }
        },
        0,
      );

      setActiveTab(activeTabIndex);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
    const tabElement = document.getElementById(`tab-${tabId}`);
    const headerOffset = 100;
    const { top } = tabElement.getBoundingClientRect();
    window.scrollTo({
      top: window.scrollY + top - headerOffset,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    let customOfferDetails = {};

    if (offer?.offer_sub_type === "pl-suvidha") {
      customOfferDetails.flatRate =
        offerDetails?.offerData[0]?.result?.defaultEligibleFlatRatePa;
      customOfferDetails.loanAmount =
        offerDetails?.offerData[0]?.result?.defaultEligibleAmount;
      customOfferDetails.emi = offerDetails?.offerData[0]?.result?.emiAmount;
      customOfferDetails.tenure =
        offerDetails?.offerData[0]?.result?.defaultEligibleTenure;
    } else if (offer?.offer_sub_type === "pl-lead") {
      customOfferDetails.flatRate =
        offerDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.default_interest_rate;
      customOfferDetails.loanAmount =
        offerDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.current_maximum_amount;
      customOfferDetails.emi =
        offerDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.maximumemi;
      customOfferDetails.tenure =
        offerDetails?.plLeadResponse?.response?.crmres?.OffersDetails[0]?.current_maximum_tenure;
    } else {
      customOfferDetails.flatRate = offer.offer_detail_tabs[0].tab_details.roi;
      customOfferDetails.loanAmount =
        offer.offer_detail_tabs[0].tab_details.loan_amount;
      customOfferDetails.emi =
        offer.offer_detail_tabs[0].tab_details.emi_tenure_max;
      customOfferDetails.tenure = offer.offer_detail_tabs[0].tab_details.tenure;
    }

    const loanDetailsArr = [
      {
        label: "Loan Amount",
        value: customOfferDetails.loanAmount,
      },
      {
        label: "Monthly EMI",
        value: customOfferDetails.emi,
      },
      {
        label: "Tenure",
        value: customOfferDetails.tenure,
      },
    ];

    let heading = "";
    if (
      offer.offer_sub_type === "pl-suvidha" ||
      offer.offer_sub_type === "pl-lead"
    ) {
      offer?.header?.every((header) => {
        if (header.includes("offer_flat_rate")) {
          heading = header.replace(
            "offer_flat_rate",
            customOfferDetails.flatRate,
          );
          return true;
        } else if (header.includes("offer_amount")) {
          heading = header.replace(
            "offer_amount",
            customOfferDetails.loanAmount,
          );
          return true;
        } else if (header.includes("offer_tenure")) {
          heading = header.replace("offer_tenure", customOfferDetails.tenure);
          return true;
        }
      });
      setHeaderH1(heading);
    } else {
      offer?.header?.every((header) => {
        if (header.includes("offer_percentage")) {
          heading = header.replace(
            "offer_percentage",
            customOfferDetails.flatRate,
          );
          return true;
        } else if (header.includes("offer_amount")) {
          heading = header.replace(
            "offer_amount",
            customOfferDetails.loanAmount,
          );
          return true;
        } else if (header.includes("offer_tenure")) {
          heading = header.replace("offer_tenure", customOfferDetails.tenure);
          return true;
        }
      });
      setHeaderH1(heading);
    }
    setLoanDetails(loanDetailsArr);
  }, []);

  return (
    <>
      <div
        className={`sticky top-[64px] sm:top-[63px] right-0 z-10 ${
          isSticky ? "bg-white" : ""
        } w-full dark:bg-black-200`}
      >
        <Breadcrumb />
        <div className="pt-3 capitalize font-semibold flex items-center text-[22px] lg:text-[28px] dark:text-white">
          <BackButton />
          Offer Detail
        </div>
      </div>
      <OffersBanner
        image={offer?.image}
        primaryTitle={headerH1}
        secondaryTitle={offer?.sub_header}
      />
      <div
        className={`lg:w-[100%] sticky top-[145px] lg:top-[150px] z-10 ${
          isSticky ? "bg-white" : ""
        } overflow-x-auto dark:bg-black-200 w-full`}
      >
        <div
          className={`flex justify-between border-b shadow-custom-primary overflow-x-auto border-light-border-color dark:border-dark-border-color`}
        >
          <div className="flex">
            {!isObjectBlank(offer) &&
              offer?.offer_detail_tabs.map((tab, index) => {
                return (
                  <button
                    key={tab.tab_title}
                    className={`p-4 pb-[14px] first:pl-0 text-sm relative flex-shrink-0 ${
                      activeTab === index
                        ? "text-red-500 font-bold"
                        : theme === "light"
                          ? "text-light-text-primary font-semibold"
                          : "text-white font-semibold"
                    }`}
                    onClick={() => handleTabClick(index)}
                  >
                    {tab.tab_title}
                    {activeTab === index && (
                      <div
                        className={`rounded-se-full rounded-ss-full active-border  h-[3px] bg-red-500 absolute right-[16px] bottom-0 ${
                          index !== 1 ? "left-[16px] " : "left-0"
                        }`}
                      ></div>
                    )}
                  </button>
                );
              })}
          </div>
        </div>
      </div>
      <div className="flex flex-wrap lg:flex-nowrap">
        <div className="w-full space-y-6 pt-2 lg:pt-4">
          {!isObjectBlank(offer) &&
            offer?.offer_detail_tabs?.map((tab, index) => {
              return (
                <div
                  key={index}
                  id={`tab-${index}`}
                  className={``}
                  ref={(el) => (contentRefs.current[index] = el)}
                >
                  {tab.tab_title === "Features And Benefits" && (
                    <OffersFeatures
                      offerDetails={loanDetails}
                      features={tab.tab_details?.features_list}
                    />
                  )}
                  {tab.tab_title.trim() === "Eligibility" && (
                    <OffersEligibility
                      eligibilityList={tab.tab_details?.eligibility_list}
                      title={tab.tab_details?.title}
                    />
                  )}
                </div>
              );
            })}
        </div>
      </div>
    </>
  );
};
OfferDetailsTabs.propTypes = {
  offer: PropTypes.object,
  offerDetails: PropTypes.object,
};
export default OfferDetailsTabs;
