import { Outlet } from "react-router-dom";
import MainContainer from "../../MainContainer";
import Sidebar from "../../OfferSidebar";

const SingleColumnLayout = () => {
  // Split the pathname into segments

  return (
    <MainContainer className={`flex lg:px-[48px] p-0 w-full`}>
      <div className="sidebar-width">
        <div className="">
          <Outlet />
        </div>
      </div>
      <Sidebar className="pt-[50px]" />
    </MainContainer>
  );
};
export default SingleColumnLayout;
