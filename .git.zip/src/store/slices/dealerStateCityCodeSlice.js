import { createSlice } from "@reduxjs/toolkit";
import { DEALER_STATE_CITY_CODE } from "../actions/actions";

const initialState = {
  dealerStateCityCodeData: {},
  loading: false,
  error: null,
};

const dealerStateCityCodeSlice = createSlice({
  name: DEALER_STATE_CITY_CODE,
  initialState,
  reducers: {
    fetchDealerStateCityCodeStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchDealerStateCityCodeDataSuccess(state, action) {
      state.loading = false;
      state.dealerStateCityCodeData = action.payload;
    },
    fetchDealerStateCityCodeDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchDealerStateCityCodeStatusData,
  fetchDealerStateCityCodeDataSuccess,
  fetchDealerStateCityCodeDataFailure,
} = dealerStateCityCodeSlice.actions;

export default dealerStateCityCodeSlice.reducer;
