import {
  Box,
  Card,
  CardContent,
  Grid,
  Skeleton,
  Stack,
  Typography,
} from "@mui/material";
import { ChevronRight } from "@mui/icons-material";
import { Link } from "react-router-dom/dist";

const CommonGrid = () => {
  const handleCardClick = () => {};
  return (
    <div className="w-full bg-[#f1f1f1] px-4 p-4 mt-5 rounded-[10px]">
      <div className="w-56 h-5 bg-[#49454F] rounded-[10px]"></div>

      <Box sx={{ flexGrow: 1, pt: 2 }}>
        <Grid
          container
          spacing={{ xs: 2, md: 4 }}
          columns={{ xs: 12, sm: 6, md: 4 }}
        >
          <Grid item xs={12} sm={6} md={4}>
            <div className="flex items-center justify-between">
              <div onClick={handleCardClick}>
                <Card
                  sx={{
                    width: 375,
                    bgcolor: "#f1f1f1",
                    borderColor: "#C6C6C6",
                    height: 180,
                    cursor: "pointer",
                  }}
                >
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      Mandate Management
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Manage your active loan
                    </Typography>
                  </CardContent>
                </Card>
              </div>

              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography
                    gutterBottom
                    variant="h5"
                    component="div"
                    sx={{ color: "#161616", fontWeight: 400, fontSize: 22 }}
                  >
                    Foreclosure
                  </Typography>
                  <Stack spacing={1}>
                    <Skeleton
                      variant="text"
                      width={100}
                      height={7}
                      sx={{ fontSize: "1rem" }}
                    />
                    <Skeleton
                      variant="text"
                      width={60}
                      height={7}
                      sx={{ fontSize: "1rem" }}
                    />
                  </Stack>

                  <Typography
                    sx={{
                      paddingTop: "70px",
                      marginLeft: "250px",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    Explore <ChevronRight />
                  </Typography>
                </CardContent>
              </Card>
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Track Application Status
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Link to="track-application-status">
                      Explore
                      <ChevronRight />
                    </Link>
                  </Typography>
                </CardContent>
              </Card>
            </div>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <div className="flex items-center justify-between">
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Lizard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lizards are a widespread group of squamate reptiles, with
                    over 6,000 species, ranging across all continents except
                    Antarctica
                  </Typography>
                </CardContent>
              </Card>
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Lizard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lizards are a widespread group of squamate reptiles, with
                    over 6,000 species, ranging across all continents except
                    Antarctica
                  </Typography>
                </CardContent>
              </Card>
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Lizard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lizards are a widespread group of squamate reptiles, with
                    over 6,000 species, ranging across all continents except
                    Antarctica
                  </Typography>
                </CardContent>
              </Card>
            </div>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <div className="flex items-center justify-between">
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Lizard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lizards are a widespread group of squamate reptiles, with
                    over 6,000 species, ranging across all continents except
                    Antarctica
                  </Typography>
                </CardContent>
              </Card>
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Lizard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lizards are a widespread group of squamate reptiles, with
                    over 6,000 species, ranging across all continents except
                    Antarctica
                  </Typography>
                </CardContent>
              </Card>
              <Card
                sx={{
                  width: 375,
                  bgcolor: "#f1f1f1",
                  borderColor: "#C6C6C6",
                  height: 180,
                }}
              >
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Lizard
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lizards are a widespread group of squamate reptiles, with
                    over 6,000 species, ranging across all continents except
                    Antarctica
                  </Typography>
                </CardContent>
              </Card>
            </div>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
};

export default CommonGrid;
