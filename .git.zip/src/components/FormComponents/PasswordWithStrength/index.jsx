import PropTypes from "prop-types";
import { useState } from "react";
import { Field } from "formik";
import { MdVisibilityOff, MdVisibility } from "react-icons/md";
import { LiaTimesCircle } from "react-icons/lia";
import { MdOutlineCheckCircle } from "react-icons/md";

const PasswordWithStrength = ({
  label,
  name,
  showConfirmPassword,
  setShowPassword,
  showPassword,
  ...rest
}) => {
  const [showPasswordStrength, setShowPasswordStrength] = useState(true);
  const [passwordInfo, setPasswordInfo] = useState({
    hasLength: false,
    hasLetterAndNumber: false,
    hasNoSeqChars: false,
  });

  // const togglePasswordVisibility = () => {
  //   setShowPassword(!showPassword);
  // };

  const handlePasswordChange = (e) => {
    const password = e.target.value;

    // const hasSequential = (str) => {
    //   if (typeof str !== "string") {
    //     return false;
    //   }

    //   for (let i = 0; i < str.length - 1; i++) {
    //     if (str.charCodeAt(i + 1) - str.charCodeAt(i) === 1) {
    //       return true;
    //     }
    //   }
    //   return false;
    // };

    const hasSequential = (str) => {
      if (typeof str !== "string" || str.length === 0) {
        return false;
      }
      for (let i = 0; i < str.length - 1; i++) {
        if (str.charCodeAt(i + 1) - str.charCodeAt(i) === 1) {
          return true;
        }
      }
      return false;
    };

    const hasLetter = /([a-z].*[A-Z])|([A-Z].*[a-z])/.test(password);
    const hasNumber = /[0-9]/.test(password);

    const hasSequentialNumber = !/(123|234|345|456|567|678|789|012)/.test(
      password,
    );
    const hasLetterAndNumber = hasLetter && hasNumber;

    // const hasSpecialChar = !/[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(password);
    const hasSpecialChar = /[!@#$%^&*()_+{}[\]:;<>,.?~\\/-]/.test(password);
    const hasLength = password.length >= 10;
    const hasNoSpace = !/\s/.test(password);

    // const hasNoSeqChars =
    //   !hasSequential(password) &&
    //   hasSpecialChar &&
    //   hasSequentialNumber &&
    //   hasNoSpace;

    const hasNoSeqChars =
      password.length > 0 &&
      !hasSequential(password) &&
      hasSequentialNumber &&
      !hasSpecialChar &&
      hasNoSpace;

    setPasswordInfo({
      hasLength,
      hasLetterAndNumber,
      hasNoSeqChars,
    });
    rest.formik.setFieldValue(name, password);
  };

  // const isValidPassword = () => {
  //   return (
  //     passwordInfo.hasLength &&
  //     passwordInfo.hasLetterAndNumber &&
  //     passwordInfo.hasNoSeqChars
  //   );
  // };
  // const { placeholder, ...restWithoutPlaceholder } = rest;
  const hasError = rest.formik.errors[name] && rest.formik.touched[name];

  return (
    <div className="flex flex-col gap-1">
      <label
        htmlFor={name}
        className="font-semibold text-red-800 label label_md"
      >
        {label}
      </label>
      <div
        className={`flex gap-1 bg-transparent focus:outline-none  ${
          hasError ? "border-b-1 border-red-500 mb-1" : "w-full"
        }`}
      >
        <div className="flex items-center w-full relative">
          <Field
            id={name}
            type={showPassword && !showConfirmPassword ? "text" : "password"}
            name={name}
            value={rest.formik.values[name]}
            onChange={handlePasswordChange}
            onFocus={() => {
              setShowPasswordStrength(true);
            }}
            {...rest}
            className="bg-transparent w-full pb-[7px] pl-3 focus:outline-none border-b-2 border-red-100 mb-1 text-grey-500 label label_md leading-[22px]"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-2"
          >
            {showPassword && !showConfirmPassword ? (
              <MdVisibilityOff />
            ) : (
              <MdVisibility />
            )}
          </button>
        </div>
      </div>

      <div>
        {showPasswordStrength && (
          <ul className="flex flex-col">
            {Object.entries(passwordInfo).map(([key, value]) => (
              <li
                key={key}
                className={`text-xs flex item-center content content_md w-full py-[2px] ${
                  value ? "text-green-500" : "text-red-800"
                } `}
              >
                {value ? (
                  <span className="pr-2">
                    <MdOutlineCheckCircle className="w-4 h-4" />
                  </span>
                ) : (
                  <span className="pr-2">
                    <LiaTimesCircle className="w-4 h-4" />
                  </span>
                )}
                &nbsp;
                {passwordStrengthLabels[key]}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

const passwordStrengthLabels = {
  hasLength: "Minimum password length must be 10 Characters",
  hasLetterAndNumber:
    "Should contain one uppercase letter, lowercase letter, and a number",
  // : "Numbers (0-9) without any sequential number",
  hasNoSeqChars:
    "No sequential letters, numbers or special characters should be used e.g (!@#$%^&*) and extra space",
};

PasswordWithStrength.propTypes = {
  label: PropTypes.string,
  name: PropTypes.string,
  showConfirmPassword: PropTypes.bool,
  setShowPassword: PropTypes.func,
  showPassword: PropTypes.bool,
};

export default PasswordWithStrength;
