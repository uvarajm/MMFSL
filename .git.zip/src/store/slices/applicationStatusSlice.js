import { createSlice } from "@reduxjs/toolkit";
import { APPLICATION_STATUS } from "../actions/actions";
const initialState = {
  applicationStatus: [],
  loading: false,
  error: null,
};

const applicationStatusSlice = createSlice({
  name: APPLICATION_STATUS,
  initialState,
  reducers: {
    fetchApplicationStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchApplicationStatusDataSuccess(state, action) {
      state.loading = false;
      state.applicationStatus = action.payload;
    },
    fetchApplicationStatusDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchApplicationStatusData,
  fetchApplicationStatusDataSuccess,
  fetchApplicationStatusDataFailure,
} = applicationStatusSlice.actions;

export default applicationStatusSlice.reducer;
