import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import CustomAccordion from "../Accordion";

const highlightQuery = (text, query) => {
  const parts = text.split(new RegExp(`(${query})`, "gi"));
  return (
    <>
      {parts.map((part, index) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <b key={index}>{part}</b>
        ) : (
          part
        ),
      )}
    </>
  );
};

const SearchResults = ({ results, query, clearAndClose }) => (
  <>
    {Object.keys(results).map((key) => (
      <div className="mb-[17px] last:mb-0" key={key}>
        {key === "faq" ? (
          <>
            <div className="header__search_title capitalize">{"FAQ's"}</div>
            <CustomAccordion
              items={results[key]}
              customFontStyle="lg:!font-normal font-karla !text-grey-500"
            />
          </>
        ) : (
          <>
            {key !== "undefined" && (
              <div className="header__search_title capitalize">{key}</div>
            )}
            <ul className="header__search_saved_lists">
              {results[key].map(
                (result, index) =>
                  result.title && (
                    <li key={index} className="list__item">
                      <Link
                        to={result.url}
                        onClick={() =>
                          clearAndClose({
                            title: result.title,
                            url: result.url,
                          })
                        }
                      >
                        {highlightQuery(result.title, query)}
                      </Link>
                    </li>
                  ),
              )}
            </ul>
          </>
        )}
      </div>
    ))}
  </>
);

SearchResults.propTypes = {
  results: PropTypes.object.isRequired,
  query: PropTypes.string.isRequired,
  clearAndClose: PropTypes.func,
};

export default SearchResults;
