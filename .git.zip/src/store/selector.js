export const loginSelector = (state) => state.login;

export const registerSelector = (state) => state.register;
