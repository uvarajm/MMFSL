/*
    To Do 
        1. Make encryption key to random string
        2. shift rsa key to env

*/
import * as forge from "node-forge";
function generateRandomBytes(size) {
  const array = new Uint8Array(size);
  window.crypto.getRandomValues(array);
  return array;
}
function bytesToHex(bytes) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join(
    "",
  );
}
function getKeyBuffer(key) {
  const encoder = new TextEncoder();
  return encoder.encode(key);
}
export async function aesEncryption(textToEncrypt) {
  var encryptionKey = "pMVH1FfKE5mJOAV0";
  const iv = generateRandomBytes(16);
  const ivStr = bytesToHex(iv);
  const textEncoder = new TextEncoder();
  const encodedText = textEncoder.encode(textToEncrypt);
  const keyHash = await crypto.subtle.digest(
    "SHA-256",
    textEncoder.encode(encryptionKey),
  );
  const hashArray = Array.from(new Uint8Array(keyHash));
  const hashHex = hashArray
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
  const key = hashHex.slice(0, 32);
  const keyBuffer = getKeyBuffer(key);
  const aesKey = await crypto.subtle.importKey(
    "raw",
    keyBuffer,
    "AES-CBC",
    false,
    ["encrypt"],
  );
  const encryptedBuffer = await crypto.subtle.encrypt(
    { name: "AES-CBC", iv },
    aesKey,
    encodedText,
  );
  const encryptedArray = new Uint8Array(encryptedBuffer);
  const encryptedText = btoa(String.fromCharCode(...encryptedArray));
  return `${ivStr}.${encryptedText}`;
}
export function rsaEncrypt(content) {
  try {
    let rsaPub = `
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCCw4PsDSQcPKhBsbi2pS1Xf7NkS5q9ZAZwkEDwVQA6LOgU1VaeZ25uJ197IaErHnddVyynwDHI8AcZrJBI/FwU2OBBfJRNwbGOFYXrcJh7Ac4ZzFQLSIcAFNH2MY8bjLxCndwRE1R3SfcS/XyxImfmnpiX8wwECtueWcoWQNeHeQIDAQAB
-----END PUBLIC KEY-----
`;
    let pubKey = forge.pki.publicKeyFromPem(rsaPub);
    let encryptedBytes = pubKey.encrypt(content, "RSAES-PKCS1-V1_5");
    const encryptedBase64 = forge.util.encode64(encryptedBytes);
    return encryptedBase64;
  } catch (err) {
    console.error("Error while encrypting:", err);
    return null;
  }
}
function base64ToArrayBuffer(base64String) {
  const binaryString = atob(base64String);
  const length = binaryString.length;
  const bytes = new Uint8Array(length);
  for (let i = 0; i < length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}
// Convert hexadecimal string to buffer
function hexStringToBuffer(hexString) {
  const bytes = [];
  for (let i = 0; i < hexString.length; i += 2) {
    bytes.push(parseInt(hexString.substr(i, 2), 16));
  }
  return new Uint8Array(bytes);
}
export async function aesDecrypt(encryptedData) {
  var encryptionKey = "pMVH1FfKE5mJOAV0";
  const textEncoder = new TextEncoder();
  const keyHash = await crypto.subtle.digest(
    "SHA-256",
    textEncoder.encode(encryptionKey),
  );
  const hashArray = Array.from(new Uint8Array(keyHash));
  const hashHex = hashArray
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
  const key = hashHex.slice(0, 32);
  const keyBuffer = getKeyBuffer(key);
  const decrypterKey = await crypto.subtle.importKey(
    "raw",
    keyBuffer,
    "AES-CBC",
    false,
    ["decrypt"],
  );
  const parts = encryptedData.split(".");
  if (parts.length !== 2) {
    throw new Error("Invalid payload format: expected nonce.encryptedData");
  }
  const nonce = parts[0];
  const data = parts[1];
  const iv = hexStringToBuffer(nonce);
  const encryptedArrayBuffer = base64ToArrayBuffer(data.trim());
  const decryptedBuffer = await crypto.subtle.decrypt(
    { name: "AES-CBC", iv },
    decrypterKey,
    encryptedArrayBuffer,
  );
  const decryptedData = responseDecoder(decryptedBuffer);
  return decryptedData;
}
function responseDecoder(decryptedBuffer) {
  const encodings = ["utf-8", "utf-16", "latin1"]; // Add more encodings if needed
  let decryptedString = null;
  let decoder = null;
  // Try decoding with different encodings until successful
  for (const encoding of encodings) {
    decoder = new TextDecoder(encoding);
    try {
      decryptedString = decoder.decode(decryptedBuffer);
      var decodedString = decryptedString.trim(); // Remove leading/trailing whitespace
      decodedString = decodedString.replace(/[\uFFFD]/g, "");
      return decodeURIComponent(decodedString);
    } catch (error) {
      console.log(`Decoding with ${encoding} failed:`, error);
    }
  }
  if (!decryptedString) {
    console.log("Unable to decode with any encoding.");
  }
}
