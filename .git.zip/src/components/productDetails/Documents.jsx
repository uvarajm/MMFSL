import PropTypes from "prop-types";
import { PRODUCT_DETAILS_CONSTANTS } from "../../const/common";
import { downloadPDF } from "../../utils";
const Documents = (documentDetails) => {
  return (
    <div id={`tab-2`}>
      <div className="text-base font-semibold lg:text-[20px] mb-2 lg:mb-[18px] flex justify-between">
        Documents
      </div>
      <div className="bg-white rounded-lg p-3 pt-0">
        <ul>
          {Object.entries(documentDetails.data).map(([key, value], index) => {
            return PRODUCT_DETAILS_CONSTANTS.DOCUMENTS[key] ? (
              <li
                className="flex justify-between border-b border-lilac-light items-center cursor-pointer"
                key={`${key}-${index}`}
              >
                <p className="text-red-800 font-semibold text-xs lg:text-sm mb-4 mt-3">
                  {PRODUCT_DETAILS_CONSTANTS.DOCUMENTS[key]}
                </p>
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="mr-2"
                  onClick={() =>
                    downloadPDF(value?.NGOGetDocumentBDOResponse?.docContent)
                  }
                >
                  <path
                    d="M7.99997 11.4115C7.87946 11.4115 7.76728 11.3923 7.66345 11.3538C7.5596 11.3154 7.46088 11.2493 7.3673 11.1557L4.2577 8.04615C4.10898 7.89743 4.03559 7.7234 4.03753 7.52405C4.03944 7.3247 4.11283 7.14746 4.2577 6.99232C4.41283 6.83721 4.59103 6.75708 4.7923 6.75195C4.99358 6.74682 5.17179 6.82182 5.32692 6.97695L7.25 8.90003V1.25C7.25 1.03718 7.32179 0.858984 7.46537 0.715401C7.60896 0.571801 7.78716 0.5 7.99997 0.5C8.21279 0.5 8.39099 0.571801 8.53458 0.715401C8.67816 0.858984 8.74995 1.03718 8.74995 1.25V8.90003L10.673 6.97695C10.8217 6.82823 10.9983 6.75483 11.2028 6.75675C11.4073 6.75868 11.5871 6.83721 11.7422 6.99232C11.8871 7.14746 11.9621 7.3231 11.9672 7.51925C11.9724 7.7154 11.8974 7.89103 11.7422 8.04615L8.63265 11.1557C8.53907 11.2493 8.44035 11.3154 8.3365 11.3538C8.23267 11.3923 8.12049 11.4115 7.99997 11.4115ZM2.3077 15.5C1.80257 15.5 1.375 15.325 1.025 14.975C0.675 14.625 0.5 14.1974 0.5 13.6923V11.7307C0.5 11.5179 0.5718 11.3397 0.7154 11.1961C0.858983 11.0525 1.03718 10.9808 1.25 10.9808C1.46282 10.9808 1.64102 11.0525 1.7846 11.1961C1.92818 11.3397 1.99997 11.5179 1.99997 11.7307V13.6923C1.99997 13.7692 2.03202 13.8397 2.09612 13.9038C2.16024 13.9679 2.23077 14 2.3077 14H13.6922C13.7692 14 13.8397 13.9679 13.9038 13.9038C13.9679 13.8397 14 13.7692 14 13.6923V11.7307C14 11.5179 14.0718 11.3397 14.2154 11.1961C14.3589 11.0525 14.5371 10.9808 14.75 10.9808C14.9628 10.9808 15.141 11.0525 15.2845 11.1961C15.4281 11.3397 15.5 11.5179 15.5 11.7307V13.6923C15.5 14.1974 15.325 14.625 14.975 14.975C14.625 15.325 14.1974 15.5 13.6922 15.5H2.3077Z"
                    fill="#E31837"
                  />
                </svg>
              </li>
            ) : (
              ""
            );
          })}
        </ul>
      </div>
    </div>
  );
};

Documents.propTypes = {
  documentDetails: PropTypes.object,
};

export default Documents;
