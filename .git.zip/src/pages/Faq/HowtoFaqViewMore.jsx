import { useState } from "react";
import PropTypes from "prop-types";
import Card from "../../components/Card";
import Modal from "../../components/Modal";
import ReactPlayer from "react-player";
import FetchDynamicImage from "../../components/Common/FetchDynamicImage";
import iconConfig from "../../assets/iconsConfig";
import { truncateText } from "../../utils/commonUtils";
import NoData from "../../components/Common/NoData";

const { play_circle } = iconConfig;

const HowtoFaqViewMore = ({ howToFaqData }) => {
  const [selectedVideo, setSelectedVideo] = useState(null);

  if (!howToFaqData || howToFaqData.length === 0) {
    return <NoData errorText={"No Videos"} />;
  }

  return (
    <div className="w-full">
      <div className="flex flex-wrap lg:flex-nowrap w-full">
        <div className="w-full">
          {howToFaqData.map((howToItem, index) => (
            <section key={index}>
              <div className="rounded p-2 pb-0 lg:p-4">
                <Card className="!bg-transparent">
                  <div className="flex flex-wrap gap-3">
                    {howToItem.videos.map((video, idx) => (
                      <div
                        key={`${index}-${video.id || idx}`}
                        className="relative flex flex-col my-2 p-2  bg-lilac-light rounded-lg"
                      >
                        <div className="relative w-[148px] h-88">
                          <FetchDynamicImage
                            src={video.thumbnail}
                            alt={video.title}
                          />
                          <img
                            src={play_circle}
                            alt="Play Icon"
                            className="absolute inset-0 w-10 h-10 m-auto cursor-pointer"
                            onClick={() => setSelectedVideo(video)}
                          />
                        </div>
                        <div className="font-quicksand text-xs text-red-800 font-semibold p-2">
                          {truncateText(video.sub_title, 25)}
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </section>
          ))}
        </div>
      </div>
      <Modal
        isOpen={!!selectedVideo}
        className="rounded-lg md:max-w-[696px] w-full"
        onClose={() => setSelectedVideo(null)}
      >
        <div className="w-full h-auto md:w-[696px] md:h-[485px] bg-white rounded-lg">
          {selectedVideo && (
            <>
              <ReactPlayer
                url={selectedVideo.video_url}
                width="100%"
                height="80%"
                controls={true}
                playing={true}
                style={{ borderRadius: "8px" }}
              />
              <div className="mt-3 ml-3">
                <h4 className="font-quicksand text-[22px] font-semibold text-red-800">
                  {selectedVideo.title}
                </h4>
                <p className="font-karla text-xs text-grey-500">
                  {selectedVideo.sub_title}
                </p>
              </div>
            </>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default HowtoFaqViewMore;

HowtoFaqViewMore.propTypes = {
  howToFaqData: PropTypes.array,
};
