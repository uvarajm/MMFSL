import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useSelector } from "react-redux";
import { Input, Button, Alert } from "../../components";
import { Container } from "../../components";
import { validation } from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";
import { REGISTRATION } from "../../const/common";

const LoanAccount = () => {
  const navigate = useNavigate();
  const [wrongAttempts, setWrongAttempts] = useState(0);
  const [alertError, setAlertError] = useState(false);
  const register = useSelector((state) => state.register);
  const initialValues = {
    loanDetails: "",
  };
  const validationSchema_loan = Yup.object({
    loanDetails: validation("Enter Loan Account number").min(10),
  });
  const onSubmit = (values, { setFieldError }) => {
    if (values.loanDetails === "ABCDE1234F") {
      register.isPan === true
        ? navigate("/register/set-password")
        : navigate("/register/pan-details");
    } else {
      setWrongAttempts((prevAttempts) => prevAttempts + 1);
      if (wrongAttempts >= 2) {
        setAlertError(true);
      } else {
        setFieldError(
          "loanDetails",
          `Sorry you have entered incorrect account number. ${
            2 - wrongAttempts
          } attempts remaining.`,
        );
      }
    }
  };
  return (
    <Container>
      <div className="relative w-full max-w-md mx-auto flex flex-col p-4 mt-5">
        <div className="relative w-full ">
          <div className="flex flex-col flex-1">
            <div className="flex lg:block">
              <BackButton />
              <p className="mb-4 headline headline_xl headline_primary lg:mt-7">
                {REGISTRATION.FEW_MORE}
              </p>
            </div>
            <p className="mb-6 content content_lg content_secondary">
              {REGISTRATION.PLEASE_ENTER}
            </p>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema_loan}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="flex flex-col space-y-6">
                  <div className="flex flex-col space-y-2">
                    <Input
                      name="loanDetails"
                      label={REGISTRATION.LABEL_Loan_AC_NO}
                      formik={formik}
                      disabled={alertError}
                      className={`label label_md border-red ${
                        alertError
                          ? "text-disable-red border-disable-red "
                          : "text-grey-500 border-red-100"
                      }`}
                    />
                    <p
                      className={`content content_md content_secondary ${
                        alertError ? "text-disable-red" : "text-grey-500"
                      }`}
                    >
                      {REGISTRATION.EG_12}
                    </p>
                  </div>
                  {!alertError && (
                    <div className="lg:pt-10 pt-40">
                      <Button
                        type="submit"
                        name="Verify"
                        disabled={!(formik.isValid && formik.dirty)}
                        className=" text-white w-full  h-[42px] rounded-md bg-red-500 disabled:bg-disable-red disabled:text-red-200 disabled:cursor-not-allowed"
                      >
                        {REGISTRATION.BTN_VERI}
                      </Button>
                    </div>
                  )}
                  {alertError && (
                    <Alert
                      className="bg-white rounded-sm text-grey-500 text-[12px] font-karla"
                      errorMessage=""
                    >
                      {REGISTRATION.ERROR_MESSAGE}{" "}
                      <span className="text-red-500">
                        {REGISTRATION.NEAR_BRANCH}
                      </span>{" "}
                      {REGISTRATION.RES}.
                    </Alert>
                  )}
                </Form>
              )}
            </Formik>
            <button
              onClick={() => navigate("/register/pan-authenticate")}
              name={REGISTRATION.TRY_PAN}
              className={`mt-6  h-[42px] w-full py-2 rounded-md label label_lg ${
                alertError
                  ? "bg-red-500 text-white"
                  : "text-red-500 border border-red-500 dark:border-red-700 dark:text-red-700"
              }`}
            >
              {REGISTRATION.TRY_PAN}
            </button>
          </div>
        </div>
      </div>
    </Container>
  );
};
export default LoanAccount;
