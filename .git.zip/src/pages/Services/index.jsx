import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { SERVICE_LISTS } from "../../store/actions/actions";
import ProductPageDetails from "../Products/ProductPageDetails";
import { MainContainer } from "../../components";
import ServiceLists from "./ServiceLists";
import { SERVICES_PAGE_CONSTANTS } from "../../const/common";
import serviceListData from "./serviceLists.json";
import OpenServices from "./OpenServices";
import ClosedServices from "./ClosedServices";
const Services = () => {
  const dispatch = useDispatch();
  const Navigate = useNavigate();
  const {
    loginStatus,
    services,
    error: openServiceError,
    loading: openServiceLoading,
    mobileNumber,
  } = useSelector((state) => {
    return {
      loginStatus: state.login.loginStatus,
      mobileNumber: state.login.mobileNumber,
      services: state.services.services,
      error: state.services.error,
      loading: state.services.loading,
    };
  });
  const [Services, open_request, closed_request] =
    SERVICES_PAGE_CONSTANTS.PRODUCT_TABS;
  let defaultActiveTab = loginStatus ? "Services" : "Open requests";
  useEffect(() => {
    if (!services?.Open) {
      dispatch({
        type: SERVICE_LISTS,
        payload: { type: "Open", mobileNumber: mobileNumber },
      });
    }
    if (!services?.Close) {
      dispatch({
        type: SERVICE_LISTS,
        payload: { type: "Close", mobileNumber: mobileNumber },
      });
    }
  }, [dispatch, services]);

  const handleRedirection = (path) => {
    Navigate(path);
  };

  const renderTabContent = (activeTab) => {
    const tabContentMap = {
      [Services]: (
        <ServiceLists serviceListData={serviceListData} listType="Services" />
      ),
      [open_request]: (
        <OpenServices
          openServiceData={services.Open}
          loading={openServiceLoading}
          error={openServiceError}
          handleRedirection={handleRedirection}
        />
      ),
      [closed_request]: (
        <ClosedServices
          closedServiceData={services.Close}
          loading={openServiceLoading}
          error={openServiceError}
          handleRedirection={handleRedirection}
        />
      ),
    };

    return tabContentMap[activeTab];
  };
  return (
    <MainContainer className="" showSidebar={true}>
      <ProductPageDetails
        productDetails={SERVICES_PAGE_CONSTANTS}
        renderTabContent={renderTabContent}
        defaultActiveTab={defaultActiveTab}
        showBeforeLogin={true}
      />
    </MainContainer>
  );
};

export default Services;
