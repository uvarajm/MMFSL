import PropTypes from "prop-types";
import StepConnector, {
  stepConnectorClasses,
} from "@mui/material/StepConnector";
import { styled } from "@mui/system";

const CustomConnectorRoot = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 4,
    left: "calc(-50% + 4px)",
    right: "calc(50% + 4px)",
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 1,
    border: 0,
    backgroundColor: "#EDE0E3",
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundColor: "#E31837",
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundColor: "#E31837",
    },
  },
}));

const CustomStepConnector = (props) => {
  const { active, completed } = props;

  return (
    <CustomConnectorRoot {...props}>
      <div
        className={`check-circle-icon h-[2px] ${
          active || completed ? "bg-[#E31837]" : "bg-gray-200"
        }`}
      />
    </CustomConnectorRoot>
  );
};

CustomStepConnector.propTypes = {
  active: PropTypes.bool,
  completed: PropTypes.bool,
};

export default CustomStepConnector;
