import { takeLatest, call, put } from "redux-saga/effects";
import {
  fetchRegisteredStatusData,
  fetchRegisteredDataSuccess,
  fetchRegisteredDataFailure,
} from "../slices/registerUserSlice";
import { REGISTERED_USER } from "../actions/actions";
import { endpoints } from "../../utils/apiUtils";
function* fetchRegisteredStatus(data) {
  try {
    const { payload } = data;
    const { token, ...restPayload } = payload;
    yield put(fetchRegisteredStatusData());
    const config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    const response = yield call(
      endpoints.registerUser,
      "POST",
      restPayload,
      config,
    );
    yield put(fetchRegisteredDataSuccess(response?.data));
  } catch (error) {
    yield put(fetchRegisteredDataFailure(error.message));
  }
}
export function* watchFetchRegisteredUser() {
  yield takeLatest(REGISTERED_USER, fetchRegisteredStatus);
}
