import Skeletons from "../Skeletons";

const CardSkeleton = () => {
  return (
    <div className="w-full h-40 bg-[#e2e2e2] mr-2 rounded-[10px] px-2 relative">
      <Skeletons
        variant="text"
        width={100}
        height={30}
        sx={{ fontSize: "1rem" }}
      />
      <Skeletons
        variant="text"
        width={150}
        height={7}
        sx={{ fontSize: "1rem" }}
      />
      <Skeletons
        variant="text"
        width={80}
        height={7}
        sx={{ fontSize: "1rem" }}
      />
      <Skeletons
        variant="text"
        width={100}
        height={30}
        sx={{ fontSize: "1rem", position: "absolute", bottom: 10, right: 10 }}
      />
    </div>
  );
};

export default CardSkeleton;
