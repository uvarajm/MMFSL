import PropTypes from "prop-types";
import ProductItems from "./ProductItems";
import HandleDataRendering from "../Common/HandleDataRendering";

const ProductFeatures = ({ categoryProduct, error, loading }) => {
  return (
    <HandleDataRendering data={categoryProduct} error={error} loading={loading}>
      <>
        {categoryProduct &&
          categoryProduct.map((products) => {
            return (
              <ProductItems
                key={products.product_title}
                product_title={products.product_title}
                types={products.types}
              />
            );
          })}
      </>
    </HandleDataRendering>
  );
};

export default ProductFeatures;

ProductFeatures.propTypes = {
  categoryProduct: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  error: PropTypes.object,
  loading: PropTypes.bool,
};
