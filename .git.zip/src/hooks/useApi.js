import { useState, useEffect } from "react";
import { makeApiRequest } from "../utils/apiUtils";
const useApi = (
  url,
  tokenName,
  method = "GET",
  dataP = null,
  responseType = "json",
) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const result = await makeApiRequest(
          url,
          tokenName,
          method,
          dataP,
          responseType,
        );
        setData(result);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return { data, loading, error };
};
export default useApi;
