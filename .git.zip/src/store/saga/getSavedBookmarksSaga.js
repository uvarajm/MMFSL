import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchGetSavedBookmarksStatusData,
  fetchGetSavedBookmarksDataSuccess,
  fetchGetSavedBookmarksDataFailure,
} from "../slices/getSavedBookmarksSlice";
import { GET_SAVED_BOOKMARKS_DATA } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchGetSavedBookmarks({ payload }) {
  try {
    yield put(fetchGetSavedBookmarksStatusData());

    const response = yield call(
      makeApiRequest,
      endpoints.getSavedBookmarks,
      BACKEND_TOKEN,
      "POST",
      payload,
    );
    yield put(fetchGetSavedBookmarksDataSuccess(response));
  } catch (error) {
    yield put(fetchGetSavedBookmarksDataFailure(error.message));
  }
}
export function* watchFetchGetSavedBookmarks() {
  yield takeLatest(GET_SAVED_BOOKMARKS_DATA, fetchGetSavedBookmarks);
}
