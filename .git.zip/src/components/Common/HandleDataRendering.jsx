import PropTypes from "prop-types";
import Loader from "./Loader";
import NoData from "./NoData";
import { ERROR_MSG } from "../../const/common";
import { isObjectBlank } from "../../utils";

const HandleDataRendering = ({ data, loading = false, error, children }) => {
  if (loading) return <Loader />;
  if (
    data?.code == "FAILURE" ||
    error == true ||
    error?.length > 0 ||
    data?.length == 0 ||
    isObjectBlank(data)
  )
    return (
      <div className="flex items-center justify-center">
        <NoData
          errorText={
            data?.length == 0 || isObjectBlank(data)
              ? "No data found"
              : data?.message || ERROR_MSG.API_ERROR
          }
        />
      </div>
    );
  return data ? children : null;
};

HandleDataRendering.propTypes = {
  data: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  loading: PropTypes.bool,
  error: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  children: PropTypes.node,
};

export default HandleDataRendering;
