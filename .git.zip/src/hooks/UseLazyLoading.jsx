import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import UseLocateMapping from "./UseLocateMapping";
import NoData from "../components/Common/NoData";

const UseLazyLoading = ({ data }) => {
  const [visibleData, setVisibleData] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const ITEMS_PER_LOAD = 10;

  useEffect(() => {
    // Initial load
    if (data && data.length > 0) {
      setVisibleData(data.slice(0, ITEMS_PER_LOAD));
      setCurrentIndex(ITEMS_PER_LOAD);
    } else {
      setVisibleData([]);
    }
  }, [data]);

  const handleScroll = () => {
    const bottom =
      Math.ceil(window.innerHeight + window.scrollY) >=
      document.documentElement.scrollHeight - 100;
    if (bottom) {
      loadMoreData();
    }
  };

  const loadMoreData = () => {
    const nextIndex = currentIndex + ITEMS_PER_LOAD;
    if (currentIndex < data.length) {
      setVisibleData((prevData) => [
        ...prevData,
        ...data.slice(currentIndex, nextIndex),
      ]);
      setCurrentIndex(nextIndex);
    }
  };

  useEffect(() => {
    if (data.length > 10) {
      window.addEventListener("scroll", handleScroll);
      return () => window.removeEventListener("scroll", handleScroll);
    }
  }, [currentIndex, data]);

  return (
    <>
      {visibleData?.length > 0 ? (
        visibleData?.map((item, index) => (
          <UseLocateMapping key={index} item={item} />
        ))
      ) : (
        <NoData errorText="No data found..." />
      )}
    </>
  );
};

UseLazyLoading.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string,
      address: PropTypes.string,
      mobileNo: PropTypes.string,
    }),
  ),
  handleUpdateBookmarks: PropTypes.func,
  setIsBookMarked: PropTypes.func,
  isBookMarked: PropTypes.bool,
};

export default UseLazyLoading;
