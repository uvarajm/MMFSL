import PropTypes from "prop-types";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "../../components/Common/SvgIcon";

const NoData = ({ errorText, children = "" }) => {
  return (
    <div className="flex items-center p-4">
      <div className="img-wrap w-20 h-[73px]">
        <SvgIcon url={iconConfig.Light} />
      </div>
      <div className="flex flex-col  ml-4">
        <div className="text-base font-red-800 font-semibold dark:text-white">
          {errorText}
        </div>
        <div className="">{children}</div>
      </div>
    </div>
  );
};

export default NoData;
NoData.propTypes = {
  errorText: PropTypes.string,
  children: PropTypes.node,
};
