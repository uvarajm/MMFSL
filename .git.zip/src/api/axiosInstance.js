import axios from "axios";
import { BACKEND_TOKEN } from "../const/common";
import generateToken from "./tokenGenerator";
import {
  getTokenFromCookies,
  isTokenExpired,
  removeTokenFromCookies,
} from "../utils/cookiesUtil";
import { rsaEncrypt } from "../utils/encryption";

// Create a new Axios instance
const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add a request interceptor to set authorization token
axiosInstance.interceptors.request.use(
  async (config) => {
    const tokenName = config.tokenName;
    let token = getTokenFromCookies(tokenName);

    if (!token || isTokenExpired(tokenName)) {
      if (token) {
        removeTokenFromCookies(tokenName);
      }

      // Generate token if not found in cookies or if expired
      const clientId =
        tokenName === BACKEND_TOKEN
          ? import.meta.env.VITE_BACKEND_CLIENT_ID
          : import.meta.env.VITE_CMS_CLIENT_ID;
      const clientSecret =
        tokenName === BACKEND_TOKEN
          ? import.meta.env.VITE_BACKEND_CLIENT_SECRETE
          : import.meta.env.VITE_CMS_CLIENT_SECRETE;
      const tokenEndpoint =
        tokenName === BACKEND_TOKEN
          ? import.meta.env.VITE_BACKEND_TOKEN_END_POINT
          : import.meta.env.VITE_CMS_TOKEN_END_POINT;

      token = await generateToken(
        clientId,
        clientSecret,
        tokenEndpoint,
        tokenName,
      );
    }

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      config.headers = {
        ...config.headers,
        "x-encryption-key": rsaEncrypt(import.meta.env.VITE_AES_KEY),
      };
    }

    return config;
  },
  (error) => Promise.reject(error),
);

// Add a response interceptor to handle token expiration
axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error?.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      const tokenName = originalRequest.tokenName;
      const clientId =
        tokenName === BACKEND_TOKEN
          ? import.meta.env.VITE_BACKEND_CLIENT_ID
          : import.meta.env.VITE_CMS_CLIENT_ID;
      const clientSecret =
        tokenName === BACKEND_TOKEN
          ? import.meta.env.VITE_BACKEND_CLIENT_SECRETE
          : import.meta.env.VITE_CMS_CLIENT_SECRETE;
      const tokenEndpoint =
        tokenName === BACKEND_TOKEN
          ? import.meta.env.VITE_BACKEND_TOKEN_END_POINT
          : import.meta.env.VITE_CMS_TOKEN_END_POINT;

      const newToken = await generateToken(
        clientId,
        clientSecret,
        tokenEndpoint,
        tokenName,
      );
      document.cookie = `${tokenName}=${newToken}; path=/; secure; SameSite=Strict;`;

      originalRequest.headers.Authorization = `Bearer ${newToken}`;
      return axiosInstance(originalRequest);
    }
    return Promise.reject(error);
  },
);

export default axiosInstance;
