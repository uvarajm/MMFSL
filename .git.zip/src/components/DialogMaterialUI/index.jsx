import PropTypes from "prop-types";
import * as React from "react";
import Button from "../Button";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Box } from "@mui/material";
import { CloseOutlined } from "@mui/icons-material";

export default function DialogMaterialUI(props) {
  const { name, onAccept, formik, ...rest } = props;

  const [open, setOpen] = React.useState(false);
  const [scroll, setScroll] = React.useState("paper");

  const handleClickOpen = (scrollType) => () => {
    setOpen(true);
    setScroll(scrollType);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const acceptTerms = () => {
    setOpen(false);

    onAccept();
    if (formik) {
      formik.setFieldValue("termsAndCondition", true);
    }
  };

  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [open]);

  return (
    <React.Fragment>
      <span>
        <button
          type="button"
          onClick={handleClickOpen("paper")}
          className="underline  text-[13px] lg:text-[14px] flex-nowrap text-tac-blue"
        >
          {name}
        </button>
      </span>

      <Dialog
        open={open}
        onClose={handleClose}
        scroll={scroll}
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
        {...rest}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            pr: 2,
          }}
        >
          <DialogTitle id="scroll-dialog-title">
            Terms and Conditions
          </DialogTitle>
          <CloseOutlined onClick={handleClose} sx={{ cursor: "pointer" }} />
        </Box>
        <DialogContent dividers={scroll === "paper"}>
          <DialogContentText
            id="scroll-dialog-description"
            ref={descriptionElementRef}
            tabIndex={-1}
          >
            {[...new Array(50)]
              .map(
                () => `Cras mattis consectetur purus sit amet fermentum.
Cras justo odio, dapibus ac facilisis in, egestas eget quam.
Morbi leo risus, porta ac consectetur ac, vestibulum at eros.
Praesent commodo cursus magna, vel scelerisque nisl consectetur et.`,
              )
              .join("\n")}
          </DialogContentText>
        </DialogContent>
        <div className="w-full flex gap-1 bg-[#ffffff] justify-center py-5">
          <Button
            onClick={acceptTerms}
            name="I Accept"
            className="border-none px-20 py-3 bg-button-bg-red text-white rounded-[100px] xs:w-full sm:mx-1 w-72 "
          />
        </div>
      </Dialog>
    </React.Fragment>
  );
}

DialogMaterialUI.propTypes = {
  name: PropTypes.string,
  onAccept: PropTypes.func,
  formik: PropTypes.object,
};
