import PropTypes from "prop-types";
import { useEffect } from "react";
import UseLazyLoading from "../../hooks/UseLazyLoading";
import { useSelector } from "react-redux";
import { removeDuplicates } from "../../utils/commonUtils";

const Saved = ({
  latitude,
  longitude,
  latitudeLongitudeData,
  saveList,
  setSaveList,
}) => {
  const { getSavedBookmarksData } = useSelector((state) => state.getBookmarks);
  const { bookmarkObj } = useSelector((state) => state.bookmark);
  useEffect(() => {
    if (
      getSavedBookmarksData?.dealerList?.length > 0 ||
      getSavedBookmarksData?.branchList?.length > 0
    ) {
      const { dealerList = [], branchList = [] } = getSavedBookmarksData;

      const dealerListWithSaved = dealerList.map((dealer) => ({
        ...dealer,
        saved: true,
      }));

      const branchListWithSaved = branchList.map((branch) => ({
        ...branch,
        saved: true,
      }));
      const filteredArray = removeDuplicates([
        ...dealerListWithSaved,
        ...branchListWithSaved,
      ]);
      setSaveList(filteredArray);
    } else {
      setSaveList([]);
    }
  }, [getSavedBookmarksData, bookmarkObj.isBookmarks]);

  return (
    <div className="w-full">
      <p className="title title_sm title_primary leading-[22px]">
        {latitude && longitude
          ? latitudeLongitudeData?.branchList?.length
          : saveList?.length > 0 && saveList?.length + " branches near you "}
      </p>

      <div className="pt-2 lg:max-w-[678px] w-full">
        <UseLazyLoading data={saveList} />
      </div>
    </div>
  );
};

Saved.propTypes = {
  getSavedBookmarksData: PropTypes.object,
  latitudeLongitudeData: PropTypes.object,
  latitude: PropTypes.number,
  longitude: PropTypes.number,
  superAppId: PropTypes.string,
  handleUpdateBookmarks: PropTypes.func,
  saveList: PropTypes.array,
  setSaveList: PropTypes.func,
  savedError: PropTypes.any,
  saveLoading: PropTypes.bool,
  updateBookmarkData: PropTypes.any,
};

export default Saved;
