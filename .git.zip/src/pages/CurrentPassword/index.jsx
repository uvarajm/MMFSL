import { useState } from "react";
import { Alert, Button, Container, Help, Password } from "../../components";
import { items } from "../../utils/utils";
import { Form, Formik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { passwordValidation } from "../../utils/validation";

const CurrentPassword = () => {
  const navigate = useNavigate();
  const [alertError, setAlertError] = useState(false);

  const initialValues = {
    currentPassword: "",
  };

  const validationSchema = Yup.object({
    currentPassword: passwordValidation("Enter password"),
  });

  const onSubmit = (values, { setFieldError }) => {
    try {
      navigate("/reset-password");
    } catch (error) {
      setFieldError("currentPassword", error.message);
      setAlertError(true);
    }
  };

  return (
    <Container>
      <div className="relative w-[560px] minHeight border border-l-[1px] border-r-[1px] flex p-4">
        <div className="absolute right-7">
          <Help helpTitle="Password Issues" items={items} />
        </div>

        <div className="flex flex-col gap-4 flex-1 mt-14">
          <h1 className="text-2xl font-medium">Enter your current Password</h1>
          <div className="flex-1">
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {(formik) => (
                <Form className="flex flex-col justify-between h-full">
                  <div className="space-y-2">
                    <Password
                      label="Enter password"
                      name="currentPassword"
                      placeholder="Enter password"
                      formik={formik}
                      disabled={alertError}
                    />
                    {alertError && <Alert errorMessage="Check your password" />}
                  </div>

                  <div className="flex  w-full">
                    <Button
                      type="submit"
                      name="Confirm"
                      disabled={!(formik.isValid && formik.dirty)}
                      className="bg-black-100 hover:opacity-85 text-white w-full h-12"
                    />
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
      </div>
    </Container>
  );
};

export default CurrentPassword;
