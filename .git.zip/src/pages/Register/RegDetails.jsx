import { Formik, Form } from "formik";
import * as Yup from "yup";
import Input from "../../components/FormComponents/Input";
import Button from "../../components/Button";
import { useNavigate } from "react-router-dom";
import { Container, Modal } from "../../components";
import BackButton from "../../components/Common/BackButton";
import { useEffect, useState } from "react";
import Icon from "../../assets/Icon";
import { useDispatch, useSelector } from "react-redux";
import { REGISTERED_USER } from "../../store/actions/actions";
import HandleDataRendering from "../../components/Common/HandleDataRendering";

const initialValues = {
  fullName: "",
};

const validationSchema = Yup.object({
  fullName: Yup.string()
    .min(3, "Minimum 3 character")
    .max(25, "MAximum 25 character")
    .required("Enter Full Name"),
});

function RegDetails() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { mobileNumber } = useSelector((state) => state.register);
  const { registeredUserData, loading, error } = useSelector(
    (state) => state.registerUser,
  );
  const [isModalOpen, setIsModalOpen] = useState(false);

  const areYouSureTriggerModal = (boolValue) => {
    setIsModalOpen(boolValue);
  };

  const onSubmit = (values) => {
    const data = {
      userFullName: values?.fullName,
      mobileNumber: mobileNumber,
      platform: "Web",
    };
    dispatch({ type: REGISTERED_USER, payload: data });
    navigate("/register/set-password");
  };

  useEffect(() => {
    if (registeredUserData && registeredUserData?.code === "SUCCESS") {
      navigate("/register/set-password");
    }
  }, [navigate, registeredUserData]);

  return (
    <Container className="max-sm:px-4">
      <HandleDataRendering
        data={registeredUserData}
        loading={loading}
        error={error}
      >
        <div className="w-full minHeight flex justify-center items-center">
          <div className="flex flex-col justify-between w-[400px]">
            <div className="flex lg:block mt-10 lg:mt-0">
              <BackButton
                isModalOpen={isModalOpen}
                setIsModalOpen={setIsModalOpen}
              />
              <p className="lg:text-[32px] text-red-800 font-semibold lg:leading-10 text-xl leading-6 pt-0 lg:pt-2">
                Tell us about yourself
              </p>
            </div>
            <div className="flex-1">
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {(formik) => (
                  <Form className="flex flex-col">
                    <div className="pt-4">
                      <Input
                        name="fullName"
                        label="Full Name"
                        type="text"
                        maxLength={25}
                        placeholder="Enter full name"
                        inputClassNameReg="border-b-1 border-red-100"
                        formik={formik}
                      />
                    </div>
                    {registeredUserData?.code === "FAILURE" && (
                      <div className="bg-white p-2 rounded-lg text-XS mt-[40px] font-karla font-normal leading-[18px] text-grey-500">
                        {registeredUserData?.message}
                      </div>
                    )}
                    <div
                      className={`flex justify-center w-full pt-10  ${
                        registeredUserData?.code === "FAILURE"
                          ? "lg:mt-0 mt-52"
                          : "lg:mt-0 mt-64"
                      }`}
                    >
                      <Button
                        type="submit"
                        name="Continue"
                        disabled={!(formik.isValid && formik.dirty)}
                        className="hover:opacity-85 w-full rounded-lg gap-2 font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
                      />
                    </div>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </div>

        <Modal
          isOpen={isModalOpen}
          className="rounded-lg lg:w-[30rem] w-full"
          onClose={() => setIsModalOpen(false)}
        >
          <div className="p-6">
            <div className="flex justify-between">
              <p className="lg:text-2xl font-semibold text-red-800 leading-[30px] font-quicksand">
                Are you sure ?
              </p>
              <Icon
                name={"Close"}
                size={24}
                className="text-red-800 cursor-pointer"
                triggerEvent={areYouSureTriggerModal}
                isModalOpen={isModalOpen}
              />
            </div>
            <p className="py-5 text-grey-500 font-normal font-karla leading-[22px]">
              Going back would mean that you would lose your progress and will
              have to restart the registration process.
            </p>
            <div className="flex items-center lg:justify-center justify-between">
              <Button
                type="submit"
                name="Back"
                className="border border-red-500 lg:w-52 w-[90px] text-red-500 font-bold rounded-lg text-sm font-quicksand"
                onClick={() => navigate("..")}
              />
              <Button
                type="submit"
                name="Stay on This page"
                className="rounded-lg bg-red-500 ml-5 w-44 lg:w-60 text-white font-bold leading-5 text-sm font-quicksand"
                onClick={() => setIsModalOpen(false)}
              />
            </div>
          </div>
        </Modal>
      </HandleDataRendering>
    </Container>
  );
}
export default RegDetails;
