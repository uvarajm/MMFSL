import { Skeleton, Stack } from "@mui/material";

const ServiceTop = () => {
  return (
    <div className="w-full bg-[#f1f1f1] px-4 p-4">
      <div className="w-full">
        <div className="w-full mb-4">
          <Skeleton
            variant="text"
            width={300}
            height={10}
            sx={{ fontSize: "1rem" }}
          />
          <Skeleton
            variant="text"
            width={450}
            height={7}
            sx={{ fontSize: "1rem" }}
          />
        </div>
        <div className="w-full flex items-center">
          <Stack spacing={1}>
            <Skeleton
              variant="rectangular"
              width={600}
              height={110}
              sx={{ borderRadius: "10px", marginTop: "20px" }}
            />
          </Stack>

          <Stack spacing={1} sx={{ px: 2 }}>
            <Skeleton
              variant="text"
              width={340}
              height={16}
              sx={{ fontSize: "1rem" }}
            />
            <Skeleton
              variant="text"
              width={340}
              height={14}
              sx={{ fontSize: "1rem" }}
            />
            <Skeleton
              variant="text"
              width={280}
              height={7}
              sx={{ fontSize: "1rem" }}
            />

            <div className="mb-3">
              <Skeleton
                variant="text"
                width={280}
                height={16}
                sx={{ fontSize: "1rem", marginLeft: "auto" }}
              />
              <Skeleton
                variant="text"
                width={340}
                height={14}
                sx={{ fontSize: "1rem" }}
              />
              <Skeleton
                variant="text"
                width={240}
                height={7}
                sx={{ fontSize: "1rem", marginLeft: "auto" }}
              />
            </div>
          </Stack>
        </div>
      </div>
    </div>
  );
};

export default ServiceTop;
