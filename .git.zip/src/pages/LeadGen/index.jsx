import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { Input, Button, Container, Select, Breadcrumb } from "../../components";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { mobileNumberValidation } from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";
import { LEAD_GEN } from "../../store/actions/actions";
import Sidebar from "../../components/OfferSidebar";
import Loader from "../../components/Common/Loader";
const LeadGen = () => {
  const options = [
    {
      key: "",
      value: "Select from below",
    },
    {
      key: "Home Type",
      value: "New Home",
    },
    {
      key: "Renovation",
      value: "Home Renovation",
    },
  ];
  const initialValues = {
    mobileNumber: "",
    pincode: "",
    fullName: "",
    productSubCategory: "",
  };
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const { leadGenData } = useSelector((state) => state?.leadGenData);
  const dispatch = useDispatch();

  const [alertError, setAlertError] = useState(false);

  const validationSchema = Yup.object({
    mobileNumber: mobileNumberValidation("Enter mobile number"),
  });

  useEffect(() => {
    if (leadGenData && leadGenData?.code === "SUCCESS") {
      setLoading(false);
      navigate("success");
    }
  }, [leadGenData, navigate]);
  const onSubmit = (values) => {
    setLoading(true);
    try {
      dispatch({
        type: LEAD_GEN,
        payload: values,
      });
    } catch (error) {
      setAlertError(true);
    }
  };
  const { productDetail } = useSelector((state) => state.productDetail);
  return (
    <Container className="px-12">
      {loading && <Loader />}
      <div className="w-full minHeight flex flex-row ">
        <div className="flex flex-col justify-between gap-4 w-9/12">
          <Breadcrumb />
          <div className="flex items-center lg:block pt-3 capitalize font-semibold text-[22px] lg:text-[28px] dark:text-white">
            <BackButton />
            {productDetail?.type_name}
          </div>
          <div>
            <h1 className="pt-3 font-semibold flex items-center text-[22px] lg:text-[22px] dark:text-white mb-8">
              Great! Please confirm your details
            </h1>
          </div>
          <div className="flex-1 w-full">
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
              handleChange
            >
              {(formik) => (
                <Form>
                  <div className="grid w-[700px] grid-cols-6 gap-8">
                    <div className="col-span-3 w-[320px]">
                      <Input
                        type="number"
                        name="mobileNumber"
                        label="Enter mobile number"
                        placeholder="Enter mobile number"
                        formik={formik}
                        disabled={alertError}
                        maxLength="10"
                        // value={mobileNumber}
                      />
                    </div>
                    <div className="col-span-3 w-80">
                      <Input
                        type="number"
                        name="pincode"
                        label="Enter Pincode"
                        placeholder="Enter pincode"
                        formik={formik}
                        maxLength="6"
                      />
                    </div>
                    <div className="col-span-3 w-80">
                      <Input
                        name="fullName"
                        label="Full Name"
                        placeholder="Enter full name"
                        formik={formik}
                      />
                    </div>
                    <div className="col-span-3 w-80">
                      <Select
                        formik={formik}
                        label={"Insurance Type"}
                        name={"Product Type"}
                        options={options}
                        customClassName="bg-transparent border-b border-red-800 focus:outline-none py-2 px-4 text-grey-500 font-karla font-normal leading-[22px]"
                      />
                    </div>
                    <div className="flex justify-center w-[178px]">
                      <Button
                        type="submit"
                        name="Submit"
                        disabled={
                          !(formik.isValid && formik.dirty) || alertError
                        }
                        className="hover:opacity-85 w-full rounded-lg gap-2 font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
                      />
                    </div>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>
        <div>
          <Sidebar
            showPreApproved={false}
            customClassName="offer-section flex flex-col items-center lg:max-w-[279px] lg:pl-4 w-full"
          />
        </div>
      </div>
    </Container>
  );
};

export default LeadGen;
