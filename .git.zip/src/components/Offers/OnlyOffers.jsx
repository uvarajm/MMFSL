import PropTypes from "prop-types";
const OnlyOffers = ({ title, children }) => {
  return (
    <div className={`content-section w-full`}>
      <div className={` py-4 headline headline_md headline_primary `}>
        {title}
      </div>

      <div className="flex flex-wrap">
        <div className="sidebar-width">{children}</div>
      </div>
    </div>
  );
};
OnlyOffers.propTypes = {
  title: PropTypes.string,
  children: PropTypes.node,
};
export default OnlyOffers;
