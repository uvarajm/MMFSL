import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchUpdateBookmarkDataStatusData,
  fetchUpdateBookmarkDataDataSuccess,
  fetchUpdateBookmarkDataDataFailure,
} from "../slices/updateBookmarkSlice";
import { UPDATE_BOOKMARKS } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchUpdateBookmark({ payload }) {
  try {
    yield put(fetchUpdateBookmarkDataStatusData());

    const response = yield call(
      makeApiRequest,
      endpoints.updateBookmark,
      BACKEND_TOKEN,
      "POST",
      { ...payload },
    );
    yield put(fetchUpdateBookmarkDataDataSuccess(response));
  } catch (error) {
    yield put(fetchUpdateBookmarkDataDataFailure(error.message));
  }
}
export function* watchFetchUpdateBookmark() {
  yield takeLatest(UPDATE_BOOKMARKS, fetchUpdateBookmark);
}
