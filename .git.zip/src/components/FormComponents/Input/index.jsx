import PropTypes from "prop-types";
import { Field, ErrorMessage } from "formik";
import TextError from "../TextError";

const Input = (props) => {
  const {
    label,
    type,
    name,
    className,
    maxLength = "",
    inputClassName = "",
    inputClassNameReg = "",
    ...rest
  } = props;

  const hasError = rest.formik.errors[name] && rest.formik.touched[name];

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <label
        htmlFor={name}
        className={`label label_lg label_primary ${className}`}
      >
        {label}
      </label>
      {hasError ? (
        <div className="flex w-full items-center border-b border-red-500 py-2 px-4">
          <Field
            id={name}
            name={name}
            type={type}
            {...rest}
            className={`bg-transparent focus:outline-none w-full text-grey-500 font-karla font-normal leading-[22px] ${inputClassName}`}
          />
          {/* <PiWarningCircleFill className="text-red-500" /> */}
        </div>
      ) : (
        <div
          className={`flex w-full items-center border-b border-red-800 py-2 px-4 ${inputClassNameReg}`}
        >
          <Field
            id={name}
            type={type}
            maxLength={maxLength}
            name={name}
            {...rest}
            className={`w-full bg-transparent focus:outline-none text-grey-500 font-karla font-normal leading-[22px] ${inputClassName}`}
          />
        </div>
      )}

      <ErrorMessage
        name={name}
        component={TextError}
        className="content_primary content content_md"
      />
    </div>
  );
};

Input.propTypes = {
  label: PropTypes.string,
  name: PropTypes.string,
  type: PropTypes.string,
  maxLength: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  inputClassName: PropTypes.string,
  className: PropTypes.string,
  inputClassNameReg: PropTypes.string,
};

export default Input;
