import PropTypes from "prop-types";

const Modal = ({ isOpen, onClose, children, className = "sm:w-1/2" }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center overlay bg-grey-400 bg-opacity-75 z-50 px-4">
      <div
        className={`bg-white shadow-lg ${className} `}
        onClick={() => onClose()}
      >
        {children}
      </div>
    </div>
  );
};

Modal.propTypes = {
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
  children: PropTypes.node,
  className: PropTypes.string,
};

export default Modal;
