import { takeLatest, put, call } from "redux-saga/effects";
import { SERVICE_LISTS } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";
import {
  fetchServiceListsStatusData,
  fetchServiceListsStatusDataFailure,
  fetchServiceListsStatusDataSuccess,
} from "../slices/serviceListSlice";

function* watchOpenListServiceStatus(action) {
  try {
    yield put(fetchServiceListsStatusData());
    console.log(action, "action");
    const response = yield call(
      makeApiRequest,
      endpoints.serviceRequests,
      BACKEND_TOKEN,
      "POST",
      {
        // mobileNumber: "8743055098",
        mobileNumber: action.payload.mobileNumber,
        srStatus: action.payload.type,
      },
    );
    let newPayload = {
      data: response,
      type: action.payload.type,
    };
    yield put(fetchServiceListsStatusDataSuccess(newPayload));
  } catch (error) {
    yield put(fetchServiceListsStatusDataFailure(error.message));
  }
}

export function* watchServiceListStatus() {
  yield takeLatest(SERVICE_LISTS, watchOpenListServiceStatus);
}
