import PropTypes from "prop-types";
import { useSelector } from "react-redux";
import { shouldShowSidebar } from "../../utils/utils";
import { useLocation } from "react-router-dom";

const MainContainer = ({ children, className }) => {
  const { open } = useSelector((state) => state.sidebar);
  const location = useLocation();
  const showButton = shouldShowSidebar(location.pathname);
  return (
    <div
      className={`${
        showButton
          ? open
            ? "minWidthPrimary lg:ml-[224px]"
            : "minWidthSecondary lg:ml-20"
          : ""
      } ${className} flex flex-wrap lg:flex-nowrap px-3 lg:px-6 pb-6`}
    >
      {children}
    </div>
  );
};

MainContainer.propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
};

export default MainContainer;
