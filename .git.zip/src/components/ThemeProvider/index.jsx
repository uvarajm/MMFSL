import PropTypes from "prop-types";
import { useSelector } from "react-redux";

const ThemeProvider = ({ children }) => {
  const { theme } = useSelector((state) => state.theme);

  return (
    <div className={`relative ${theme === "light" ? "light" : ""}`}>
      <div
        className={`fixed top-0 left-0 right-0  h-screen w-screen z-[1] ${
          theme === "light" ? "theme-gradient-light" : "dark-theme-color"
        } `}
      ></div>
      <div className=" z-[2] relative border-light-border-color text-light-text-primary light-theme-color min-h-screen">
        <div className="min-h-screen my-auto">{children}</div>
      </div>
    </div>
  );
};

ThemeProvider.propTypes = {
  children: PropTypes.node,
};

export default ThemeProvider;
