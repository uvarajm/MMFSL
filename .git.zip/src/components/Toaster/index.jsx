import PropTypes from "prop-types";
import SvgIcon from "../Common/SvgIcon";
import { useEffect, useState } from "react";

const Toaster = ({ text, url, colorClass, className = "" }) => {
  const [showToaster, setShowToaster] = useState(false);

  useEffect(() => {
    setShowToaster(true);
    const timer = setTimeout(() => {
      setShowToaster(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  if (!showToaster) return null;

  return (
    <div
      className={`flex items-center ${className} fixed right-4 bottom-4 bg-white z-[100]`}
    >
      <div className="flex flex-row fit shadow-custom-primary rounded-lg p-3 ">
        <SvgIcon
          url={url}
          colorClass={colorClass}
          className="lg:-mt-0 md:-mt-0 mt-0 px-1"
        />
        <div className={`content content-xl content-secondary-dark px-2`}>
          {text}
        </div>
      </div>
    </div>
  );
};

Toaster.propTypes = {
  text: PropTypes.string,
  url: PropTypes.string,
  colorClass: PropTypes.string,
  className: PropTypes.string,
};

export default Toaster;
