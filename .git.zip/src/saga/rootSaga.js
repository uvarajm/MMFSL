import { all, fork } from "redux-saga/effects";
import { watchGetLogin } from "../pages/Login/saga";
import { watchFetchProductCategoryStatus } from "../store/saga/productCategorySaga";
import { watchFetchInProgressProducts } from "../store/saga/inProgressProducts";
import { watchfetchTermAndConditionContent } from "../store/saga/termAndConditionPageSaga";
import { watchFetchRegister } from "../store/saga/registerSaga";
import { watchFetchValidateOtp } from "../store/saga/validateOtpSaga";
import { watchFetchCreatePasswordStatus } from "../store/saga/createPasswordSaga";
import { watchFetchLoanListProducts } from "../store/saga/loanList";
import { watchFetchProductDetailsStatus } from "../store/saga/productDetailsSaga";
import { watchfetchPrivacyPolicyContent } from "../store/saga/privacyPolicySaga";
import { watchFetchRegisteredUser } from "../store/saga/registerUserSaga";
import { watchFetchPanAccountUser } from "../store/saga/panValidateSaga";
import { watchFetchRegisteredUserStatus } from "../store/saga/registrationUserStatusSaga";
import { watchfetchPaymentData } from "../store/saga/paymentSaga";
import { watchFetchLeadGenStatus } from "../store/saga/leadGenSaga";
import { watchFetchStateList } from "../store/saga/StateListSaga";
import { watchFetchDealerPinCode } from "../store/saga/dealerPincodeSaga";
import { watchFetchBranchStateCityStatus } from "../store/saga/branchStateCityCodeSaga";
import { watchFetchLatitudeLongitude } from "../store/saga/latitudeLongitudeSaga";
import { watchFetchGetSavedBookmarks } from "../store/saga/getSavedBookmarksSaga";
import { watchFetchUpdateBookmark } from "../store/saga/updateBookmarkSaga";
import { watchFetchDealerStateCityCodeStatusStatus } from "../store/saga/dealerStateCityCodeSaga";
import { watchFetchAppFaqStatus } from "../store/saga/appFaqSaga";
import { watchFetchOffers } from "../store/saga/offersSaga";
import { watchFetchOffersDetails } from "../store/saga/offersDetailsSaga";
import { watchServiceListStatus } from "../store/saga/serviceOpenLists";
import { watchFetchBranchDealerPinCode } from "../store/saga/branchDealerPinCodeSaga";

const rootSaga = function* () {
  yield all([
    fork(watchGetLogin),
    fork(watchFetchRegister),
    fork(watchFetchProductCategoryStatus),
    fork(watchFetchInProgressProducts),
    fork(watchfetchTermAndConditionContent),
    fork(watchFetchValidateOtp),
    fork(watchFetchCreatePasswordStatus),
    fork(watchFetchLoanListProducts),
    fork(watchfetchPrivacyPolicyContent),
    fork(watchFetchRegisteredUser),
    fork(watchFetchPanAccountUser),
    fork(watchFetchRegisteredUserStatus),
    fork(watchFetchProductDetailsStatus),
    fork(watchfetchPaymentData),
    fork(watchFetchLeadGenStatus),
    fork(watchFetchStateList),
    fork(watchFetchBranchDealerPinCode),
    fork(watchFetchDealerPinCode),
    fork(watchFetchBranchStateCityStatus),
    fork(watchFetchLatitudeLongitude),
    fork(watchFetchGetSavedBookmarks),
    fork(watchFetchUpdateBookmark),
    fork(watchFetchDealerStateCityCodeStatusStatus),
    fork(watchFetchAppFaqStatus),
    fork(watchFetchOffers),
    fork(watchFetchOffersDetails),
    fork(watchServiceListStatus),
    // Other forks
  ]);
};
export default rootSaga;
