import { createSlice } from "@reduxjs/toolkit";
import { PAYMENT } from "../actions/actions";
const initialState = {
  payment: {},
  loading: false,
  error: null,
};
const paymentSlice = createSlice({
  name: PAYMENT,
  initialState,
  reducers: {
    fetchPaymentStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchPaymentStatusDataSuccess(state, action) {
      state.loading = false;
      state.payment = action.payload;
    },
    fetchPaymentStatusDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchPaymentStatusData,
  fetchPaymentStatusDataSuccess,
  fetchPaymentStatusDataFailure,
} = paymentSlice.actions;

export default paymentSlice.reducer;
