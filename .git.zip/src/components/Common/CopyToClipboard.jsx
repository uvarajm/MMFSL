import { useRef, useState } from "react";
import PropTypes from "prop-types";
import Tooltip from "@mui/material/Tooltip";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "./SvgIcon";

const CopyToClipboard = ({ text }) => {
  const { FileCopy } = iconConfig;
  const [open, setOpen] = useState(false);
  const pTagRef = useRef(null);

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const copyContent = () => {
    setOpen(true);
    const textToCopy = pTagRef.current?.innerText;
    navigator.clipboard.writeText(textToCopy).catch((err) => {
      console.error("Failed to copy: ", err);
    });
  };

  return (
    <div className="flex">
      <span ref={pTagRef}>{text}</span>
      <Tooltip
        PopperProps={{
          disablePortal: true,
        }}
        onClose={handleTooltipClose}
        open={open}
        title="Copied to clipboard"
        placement="bottom"
        arrow
      >
        <span onClick={copyContent}>
          <SvgIcon url={FileCopy} className={"pl-1 cursor-pointer"} />
        </span>
      </Tooltip>
    </div>
  );
};

export default CopyToClipboard;

CopyToClipboard.propTypes = {
  text: PropTypes.string,
};
