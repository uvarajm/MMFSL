export const items = [
  {
    title: "Accordion Item 1",
    content: <p>This is the content of accordion item 1.</p>,
  },
  {
    title: "Accordion Item 2",
    content: <p>This is the content of accordion item 2.</p>,
  },
  {
    title: "Accordion Item 3",
    content: <p>This is the content of accordion item 3.</p>,
  },
];

export const headerClass = ``;

export const foreclosureOptions = [
  {
    key: "Select Foreclosure Reason",
    value: "",
  },
  {
    key: "Wish to sell off my vehicle",
    value: "Wish to sell off my vehicle 1",
  },
  {
    key: "Sufficient funds available with me",
    value: "Sufficient funds available with me 2",
  },
  {
    key: "Taking a new loan from Mahindra Finance",
    value: "Taking a new loan from Mahindra Finance 3",
  },
  {
    key: "Received better offer from another financier",
    value: "Received better offer from another financier 4",
  },
];

export const TabsNumber = [
  {
    key: "Active Loans",
    content: "",
  },
];
// Check if value is a number
export const numberReg = (value) => /^\d$/.test(value);

export const numberMask = (number, maskdigit = 4, numberMask = "x") =>
  `${number}`.slice(-maskdigit).padStart(`${number}`.length, numberMask);

export const isMobile = () => window.innerWidth < 768;

export const isObjectBlank = (obj) => {
  return obj && Object.keys(obj).length === 0 && obj.constructor === Object;
};

export const downloadPDF = (base64Pdf) => {
  const linkSource = `data:application/pdf;base64,${base64Pdf}`;
  const downloadLink = document.createElement("a");
  const fileName = "file.pdf";

  downloadLink.href = linkSource;
  downloadLink.download = fileName;
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
};

export const showSearchHandler =
  location.pathname === "/product" ||
  location.pathname === "/settings" ||
  location.pathname === "/services" ||
  location.pathname === "/pay" ||
  location.pathname === "/offer" ||
  location.pathname === "/home";

export const hasBlankValue = (obj) => {
  return Object.values(obj).some((value) => value === "");
};

// check value is string or number
export const isNumber = (value) => !isNaN(value) && !isNaN(parseFloat(value));
