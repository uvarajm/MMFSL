import CircularProgress from "@mui/joy/CircularProgress";

const Loader = () => {
  return (
    <div className="absolute left-0 right-0 top-0 bottom-0">
      <div className="w-full minHeight flex justify-center items-center top-0 left-0 right-0 bottom-0 bg-grey-300 opacity-40 fixed z-40"></div>
      <div className=" w-full flex items-center justify-center h-full">
        <CircularProgress size="lg" color="danger" />
      </div>
    </div>
  );
};

export default Loader;
