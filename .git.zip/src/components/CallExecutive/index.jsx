import PropTypes from "prop-types";
import Mobile from "../../assets/call-executive/mobile.svg";
import SvgIcon from "../Common/SvgIcon";
import iconConfig from "../../assets/iconsConfig";
import { CASH_COLLECTION_POINTS } from "../../const/locateConst";

const CallExecutive = ({
  setShowCallExecutive,
  tollFreeNumber = CASH_COLLECTION_POINTS.TOLL_FREE_NUMBER,
}) => {
  return (
    <div className="w-60 h-60 bg-white rounded-md absolute -top-56 right-1 ">
      <div className="flex justify-between">
        <img src={Mobile} alt="mobile" className="ml-[25px] mt-[26px]" />
        <button
          onClick={() => setShowCallExecutive(false)}
          className="mr-[13px]"
        >
          <SvgIcon
            url={iconConfig.Close}
            colorClass="fill-red-500 "
            className="w-6 h-6"
          />
        </button>
      </div>
      <div className="p-4">
        <p className=" w-[149px] mb-2 title !font-medium title_xs title_primary">
          {CASH_COLLECTION_POINTS.CONNECT_US}
        </p>
        <p className="w-[179px] mb-2 headline headline_md headline_primary">
          {tollFreeNumber}
        </p>
        <p className="content content_md content_secondary">
          {CASH_COLLECTION_POINTS.TIMING_WEEK}
        </p>
      </div>
    </div>
  );
};

CallExecutive.propTypes = {
  setShowCallExecutive: PropTypes.func,
  tollFreeNumber: PropTypes.string,
};

export default CallExecutive;
