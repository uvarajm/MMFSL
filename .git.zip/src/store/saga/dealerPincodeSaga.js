import { call, takeLatest, put } from "redux-saga/effects";
import {
  fetchDealerPinCodeStatusData,
  fetchDealerPinCodeDataSuccess,
  fetchDealerPinCodeDataFailure,
} from "../slices/dealerPincodeSlice";
import { DEALER_PINCODE_DATA } from "../actions/actions";
import { makeApiRequest } from "../../utils/apiUtils";
import { BACKEND_TOKEN } from "../../const/common";
import { endpoints } from "../../utils/apiUtils";

function* fetchDealerPinCodeStatus({ payload }) {
  try {
    yield put(fetchDealerPinCodeStatusData());

    const response = yield call(
      makeApiRequest,
      endpoints.dealerPincode,
      BACKEND_TOKEN,
      "POST",
      payload,
    );
    yield put(fetchDealerPinCodeDataSuccess(response));
  } catch (error) {
    yield put(fetchDealerPinCodeDataFailure(error.message));
  }
}
export function* watchFetchDealerPinCode() {
  yield takeLatest(DEALER_PINCODE_DATA, fetchDealerPinCodeStatus);
}
