// saga.js
import { takeLatest, put, call } from "redux-saga/effects";
import { GET_TERM_AND_CONDITION } from "../actions/actions";
import {
  fetchtermAndConditionPageData,
  fetchtermAndConditionPageDataFailure,
  fetchtermAndConditionPageDataSuccess,
} from "../slices/tearmAndConditionPageSlice";
import { endpoints, makeApiRequest } from "../../utils/apiUtils";
import { CMS_TOKEN } from "../../const/common";

function* fetchTermAndConditionData() {
  try {
    yield put(fetchtermAndConditionPageData());
    // Retrieve the token name directly from cookies
    // Make API request using the token name
    const response = yield call(
      makeApiRequest,
      endpoints.termAndCondition,
      CMS_TOKEN,
    );
    yield put(fetchtermAndConditionPageDataSuccess(response));
  } catch (error) {
    yield put(fetchtermAndConditionPageDataFailure(error.message));
  }
}

export function* watchfetchTermAndConditionContent() {
  yield takeLatest(GET_TERM_AND_CONDITION, fetchTermAndConditionData);
}
