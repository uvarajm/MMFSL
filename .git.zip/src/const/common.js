import English from "../assets/icons/languages/english.png";
import Hindi from "../assets/icons/languages/hindi.png";
import Assamese from "../assets/icons/languages/assamese.png";
import Bengali from "../assets/icons/languages/bengali.png";
import Kannada from "../assets/icons/languages/kannada.png";
import Marathi from "../assets/icons/languages/marathi.png";
import Malayalam from "../assets/icons/languages/malayalam.png";
import Odia from "../assets/icons/languages/odia.png";
import Punjabi from "../assets/icons/languages/punjabi.png";
import Telugu from "../assets/icons/languages/telugu.png";
import Tamil from "../assets/icons/languages/tamil.png";
//Product images
import CarTag from "../../src/assets/products/car_tag.svg";
import Database from "../../src/assets/products/database.svg";
import Ecg from "../../src/assets/products/ecg.svg";
import Rickshaw from "../../src/assets/products/rickshaw.svg";
import Health_Safety from "../../src/assets/products/health_and_safety.svg";
import Home from "../../src/assets/products/home.svg";
import Shipping from "../../src/assets/products/local_shipping.svg";
import Car from "../../src/assets/products/Car.svg";
import PriceChange from "../../src/assets/products/price_change.svg";
import Tractor from "../../src/assets/products/Tractor.svg";
import Activism from "../../src/assets/products/activism.svg";
import Balance from "../../src/assets/products/balance.svg";
// import { APPLICATION_STATUS } from "../store/actions/actions";

const applicationStatus = {
  INITIATED: "Initiated",
  UNDER_PROCESS: "Under Process",
  SANCTION: "Sanction",
  POST_SANCTION: "Post Sanction",
  COMPLETED: "Completed",
};
const status = [
  "initiated",
  "under process",
  "sanction",
  "post sanction",
  "completed",
];
const DDMMMYYYY = "DD MMM YYYY";
const DDMMMYY = "DD MMM YY";
const DDMMYY = "DD-MM-YY";
const DDMMYYYY = "DD-MM-YYYY";
const TENURE_SLOTS_FOR_DATE_RANGE = [12, 15, 24, 30, 36, 42, 48, 60];
const PRODUCT_PAGE_CONSTANTS = {
  PAGE_TITLE: "Products",
  PRODUCT_TABS: ["Explore", "In-progress", "Active", "Completed"],
  OFFER_TEXT: "Offers available",
};
const INPROGRESS_PRODUCT_CONSTANTS = {
  CONGRATULATION: "Congratulations!",
  SUCCESS_MSG: "Your application was processed successfully",
  PROCESS_TEXT: "Under Process",
  KEY_LABEL_MAP: {
    applicantName: "Name",
    applicationDate: "Date of creation",
    applicationNumber: "Application Number",
    applicationStatus: "Status",
    assetName: "Asset Name",
    lmsType: "LMS Type",
    loanType: "Sale Purchase",
    branchName: "Branch Name",
    businessExecutiveName: "Business Executive Name",
    subStatus: "Sub Status",
  },
  EXCLUDED_KEYS: [
    "lmsType",
    "applicationStatus",
    "loanType",
    "stage",
    "businessExecutiveContactNumber",
    "currentDate",
    "errorCode",
  ],
  DOCUMENT_ERROR_MSG:
    "Some documents might be required to be uploaded. Please contact your business executive.",
  APPLICATION_ID_PREFIX: "Application ID #",
  APPLICATION_STATUS_TEXT: "Application status as on",
  BUSINESS_EXEC: "Contact business executive",
};

const LANGUAGE_PREFERENCES = [
  {
    icon: English,
    font: "English",
    selected: true,
  },
  {
    icon: Hindi,
    text: "Hindi",
    font: "हिंदी",
  },
  {
    icon: Assamese,
    text: "Assamese",
    font: "অসমীয়া",
  },
  {
    icon: Bengali,
    text: "Bengali",
    font: "বাংলা",
  },
  {
    icon: Kannada,
    text: "Kannada",
    font: "ಕನ್ನಡ",
  },
  {
    icon: Marathi,
    text: "Marathi",
    font: "मराठी",
  },
  {
    icon: Malayalam,
    text: "Malayalam",
    font: "മലയാളം",
  },
  {
    icon: Odia,
    text: "Odia",
    font: "ଓଡିଆ",
  },
  {
    icon: Punjabi,
    text: "Punjabi",
    font: "ਪੰਜਾਬੀ",
  },
  {
    icon: Telugu,
    text: "Telugu",
    font: "తెలుగు",
  },
  {
    icon: Tamil,
    text: "Tamil",
    font: "தமிழ்",
  },
];

const PRODUCT_TYPE_IMAGE_MAPPING = {
  home: Home,
  "new car": Car,
  "used car": CarTag,
  personal: Activism,
  "balance transfer": Balance,
  "fixed deposit": Database,
  health: Ecg,
  "three wheeler": Rickshaw,
  life: Health_Safety,
  "utility vehicle": Shipping,
  "commercial vehicle": Shipping,
  "mutual funds": PriceChange,
  tractor: Tractor,
};

const REGISTRATION = {
  PAN_OR_LOAN:
    "Please verify yourself using either your PAN or loan account number",
  PLEASE_SELECT: "Please select any one.",
  Pan: "Pan",
  LOAN: "Loan Account Number",
  CONTINUE: "Continue",
  UNABLE_TO_AUTHENTICATE:
    "Unable to authenticate you through Loan Account number. Please enter your PAN continue.",
  EG: "Eg:ABCDE1234F",
  I_Agree:
    "I agree to let Fin2go use my PAN to verify me and to save my PAN to my profile",
  VERIFY: "Verify",
  ENTER_DETAILS: "Enter more details",
  NAME_AS_PER_PAN: "Name as per PAN",
  DATE_AS_PER_PAN: "Date of birth as per PAN",
  VERIFICATION: "Verification",
  PLEASE_VERIFY: " Please verify yourself using PAN",
  PAN: "PAN",
  EG_AB: "Eg: ABCDE1234F",
  BTN_VERI: "Verify",
  ERROR_MESSAGE:
    "We are unable to authenticate you as a customer, please visit a",
  NEAR_BRANCH: "nearby branch",
  RES: "for a resolution",
  TRY_LOAN: "Try Loan account number instead",
  FEW_MORE: " Few more details",
  PLEASE_ENTER: "Please enter your Loan account number to continue",
  LABEL_Loan_AC_NO: "Loan account number",
  EG_12: "Eg: 123456789",
  TRY_PAN: "Try PAN instead",
};

const ACTIVE_LOAN_CONSTANTS = {
  SHOW_MORE_TEXT: "+5 More",
  APPLICATION_STATUS: "Application ID #2344553",
  LOAN_DETAILS: {
    LOAN_NO: "Loan no.",
    EMI_AMOUNT: "EMI amount",
    REGISTRATION_NO: "Registration no.",
    NEXT_DUE_DATE: " Next due date",
  },
  BUTTONS: {
    MANDATE: "Modify mandate",
    PAY: " Pay now",
  },
};
// EMI Calculator constants
const EMI = {
  LOAN_AMOUNT: "Loan Amount",
  RUPEE: "₹",
  LACK: "L",
  ROI: "Rate of interest",
  PERCENT: "%",
  MONTHS: "months",
  TENURE: "Tenure",
  TOTAL_INTEREST: "Total Interest",
  PRINCIPAL_AMOUNT: "Principal Amount",
  MONTHLY_EMI: "Monthly EMI",
};

const PRODUCT_DETAILS_CONSTANTS = {
  SUBTITLE: {
    basicChargeDetails: "Charges",
    basicCustomerDetails: "Basic details",
    basicBankDetails: "Bank details",
    basicAssetDetails: "Asset details",
    basicInsuranceDetails: "Insurance details",
  },
  BASIC_DETAILS: {
    registerNo: "Registration no:",
    loanNo: "Loan no:",
    Active: "Active",
    startDate: "Start date",
    endDate: "End date",
    dueDate: " Next due date",
    loanAmount: "Loan amount",
    totalOutAmount: "Total outstanding amount",
    emiPaid: "No. of EMI paid",
    chargesOverdue: "Charges Overdue",
    totalAmountOverdue: "Total amount overdue",
    emiOverdue: "EMI overdue",
    intRate: "Interest rate",
    emiAmount: "EMI amount",
    frequency: "Frequency",
    repaymentMode: "Repayment mode",
  },
  OTHER_DETAILS: {
    customerName: "Customer Name",
    coApllicantName: "Co-applicant name",
    guarantorName: "Guarantor name",
    branch: "Branch",
    executiveName: "Executive name",
    executiveNumber: "Executive number",
    additionalInterestCharges: "Additional Interest Charges",
    chequeReturnCharges: "Cheque return charges",
    otherCharges: "Repossession charges",
    repossessionCharges: "Other charges",
    vehicleRegistrationNumber: "Vehicle registration no.",
    vehicleName: "Vehicle name",
    engineNumber: "Engine number",
    chasisNumber: "Chassis number",
    bankAccHolderName: "Bank A/C holder name",
    bankName: "Bank name",
    branchName: "Branch name",
    bankAccNo: "Bank A/C number",
    umrnNo: "UMRN number",
    mandateStatus: "Mandate Status",
    frequency: "Frequency",
    POLICY_NO: "Policy number",
    POLICY_TYPE: "Policy type",
    PERIOD_OF_INS: "Period of insurance",
    POLICY_ISSUE_DATE: "Insurance date",
    POLICY_START_DATE: "Period of insurance",
    POLICY_EXPIRY_DATE: "Policy expiry date",
    INSURED_AMOUNT: "Amount insured for",
    TOTAL_PREMIUM: "Total Premium (monthly)",
    INSURANCE_COMPANY: "Insurance Company",
    UniqueRequesterId: "UniqueRequesterId",
  },
  EXCLUDED_KEYS: [
    "POLICY_EXPIRY_DATE",
    "POLICY_ISSUE_DATE",
    "UniqueRequesterId",
  ],
  SHOW_RUPEE_SYMBOL: [
    "additionalInterestCharges",
    "chequeReturnCharges",
    "otherCharges",
    "repossessionCharges",
    "INSURED_AMOUNT",
    "TOTAL_PREMIUM",
  ],
  SORTED_TABS: {
    basicDetailsResponse: "Loan Details",
    paymentHistory: "Payment History",
    documentDetails: "Documents",
    basicChargeDetails: "Charges",
    basicBankDetails: "Bank Details",
    basicCustomerDetails: "Basic Details",
    basicAssetDetails: "Asset Details​",
    basicInsuranceDetails: "Insurance details​",
  },
  RENDERING_SEQ: {
    basicChargeDetails: "Charges",
    basicBankDetails: "Bank Details",
    basicCustomerDetails: "Basic Details",
    basicAssetDetails: "Asset Details​",
    basicInsuranceDetails: "Insurance details​",
  },
  DOCUMENTS: {
    kfs: "KFS",
    repaymnetSchedule: "Repayment schedule",
    autofininterestPrincipalBreakup: "Statement of account",
  },
  COMMON: {
    MODIFY_MANDATE: "Modify mandate",
    BANK_DETAILS_INFO: " Never pay late fees or miss EMI’s",
    VEHICLE_DETAILS_INFO: "Please update your vehicle details",
    INSURANCE_DETAILS_INFO: "You don’t seem to have an insurance.",
    SET_REMINDER: "Set reminder",
    TOTAL_PAYABLE: "Total Payable",
  },
};

const RUPEE_SYMBOL = "₹ ";

const ERROR_MSG = {
  API_ERROR: "Something went wrong, Please try again later.",
};

const DOWNLOAD_APP_CONSTANT = {
  GET_ACCESS: "Get access to all features",
  DESCRIPTION:
    "View payment history, download loan documents, set payment reminders and many more features with fin2go mobile app for android & iOS.",
  DOWNLOAD: "Download app now!",
};

const DEMO_USER_MAPPING = [
  { number: 9819103401, name: "Yogesh Kotkar", ucic: "60016615695" },
  { number: 7745801845, name: "Rekha Singh", ucic: "60008950573" },
  { number: 9820215536, name: "Himanshu Singh", ucic: "60006303383" },
  { number: 8796227151, name: "Khusbu Niwas", ucic: "60001825931" },
  { number: 7715076895, name: "Nimisha Vaidya", ucic: "60016615696" },
  { number: 9167116151, name: "Saroj Yadav", ucic: "60016638206" },
  { number: 9999403408, name: "Neeru Gupta", ucic: "60000361275" },
  { number: 9782700490, name: "Ashit Kumar", ucic: "60008929986" },
  { number: 8743055098, name: "Ashit Kumar", ucic: "60008929986" }, // for service request
];
export const LOCATE = {
  PAGE_TITLE: "",
  PRODUCT_TABS: ["Branches", "Dealers", "Cash Collection Points", "Saved"],
};

const FEEDBACK = {
  INTRO: "Your feedback matters.",
  PLEASE_RATE: "Please rate your experience with us.",
  THANK_YOU: "Thank you for your feedback!",
  YOUR_INPUT: "Your inputs help us improve the app.",
  DONE: "Done",
  YOUR_FEEDBACK: "Your feedback",
  SUBMIT: "Submit",
  HAPPY: "Happy",
  UNHAPPY: "Unhappy",
  OK: "Okay",
  unhappy: 1,
  okay: 2,
  happy: 3,
};
const COMMON_HEADING_LABEL = {
  label: "Let's get started",
};

const SERVICES_PAGE_CONSTANTS = {
  PAGE_TITLE: "Services",
  PRODUCT_TABS: ["Services", "Open requests", "Closed requests"],
  OFFER_TEXT: "Services available",
};

const MOMENT_FORMATS = {
  YYYYMMDD: "YYYY-MM-DD HH:mm:ss",
  DMMMYYY_WITH_TIME: "D MMM YYYY [at] h:mm A",
  COMMA_SEPARATED_DATE_TIME: "D MMM YYYY [at] h:mm A",
};

const FOOTER = {
  TITLE: "Mahindra Finance",
  TERMS_CONDITION: "Terms & Conditions",
  PRIVACY_POLICY: "Privacy Policy",
};

export {
  PRODUCT_PAGE_CONSTANTS,
  TENURE_SLOTS_FOR_DATE_RANGE,
  DDMMYYYY,
  DDMMYY,
  DDMMMYYYY,
  DDMMMYY,
  applicationStatus,
  status,
  INPROGRESS_PRODUCT_CONSTANTS,
  REGISTRATION,
  LANGUAGE_PREFERENCES,
  PRODUCT_TYPE_IMAGE_MAPPING,
  ACTIVE_LOAN_CONSTANTS,
  EMI,
  PRODUCT_DETAILS_CONSTANTS,
  ERROR_MSG,
  RUPEE_SYMBOL,
  DOWNLOAD_APP_CONSTANT,
  DEMO_USER_MAPPING,
  FEEDBACK,
  COMMON_HEADING_LABEL,
  SERVICES_PAGE_CONSTANTS,
  MOMENT_FORMATS,
  FOOTER,
};
export const BACKEND_TOKEN = "backendToken";
export const CMS_TOKEN = "cmsToken";
