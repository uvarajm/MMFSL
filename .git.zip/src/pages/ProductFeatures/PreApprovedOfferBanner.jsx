import preApprove from "../../assets/pre-approve.png";

const PreApprovedOfferBanner = () => {
  return (
    <div className={`bg-white rounded-lg  flex justify-between pr-4`}>
      <div className="lg:pt-4 lg:px-4 p-4">
        <div className=" title title_xl title_primary-dark  mb-4 lg:mb-[16px]">
          Pre-approved offer
        </div>
        <div className="content content_xl content_secondary-dark">
          Congratulations! You are eligible for an existing offer
        </div>
        <div className="cta cursor-pointer flex items-center label label_md label_primary-dark-red mt-3">
          Avail now
          <svg
            width="7"
            className="ml-2"
            height="12"
            viewBox="0 0 7 12"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M4.94665 5.99999L0.873576 1.92689C0.735109 1.78844 0.664276 1.6144 0.661076 1.40479C0.657859 1.19519 0.728692 1.01795 0.873576 0.873087C1.01844 0.728203 1.19408 0.655762 1.40048 0.655762C1.60688 0.655762 1.78251 0.728203 1.92738 0.873087L6.4216 5.36731C6.5152 5.46089 6.58123 5.55961 6.61968 5.66346C6.65814 5.76729 6.67738 5.87947 6.67738 5.99999C6.67738 6.1205 6.65814 6.23268 6.61968 6.33651C6.58123 6.44036 6.5152 6.53908 6.4216 6.63266L1.92738 11.1269C1.78893 11.2654 1.61489 11.3362 1.40527 11.3394C1.19568 11.3426 1.01844 11.2718 0.873576 11.1269C0.728692 10.982 0.65625 10.8064 0.65625 10.6C0.65625 10.3936 0.728692 10.218 0.873576 10.0731L4.94665 5.99999Z"
              fill="#E31837"
            />
          </svg>
        </div>
      </div>
      <img src={preApprove}></img>
    </div>
  );
};

export default PreApprovedOfferBanner;
