import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";
import page404 from "../../assets/page404.png";

const PageNotFound = () => {
  const navigate = useNavigate();

  const handleHomeBack = () => {
    navigate("/");
  };

  return (
    <div className="w-full h-[100vh] flex justify-center items-center">
      <div className="w-full p-5">
        <div className="w-2/5 mx-auto">
          <img src={page404} alt="404" className="w-full object-contain" />
        </div>
        <div className="flex justify-center mx-auto mt-10 w-[320px] ">
          <Button
            variant="contained"
            className="!max-w-[175px] !w-full !text-sm !font-quicksand !capitalize  !bg-red-500 !rounded-[10px] justify-self-end mb-[6px] !p-[8px] !shadow-none"
            onClick={handleHomeBack}
            color="primary"
          >
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PageNotFound;
