import DOMPurify from "dompurify";
import PropTypes from "prop-types";
import Disclaimer from "./Disclaimer";

const StepperTitle = ({ title, details }) => {
  const { apply_steps, disclaimer = "" } = details;
  const sanitizer = DOMPurify.sanitize;
  return (
    <section className="space-y-4">
      <div className="title title_xl title_primary">{title}</div>

      <div className="bg-white rounded p-2 lg:p-4">
        <div className="flex flex-col flex-wrap md:flex-row">
          {apply_steps.map((steps, index) => (
            <div
              key={index}
              className="space-y-2 flex w-full lg:block lg:w-1/4"
            >
              {/* index number */}
              <div className="flex items-center flex-col lg:flex-row mr-2 lg:mr-0">
                <p className="bg-lilac-light h-[32px] w-[32px] flex justify-center items-center rounded-[50%] label label_lg label_primary-dark">
                  {index + 1}
                </p>
                <div
                  className={`${
                    index === apply_steps?.length - 1 ? "" : "border-b-2"
                  } border-lilac-light flex-1 2xl:w-44 lg:mr-1 w-1 bg-lilac-light`}
                />
              </div>

              <div className="space-y-1 flex flex-col pr-2">
                <p className="label label_lg label_primary-dark">
                  {steps?.title}
                </p>
                <p
                  className="primary-description"
                  dangerouslySetInnerHTML={{
                    __html: sanitizer(steps?.description),
                  }}
                ></p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {disclaimer !== "" ? <Disclaimer text={disclaimer} /> : ""}
    </section>
  );
};

StepperTitle.propTypes = {
  title: PropTypes.string.isRequired,
  details: PropTypes.shape({
    description: PropTypes.string,
    apply_steps: PropTypes.arrayOf(
      PropTypes.shape({
        title: PropTypes.string.isRequired,
      }),
    ).isRequired,
    disclaimer: PropTypes.string,
  }).isRequired,
};

export default StepperTitle;
