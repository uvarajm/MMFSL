import { createSlice } from "@reduxjs/toolkit";
import { LOAN_LIST } from "../actions/actions";

const initialState = {
  loanListDataResponse: {},
  loading: false,
  error: null,
};

const loanListProducts = createSlice({
  name: LOAN_LIST,
  initialState,
  reducers: {
    fetchLoanListProductsStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchLoanListProductsDataSuccess(state, action) {
      state.loading = false;
      state.loanListDataResponse = action.payload;
    },
    fetchLoanListProductsDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});
export const {
  fetchLoanListProductsStatusData,
  fetchLoanListProductsDataSuccess,
  fetchLoanListProductsDataFailure,
} = loanListProducts.actions;
export default loanListProducts.reducer;
