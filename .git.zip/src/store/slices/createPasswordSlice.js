import { createSlice } from "@reduxjs/toolkit";
import { CREATE_PASSWORD } from "../actions/actions";

const initialState = {
  createPasswordData: {},
  mobileNumber: "",
  loading: false,
  error: null,
};

const createPasswordSlice = createSlice({
  name: CREATE_PASSWORD,
  initialState,
  reducers: {
    fetchCreatePasswordStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchCreatePasswordDataSuccess(state, action) {
      state.loading = false;
      state.createPasswordData = action.payload;
    },
    fetchCreatePasswordDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    setMobileNumber(state, action) {
      state.mobileNumber = action.payload;
    },
  },
});

export const {
  fetchCreatePasswordStatusData,
  fetchCreatePasswordDataSuccess,
  fetchCreatePasswordDataFailure,
  setMobileNumber,
} = createPasswordSlice.actions;

export default createPasswordSlice.reducer;
