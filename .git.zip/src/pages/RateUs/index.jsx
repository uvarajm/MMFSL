import { MainContainer } from "../../components";
import OfferSidebar from "../../components/OfferSidebar";
import Feedback from "../../components/Feedback";

const RateUs = () => {
  return (
    <MainContainer className={"px-6 pb-6"}>
      <div className={`light-theme-color dark:dark-theme-color sidebar-width`}>
        <div className="w-full">
          <div className={`dark:bg-dark-coral`}>
            <h1
              className={`font-semibold text-[28px] text-red-800 dark:text-white leading-[36px] font-Quicksand`}
            >
              Rate Us
            </h1>
            <Feedback />
          </div>
        </div>
      </div>
      <OfferSidebar />
    </MainContainer>
  );
};

export default RateUs;
