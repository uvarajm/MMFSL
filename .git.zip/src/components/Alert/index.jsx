import PropTypes from "prop-types";
import { MdError } from "react-icons/md";

const Alert = ({ errorMessage, className, ...rest }) => {
  return (
    <section
      className={`w-full border-l-4 border-red-500 flex gap-3 bg-[#393939] p-4 ${className}`}
      {...rest}
    >
      <MdError color="red" size={30} />
      <span className="text-white text-[12px]">{errorMessage}</span>
    </section>
  );
};

Alert.propTypes = {
  errorMessage: PropTypes.string,
  className: PropTypes.string,
};

export default Alert;
