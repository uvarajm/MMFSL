import { useState } from "react";
import PropTypes from "prop-types";
import CloseIcon from "@mui/icons-material/Close";

function Feedback({ isOpen, onClose }) {
  const [selectedEmoji, setSelectedEmoji] = useState(null);
  const [comment, setComment] = useState("");

  const handleSubmit = () => {
    // Handle the submission logic here
    // console.log({ selectedEmoji, comments });
    onClose(); // Close the popup after submission
  };

  if (!isOpen) return null;

  return (
    <div className="fixed w-[479px] h-auto top-[150px] left-[401px] bg-white border border-gray-300 shadow-lg rounded-lg overflow-hidden p-5 z-50">
      {/* <button
        onClick={onClose}
        className="absolute top-2.5 right-2.5 bg-transparent border-none text-2xl cursor-pointer"
      >
        X
      </button> */}
      <CloseIcon
        onClick={onClose}
        className="absolute top-2.5 right-2.5 bg-transparent border-none text-2xl cursor-pointer"
        style={{ color: "red" }}
      />

      <div className="mt-10 mb-6 text-center ">
        Your feedback matters. Please rate your experience with us.
      </div>
      <div className="flex justify-around mb-5 mt-4">
        <div className="flex flex-col items-center cursor-pointer text-3xl">
          <span onClick={() => setSelectedEmoji("happy")}>😊</span>
          <p className="label label_md label_secondary-dark mt-2">Happy</p>
        </div>
        <div className="flex flex-col items-center cursor-pointer text-3xl">
          <span onClick={() => setSelectedEmoji("okay")}>😐</span>
          <p className="label label_md label_secondary-dark mt-2">Okay</p>
        </div>
        <div className="flex flex-col items-center cursor-pointer text-3xl">
          <span onClick={() => setSelectedEmoji("unhappy")}>😞</span>
          <p className="label label_md label_secondary-dark mt-2 ">Unhappy</p>
        </div>
      </div>
      {(selectedEmoji === "okay" || selectedEmoji === "unhappy") && (
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Please provide your comments"
          className="w-full h-16 mb-5 p-2 border border-gray-300"
        />
      )}
      <button
        onClick={handleSubmit}
        className="w-full h-12 p-2 bg-[#E31837] text-white rounded-md"
      >
        Submit
      </button>
    </div>
  );
}

Feedback.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
};

export default Feedback;
