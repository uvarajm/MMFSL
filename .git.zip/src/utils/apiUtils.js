import axiosInstance from "../api/axiosInstance";
import { aesEncryption, aesDecrypt } from "./encryption";
import { BACKEND_TOKEN } from "../const/common";

export const makeApiRequest = async (
  url,
  tokenName,
  method = "GET",
  dataP = null,
  responseType = "json", // default response type
) => {
  let data = dataP;
  if (tokenName === BACKEND_TOKEN) {
    data = {
      requestEncryptedData: await aesEncryption(JSON.stringify(data)),
    };
  }

  const response = await axiosInstance({
    method,
    url,
    data,
    tokenName, // Pass tokenName in the request config
    responseType, // Set response type based on requirement
  });

  if (responseType === "arraybuffer") {
    return response;
  }
  let responseData = response.data;
  if (tokenName === BACKEND_TOKEN) {
    responseData = await aesDecrypt(response.data.responseEncryptedData);
    responseData = JSON.parse(responseData);
  }
  return responseData;
};

export const endpoints = {
  applicationStatusApi: "/oneapp/api/app/v1/app-loan-status",
  payment: "/oneapp/api/bbps/v1/redirect-url",
  validateOtp: "/oneapp/api/web/v1/validate-otp",
  loanList: "/oneapp/api/common/v1/loan-list",
  panAccount: `/oneapp/api/web/v1/pan-account-user`,
  productFeatures: "/oneapp/api/v1/mahfin-product-features?language=en",
  productDetails: "/oneapp/api/product-details/v1/loan-details",
  paymentHistory: "/oneapp/api/product-details/v1/payment-history",
  productDetailsDocument: "/oneapp/api/product-details/v1/get-document",
  sendOtp: "/oneapp/api/web/v1/send-otp",
  registerUser: "/oneapp/api/web/v1/register-user",
  registrationStatus: "/oneapp/api/web/v1/registration-status",
  leadGen: "/oneapp/api/lead/v1/generate",
  callExecutive: "/oneapp/api/v1/call-executive",
  stateList: "/oneapp/api/masters/v1/get-locateUs-state-list",
  cityList: "/oneapp/api/masters/v1/get-locateUs-city-list",
  branchPinCode: "/oneapp/api/masters/v1/get-locateUs-branch-by-pinCode",
  dealerPincode: "/oneapp/api/masters/v1/get-locateUs-dealer-by-pinCode",
  branchStateCity:
    "/oneapp/api/masters/v1/get-locateUs-branch-by-state-city-code",
  latitudeLongitude: "/oneapp/api/masters/v1/get-locateUs-branch-by-lat-lon",
  getSavedBookmarks: "/oneapp/api/masters/v1/get-locateUs-bookmark",
  updateBookmark: "/oneapp/api/masters/v1/update-locateUs-bookmark",
  dealerStateCityCode:
    "/oneapp/api/masters/v1/get-locateUs-dealer-by-state-city-code",
  getSearchHistory: "/oneapp/api/common/v1/getsearchhis",
  getSearchHistoryDetails: "/oneapp/api/common/v1/saveSearchHisDetails",
  getCmsSearch: "/oneapp/api/v1/search?language=en&query=",
  faq: "/oneapp/api/v1/faq",
  termAndCondition: "/oneapp/api/v1/static-content?category=legal_notice",
  privacyPolicy: "/oneapp/api/v1/static-content?category=privacy_policy",
  rateUs: "/oneapp/api/rate-us/v1/save-record",
  recommended_search:
    "/oneapp-sit/api/v1/generic-response?category=recommended_search",
  offers: "/oneapp/api/v1/offers?language=en",
  offersDetails: "/oneapp/api/landing-page/v1/offer-details",
  serviceRequests: "/oneapp/api/servicerequest/v1/service-requests",
};
