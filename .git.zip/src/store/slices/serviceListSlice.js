import { createSlice } from "@reduxjs/toolkit";
import { SERVICE_LISTS } from "../actions/actions";

const initialState = {
  services: {},
  loading: false,
  error: null,
};

const serviceOpenList = createSlice({
  name: SERVICE_LISTS,
  initialState,
  reducers: {
    fetchServiceListsStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchServiceListsStatusDataSuccess(state, action) {
      state.loading = false;
      const { type, data } = action.payload;
      if (!state.services[type]) {
        state.services[type] = []; // Initialize if not present
      }
      state.services[type] = [...state.services[type], ...data.data]; // Append new data
    },
    fetchServiceListsStatusDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  fetchServiceListsStatusData,
  fetchServiceListsStatusDataSuccess,
  fetchServiceListsStatusDataFailure,
} = serviceOpenList.actions;

export default serviceOpenList.reducer;
