const FetchImage = () => {
  return <div>FetchImage</div>;
};

export default FetchImage;
