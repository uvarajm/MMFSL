import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setGeoLocation } from "../../store/slices/geoLocationSlice";

const MyLocation = () => {
  const dispatch = useDispatch();

  /**
   * getting geo coords of user
   * latitude
   * longitude
   */

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        dispatch(
          setGeoLocation({
            latitude,
            longitude,
          }),
        );
      });
    } else {
      console.log("Geolocation is not available in your browser.");
    }
  }, [dispatch]);

  return <></>;
};

export default MyLocation;
