import PropTypes from "prop-types";
import moment from "moment/moment";
import checkCircleIcon from "../Common/CheckIconApplication";
import {
  applicationStatus as status,
  INPROGRESS_PRODUCT_CONSTANTS,
  DDMMMYYYY,
} from "../../const/common";

const LoanStatus = (props) => {
  const {
    applicationNumber,
    applicationStatus,
    loanType,
    offer = false,
    businessExecutiveContactNumber,
    subStatus,
    currentDate,
    errorCode,
  } = props.details;
  return (
    <>
      <div className="w-full lg:w-2/4 lg:p-4 pb-3">
        <div className="rounded-lg bg-white p-4 ">
          <div
            className={`flex border-b pb-2 border-light-border-color dark:border-dark-border-color`}
          >
            {props.details.assetName ? (
              <svg
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="40" height="40" rx="8" fill="#EDE0E3" />
                <mask
                  id="mask0_1999_51072"
                  style={{ maskType: "alpha" }}
                  maskUnits="userSpaceOnUse"
                  x="4"
                  y="5"
                  width="32"
                  height="32"
                >
                  <rect
                    x="4"
                    y="5"
                    width="32"
                    height="31.9024"
                    fill="#D9D9D9"
                  />
                </mask>
                <g mask="url(#mask0_1999_51072)"></g>
                <path
                  d="M11.8203 27.6778V28.8868C11.8203 29.2637 11.6831 29.5841 11.4086 29.8479C11.1341 30.1117 10.8007 30.2437 10.4086 30.2437C10.0165 30.2437 9.68363 30.1117 9.41014 29.8479C9.13663 29.5841 8.99988 29.2637 8.99988 28.8868V19.8373C8.99988 19.7041 9.00886 19.5708 9.02681 19.4376C9.04477 19.3044 9.07497 19.1768 9.11741 19.0548L11.505 12.5592C11.6648 12.0972 11.9544 11.7219 12.3738 11.4331C12.7933 11.1444 13.2626 11 13.7819 11H26.8844C27.4037 11 27.8731 11.1444 28.2925 11.4331C28.712 11.7219 29.0016 12.0972 29.1613 12.5592L31.5489 19.0548C31.5914 19.1768 31.6216 19.3044 31.6395 19.4376C31.6575 19.5708 31.6665 19.7041 31.6665 19.8373V28.8868C31.6665 29.2637 31.5292 29.5841 31.2547 29.8479C30.9802 30.1117 30.6469 30.2437 30.2547 30.2437C29.8626 30.2437 29.5298 30.1117 29.2563 29.8479C28.9828 29.5841 28.846 29.2637 28.846 28.8868V27.6778H11.8203ZM11.8101 17.5133H28.8563L27.2768 13.1834C27.2426 13.1012 27.1913 13.0374 27.1229 12.9922C27.0545 12.947 26.9733 12.9243 26.8793 12.9243H13.787C13.693 12.9243 13.6118 12.947 13.5434 12.9922C13.4751 13.0374 13.4238 13.1012 13.3896 13.1834L11.8101 17.5133ZM14.2849 24.2732C14.7701 24.2732 15.1814 24.1098 15.519 23.783C15.8567 23.4563 16.0255 23.0595 16.0255 22.5926C16.0255 22.1258 15.8557 21.73 15.516 21.4052C15.1764 21.0803 14.764 20.9179 14.2789 20.9179C13.7937 20.9179 13.3823 21.0813 13.0447 21.4081C12.7071 21.7348 12.5383 22.1316 12.5383 22.5985C12.5383 23.0653 12.7081 23.4611 13.0477 23.786C13.3874 24.1108 13.7998 24.2732 14.2849 24.2732ZM26.3875 24.2732C26.8726 24.2732 27.284 24.1098 27.6216 23.783C27.9592 23.4563 28.128 23.0595 28.128 22.5926C28.128 22.1258 27.9582 21.73 27.6186 21.4052C27.279 21.0803 26.8666 20.9179 26.3814 20.9179C25.8963 20.9179 25.4849 21.0813 25.1473 21.4081C24.8097 21.7348 24.6409 22.1316 24.6409 22.5985C24.6409 23.0653 24.8107 23.4611 25.1503 23.786C25.4899 24.1108 25.9023 24.2732 26.3875 24.2732ZM10.9998 25.7535H29.6665V19.4376H10.9998V25.7535Z"
                  fill="#691A1E"
                />
              </svg>
            ) : (
              <svg
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="40" height="40" rx="8" fill="#EDE0E3" />
                <mask
                  id="mask0_1_81125"
                  style={{ maskType: "alpha" }}
                  maskUnits="userSpaceOnUse"
                  x="4"
                  y="5"
                  width="32"
                  height="32"
                >
                  <rect
                    x="4"
                    y="5"
                    width="32"
                    height="31.9024"
                    fill="#D9D9D9"
                  />
                </mask>
                <g mask="url(#mask0_1_81125)"></g>
                <mask
                  id="mask1_1_81125"
                  style={{ maskType: "alpha" }}
                  maskUnits="userSpaceOnUse"
                  x="4"
                  y="5"
                  width="32"
                  height="32"
                >
                  <rect x="4" y="5" width="32" height="32" fill="#D9D9D9" />
                </mask>
                <g mask="url(#mask1_1_81125)">
                  <path
                    d="M22.4977 32.4692C22.5404 32.4863 22.5789 32.4949 22.6131 32.4949C22.6472 32.4949 22.6857 32.4863 22.7284 32.4692L30.572 30.041C30.5037 29.7385 30.3626 29.5064 30.1489 29.3448C29.9351 29.1833 29.6933 29.1025 29.4233 29.1025H22.8936C22.3117 29.1025 21.8173 29.0803 21.4105 29.0359C21.0037 28.9914 20.5857 28.894 20.1567 28.7436L18.0643 28.0589C17.7954 27.9735 17.6021 27.8025 17.4844 27.5461C17.3668 27.2897 17.3507 27.0286 17.4361 26.7628C17.5216 26.497 17.687 26.3022 17.9323 26.1782C18.1776 26.0543 18.4353 26.0351 18.7053 26.1205L20.4387 26.7282C20.8421 26.8564 21.2934 26.9475 21.7925 27.0013C22.2917 27.0552 22.9386 27.0889 23.7334 27.1026H24.09C24.09 26.7727 24.0156 26.4881 23.8669 26.2487C23.7182 26.0094 23.5225 25.8479 23.2797 25.7641L15.5438 22.9231C15.5182 22.9146 15.4947 22.9081 15.4733 22.9039C15.4519 22.8996 15.4284 22.8974 15.4028 22.8974H12.9361V29.7692L22.4977 32.4692ZM21.9772 34.4281L12.9361 31.8358C12.784 32.388 12.4746 32.8311 12.0079 33.1653C11.5412 33.4995 11.0472 33.6666 10.5259 33.6666H8.67976C8.01694 33.6666 7.44953 33.4306 6.97753 32.9586C6.50553 32.4866 6.26953 31.9192 6.26953 31.2563V23.3077C6.26953 22.6449 6.50553 22.0775 6.97753 21.6055C7.44953 21.1335 8.01694 20.8975 8.67976 20.8975H15.388C15.5278 20.8975 15.6695 20.9129 15.813 20.9436C15.9566 20.9744 16.09 21.0103 16.213 21.0513L23.9823 23.9129C24.5874 24.1368 25.0899 24.533 25.4899 25.1013C25.8899 25.6697 26.0899 26.3368 26.0899 27.1026H29.4233C30.3806 27.1026 31.1605 27.4116 31.763 28.0295C32.3656 28.6474 32.6669 29.4496 32.6669 30.4359C32.6669 30.8137 32.5669 31.1179 32.3669 31.3487C32.1669 31.5795 31.8643 31.7624 31.4592 31.8974L23.3695 34.4076C23.1507 34.4794 22.9208 34.5175 22.6797 34.5217C22.4387 34.526 22.2045 34.4948 21.9772 34.4281ZM8.2695 31.2563C8.2695 31.376 8.30795 31.4743 8.38486 31.5512C8.4618 31.6282 8.5601 31.6666 8.67976 31.6666H10.5259C10.6455 31.6666 10.7438 31.6346 10.8208 31.5705C10.8977 31.5064 10.9362 31.4017 10.9362 31.2563V22.8974H8.67976C8.5601 22.8974 8.4618 22.9359 8.38486 23.0128C8.30795 23.0898 8.2695 23.1881 8.2695 23.3077V31.2563Z"
                    fill="#691A1E"
                  />
                  <mask
                    id="mask2_1_81125"
                    style={{ maskType: "alpha" }}
                    maskUnits="userSpaceOnUse"
                    x="17"
                    y="6"
                    width="17"
                    height="17"
                  >
                    <rect
                      x="17.333"
                      y="6.33334"
                      width="16"
                      height="16"
                      fill="#D9D9D9"
                    />
                  </mask>
                  <g mask="url(#mask2_1_81125)">
                    <path
                      d="M26.283 20.1334L22.183 15.8668C22.1275 15.8112 22.083 15.7418 22.0497 15.6584C22.0163 15.5751 21.9997 15.489 21.9997 15.4001V15.0001C21.9997 14.8112 22.0636 14.6529 22.1913 14.5251C22.3191 14.3973 22.4775 14.3334 22.6663 14.3334H24.333C24.9219 14.3334 25.4302 14.1418 25.858 13.7584C26.2858 13.3751 26.5441 12.9001 26.633 12.3334H21.9997C21.8108 12.3334 21.6525 12.2695 21.5247 12.1418C21.3969 12.014 21.333 11.8557 21.333 11.6668C21.333 11.4779 21.3969 11.3195 21.5247 11.1918C21.6525 11.064 21.8108 11.0001 21.9997 11.0001H26.433C26.2441 10.6112 25.9636 10.2918 25.5913 10.0418C25.2191 9.79177 24.7997 9.66677 24.333 9.66677H21.9997C21.8108 9.66677 21.6525 9.60288 21.5247 9.4751C21.3969 9.34732 21.333 9.18899 21.333 9.0001C21.333 8.81121 21.3969 8.65288 21.5247 8.5251C21.6525 8.39732 21.8108 8.33344 21.9997 8.33344H28.6663C28.8552 8.33344 29.0136 8.39732 29.1413 8.5251C29.2691 8.65288 29.333 8.81121 29.333 9.0001C29.333 9.18899 29.2691 9.34732 29.1413 9.4751C29.0136 9.60288 28.8552 9.66677 28.6663 9.66677H27.1663C27.3219 9.85566 27.4608 10.0612 27.583 10.2834C27.7052 10.5057 27.7997 10.7445 27.8663 11.0001H28.6663C28.8552 11.0001 29.0136 11.064 29.1413 11.1918C29.2691 11.3195 29.333 11.4779 29.333 11.6668C29.333 11.8557 29.2691 12.014 29.1413 12.1418C29.0136 12.2695 28.8552 12.3334 28.6663 12.3334H27.983C27.8941 13.2779 27.5052 14.0695 26.8163 14.7084C26.1275 15.3473 25.2997 15.6668 24.333 15.6668H23.8497L27.2497 19.2001C27.4497 19.4112 27.4913 19.6529 27.3747 19.9251C27.258 20.1973 27.0552 20.3334 26.7663 20.3334C26.6775 20.3334 26.5913 20.3168 26.508 20.2834C26.4247 20.2501 26.3497 20.2001 26.283 20.1334Z"
                      fill="#691A1E"
                    />
                  </g>
                </g>
              </svg>
            )}

            <div
              className={`flex flex-col pl-4 w-full  text-light-text-primary`}
            >
              <div className="flex justify-between items-center">
                {loanType ? (
                  <p className={`label label_md label_primary-dark`}>
                    {loanType}
                  </p>
                ) : (
                  ""
                )}
                {offer ? (
                  <p
                    className={`text-[11px] text-grey-500 p-[2px] lg:p-1 bg-light-border-color dark:bg-dark-border-color`}
                  >
                    {INPROGRESS_PRODUCT_CONSTANTS.PROCESS_TEXT}
                  </p>
                ) : (
                  ""
                )}
              </div>
              <p className="label label_lg label_primary-dark">
                {INPROGRESS_PRODUCT_CONSTANTS.APPLICATION_ID_PREFIX}
                {!errorCode ? applicationNumber : "InActive"}
              </p>
            </div>
          </div>
          <div className="flex justify-between flex-wrap mt-2">
            <div className="w-2/4  py-2">
              <div className="label label_md label_primary-dark">
                {INPROGRESS_PRODUCT_CONSTANTS.KEY_LABEL_MAP.applicantName}
              </div>
              <div className="content content_md content_secondary_dark">
                {props.details.applicantName}
              </div>
            </div>
            <div className="w-2/4 py-2">
              <div className="label label_md label_primary-dark">
                {INPROGRESS_PRODUCT_CONSTANTS.KEY_LABEL_MAP.applicationDate}
              </div>
              <div className="content content_md content_secondary_dark">
                {props.details.applicationDate}
              </div>
            </div>
            {props.details.assetName && (
              <div className="w-2/4 py-2">
                <div className="label label_md label_primary-dark">
                  {INPROGRESS_PRODUCT_CONSTANTS.KEY_LABEL_MAP.assetName}
                </div>
                <div className="content content_md content_secondary_dark">
                  {props.details.assetName}
                </div>
              </div>
            )}
            {props.details.branchName && (
              <div className="w-2/4 py-2">
                <div className="label label_md label_primary-dark">
                  {INPROGRESS_PRODUCT_CONSTANTS.KEY_LABEL_MAP.branchName}
                </div>
                <div className="content content_md content_secondary_dark">
                  {props.details.branchName}
                </div>
              </div>
            )}
          </div>
          <div className={`mt-2 mb-4 label label_md label_primary-dark`}>
            {INPROGRESS_PRODUCT_CONSTANTS.APPLICATION_STATUS_TEXT}{" "}
            {moment(currentDate).format(DDMMMYYYY)}
          </div>
          {!errorCode && (
            <>
              {" "}
              {applicationStatus !== undefined
                ? checkCircleIcon(applicationStatus.toLowerCase())
                : null}
              <div className="mt-[-10px] flex flex-col py-4 w-full">
                <div className="flex items-center w-full justify-between">
                  {Object.entries(status).map(([key, value]) => (
                    <div
                      key={key}
                      className={`text-[10px] ${
                        applicationStatus === value ? "font-bold" : ""
                      }`}
                    >
                      {value}
                    </div>
                  ))}
                </div>
                <div className="w-full"></div>
              </div>
              {subStatus == "Documents awaited" ? (
                <div
                  className={`bg-light-border-color dark:bg-dark-border-color rounded-lg flex p-2 font-karla text-[11px] relative`}
                >
                  <div className="arrow absolute left-[62px] lg:left-[22%] top-[-12px]">
                    <svg
                      width="19"
                      height="14"
                      viewBox="0 0 19 14"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <g filter="url(#filter0_d_1_81253)">
                        <path
                          d="M9.07277 3L2.58496 13H16.024L9.07277 3Z"
                          fill="#EDE0E3"
                        />
                      </g>
                      <defs>
                        <filter
                          id="filter0_d_1_81253"
                          x="0.584961"
                          y="0"
                          width="17.4395"
                          height="14"
                          filterUnits="userSpaceOnUse"
                          colorInterpolationFilters="sRGB"
                        >
                          <feFlood
                            floodOpacity="0"
                            result="BackgroundImageFix"
                          />
                          <feColorMatrix
                            in="SourceAlpha"
                            type="matrix"
                            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                            result="hardAlpha"
                          />
                          <feOffset dy="-1" />
                          <feGaussianBlur stdDeviation="1" />
                          <feComposite in2="hardAlpha" operator="out" />
                          <feColorMatrix
                            type="matrix"
                            values="0 0 0 0 0.729412 0 0 0 0 0.560784 0 0 0 0 0.580392 0 0 0 0.2 0"
                          />
                          <feBlend
                            mode="normal"
                            in2="BackgroundImageFix"
                            result="effect1_dropShadow_1_81253"
                          />
                          <feBlend
                            mode="normal"
                            in="SourceGraphic"
                            in2="effect1_dropShadow_1_81253"
                            result="shape"
                          />
                        </filter>
                      </defs>
                    </svg>
                  </div>
                  <svg
                    className="mr-2"
                    width="15"
                    height="16"
                    viewBox="0 0 13 14"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M6.5182 10.1538C6.66157 10.1538 6.78175 10.1022 6.87874 9.99904C6.97572 9.89583 7.02421 9.76794 7.02421 9.61539C7.02421 9.46282 6.97572 9.33494 6.87874 9.23174C6.78175 9.12854 6.66157 9.07694 6.5182 9.07694C6.37482 9.07694 6.25464 9.12854 6.15766 9.23174C6.06068 9.33494 6.01219 9.46282 6.01219 9.61539C6.01219 9.76794 6.06068 9.89583 6.15766 9.99904C6.25464 10.1022 6.37482 10.1538 6.5182 10.1538ZM6.5184 7.71795C6.6516 7.71795 6.76317 7.67004 6.85313 7.5742C6.94308 7.47838 6.98806 7.35964 6.98806 7.21797V4.21794C6.98806 4.07628 6.94302 3.95754 6.85293 3.8617C6.76282 3.76587 6.65118 3.71795 6.51799 3.71795C6.3848 3.71795 6.27322 3.76587 6.18327 3.8617C6.09331 3.95754 6.04833 4.07628 6.04833 4.21794V7.21797C6.04833 7.35964 6.09338 7.47838 6.18347 7.5742C6.27357 7.67004 6.38522 7.71795 6.5184 7.71795ZM6.51925 13.3333C5.69606 13.3333 4.9223 13.1671 4.19798 12.8347C3.47364 12.5022 2.84358 12.051 2.30778 11.4812C1.77197 10.9113 1.34779 10.2411 1.03524 9.47067C0.722683 8.70026 0.566406 7.87708 0.566406 7.00112C0.566406 6.12516 0.722615 5.30181 1.03503 4.53105C1.34745 3.76029 1.77144 3.08983 2.307 2.51969C2.84257 1.94953 3.47236 1.49816 4.19637 1.16557C4.92037 0.832982 5.69396 0.666687 6.51715 0.666687C7.34034 0.666687 8.11409 0.83291 8.83842 1.16535C9.56275 1.4978 10.1928 1.94896 10.7286 2.51885C11.2644 3.08875 11.6886 3.75892 12.0012 4.52934C12.3137 5.29975 12.47 6.12293 12.47 6.99889C12.47 7.87484 12.3138 8.6982 12.0014 9.46895C11.6889 10.2397 11.265 10.9102 10.7294 11.4803C10.1938 12.0505 9.56404 12.5018 8.84003 12.8344C8.11603 13.167 7.34243 13.3333 6.51925 13.3333ZM6.5182 12.3333C7.9174 12.3333 9.10254 11.8167 10.0736 10.7833C11.0447 9.75 11.5302 8.48889 11.5302 7C11.5302 5.51112 11.0447 4.25 10.0736 3.21667C9.10254 2.18334 7.9174 1.66667 6.5182 1.66667C5.119 1.66667 3.93386 2.18334 2.96278 3.21667C1.99169 4.25 1.50615 5.51112 1.50615 7C1.50615 8.48889 1.99169 9.75 2.96278 10.7833C3.93386 11.8167 5.119 12.3333 6.5182 12.3333Z"
                      fill="#E68600"
                    />
                  </svg>
                  {INPROGRESS_PRODUCT_CONSTANTS.DOCUMENT_ERROR_MSG}
                </div>
              ) : (
                ""
              )}
              {businessExecutiveContactNumber ? (
                <div className="flex justify-between mt-4 text-xs font-semibold">
                  <p className={`label label_md label_primary-dark flex`}>
                    <svg
                      className="mr-2"
                      width="16"
                      height="16"
                      viewBox="0 0 16 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <mask
                        id="mask0_1_81180"
                        style={{ maskType: "alpha" }}
                        maskUnits="userSpaceOnUse"
                        x="0"
                        y="0"
                        width="16"
                        height="16"
                      >
                        <rect width="16" height="16" fill="#D9D9D9" />
                      </mask>
                      <g mask="url(#mask0_1_81180)">
                        <path
                          d="M6.50031 9.56409C6.38579 9.56409 6.29091 9.52648 6.21569 9.45127C6.14048 9.37605 6.10288 9.28117 6.10288 9.16665C6.10288 9.05213 6.14048 8.95726 6.21569 8.88203C6.29091 8.80682 6.38579 8.76922 6.50031 8.76922H9.50031C9.61483 8.76922 9.7097 8.80682 9.78493 8.88203C9.86014 8.95726 9.89774 9.05213 9.89774 9.16665C9.89774 9.28117 9.86014 9.37605 9.78493 9.45127C9.7097 9.52648 9.61483 9.56409 9.50031 9.56409H6.50031ZM5.83364 7.56408C5.71912 7.56408 5.62425 7.52648 5.54903 7.45127C5.47381 7.37605 5.43621 7.28117 5.43621 7.16665C5.43621 7.05213 5.47381 6.95726 5.54903 6.88203C5.62425 6.80682 5.71912 6.76922 5.83364 6.76922H10.167C10.2815 6.76922 10.3764 6.80682 10.4516 6.88203C10.5268 6.95726 10.5644 7.05213 10.5644 7.16665C10.5644 7.28117 10.5268 7.37605 10.4516 7.45127C10.3764 7.52648 10.2815 7.56408 10.167 7.56408H5.83364ZM4.87213 15C4.53537 15 4.25033 14.8833 4.01699 14.65C3.78366 14.4166 3.66699 14.1316 3.66699 13.7948V2.20513C3.66699 1.86838 3.78366 1.58333 4.01699 1.35C4.25033 1.11667 4.53537 1 4.87213 1H11.1285C11.4652 1 11.7503 1.11667 11.9836 1.35C12.217 1.58333 12.3336 1.86838 12.3336 2.20513V13.7948C12.3336 14.1316 12.217 14.4166 11.9836 14.65C11.7503 14.8833 11.4652 15 11.1285 15L4.87213 15ZM4.66698 13.1667V13.7949C4.66698 13.8461 4.68834 13.8932 4.73108 13.9359C4.77382 13.9786 4.82084 14 4.87213 14H11.1285C11.1798 14 11.2268 13.9786 11.2695 13.9359C11.3123 13.8932 11.3336 13.8461 11.3336 13.7949V13.1667H4.66698ZM4.66698 12.1667H11.3336V3.83332H4.66698V12.1667ZM4.66698 2.83335H11.3336V2.20515C11.3336 2.15386 11.3123 2.10684 11.2695 2.0641C11.2268 2.02137 11.1798 2 11.1285 2H4.87213C4.82084 2 4.77382 2.02137 4.73108 2.0641C4.68834 2.10684 4.66698 2.15386 4.66698 2.20515V2.83335Z"
                          fill="#691A1E"
                        />
                      </g>
                    </svg>
                    {INPROGRESS_PRODUCT_CONSTANTS.BUSINESS_EXEC}
                  </p>
                  <p className="label label_md label_primary-dark-red">
                    {businessExecutiveContactNumber}
                  </p>
                </div>
              ) : (
                ""
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

LoanStatus.propTypes = {
  applicationNumber: PropTypes.string,
  applicationStatus: PropTypes.string,
  loanType: PropTypes.string,
  offer: PropTypes.bool,
  businessExecutiveContactNumber: PropTypes.string,
  subStatus: PropTypes.string,
  currentDate: PropTypes.string,
  errorCode: PropTypes.string,
  details: PropTypes.object,
};

export default LoanStatus;
