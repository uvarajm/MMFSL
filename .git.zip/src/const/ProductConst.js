export const PRODUCT_FAQ = {
  PAGE_TITLE: "FAQS",
  PRODUCT_TABS: ["Products", "General", "How to"],
};
export const FAQ_TYPE = "how_to";
export const FAQ_TYPE_URL = "how-to";

export const [PRODUCTS, GENERAL, HOW_TO] = PRODUCT_FAQ.PRODUCT_TABS;
