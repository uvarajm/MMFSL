import DOMPurify from "dompurify";
import PropTypes from "prop-types";
import Disclaimer from "./Disclaimer";

const Eligibility = ({ title, details }) => {
  const { documents, description, disclaimer = "" } = details;
  const sanitizer = DOMPurify.sanitize;
  return (
    <section className="text-wrap space-y-4">
      <div className="title title_xl title_primary">{title}</div>

      <div className="bg-white rounded p-2 lg:p-4">
        <p className="primary-description mb-6">{description}</p>

        <div className="flex max-sm:flex-col flex-wrap lg:-mx-4">
          {documents?.map((document, index) => (
            <div
              key={index}
              className="w-1/3 space-y-1 lg:py-1 border-b lg:border-b-0 lg:border-r label label_lg label_primary-dark border-lilac-light last:border-0 lg:px-4 py-2"
            >
              <p className="label label_lg label_primary-dark">
                {document?.title}
              </p>
              <p
                className="primary-description"
                dangerouslySetInnerHTML={{
                  __html: sanitizer(document?.description),
                }}
              ></p>
            </div>
          ))}
        </div>
      </div>
      {disclaimer !== "" ? <Disclaimer text={disclaimer} /> : ""}
    </section>
  );
};

Eligibility.propTypes = {
  title: PropTypes.string,
  details: PropTypes.shape({
    documents: PropTypes.arrayOf(
      PropTypes.shape({
        title: PropTypes.string.isRequired,
        description: PropTypes.string.isRequired,
      }),
    ),
    description: PropTypes.string.isRequired,
    disclaimer: PropTypes.string,
  }),
};

export default Eligibility;
