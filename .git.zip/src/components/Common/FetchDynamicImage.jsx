import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { makeApiRequest } from "../../utils/apiUtils";
import { PRODUCT_TYPE_IMAGE_MAPPING, CMS_TOKEN } from "../../const/common";
import iconConfig from "../../assets/iconsConfig";
import SvgIcon from "./SvgIcon";

const arrayBufferToBase64 = (arrayBuffer) => {
  return btoa(
    new Uint8Array(arrayBuffer).reduce(
      (data, byte) => data + String.fromCharCode(byte),
      "",
    ),
  );
};

const FetchDynamicImage = ({ src, alt, customClasses = "", imageType }) => {
  const [imageSrc, setImageSrc] = useState("");
  const [iconPath, setIconPath] = useState();

  useEffect(() => {
    let isMounted = true;
    if (imageType === "icons") {
      setIconPath(iconConfig[src]);
    } else {
      if (src !== "") {
        makeApiRequest(src, CMS_TOKEN, "GET", null, "arraybuffer")
          .then((response) => {
            const base64String = arrayBufferToBase64(response.data);
            if (isMounted) {
              setImageSrc(`data:image/png;base64,${base64String}`);
            }
          })
          .catch((error) => console.error("Error fetching image:", error));
      }
    }

    return () => {
      isMounted = false;
    };
  }, [src, alt]);

  const finalSrc = imageSrc || PRODUCT_TYPE_IMAGE_MAPPING[alt] || "";

  return (
    <div className="flex flex-shrink-0">
      {imageType === "icons" ? (
        <SvgIcon url={iconPath} />
      ) : (
        <img className={customClasses} src={finalSrc} alt={alt} />
      )}
    </div>
  );
};

FetchDynamicImage.propTypes = {
  src: PropTypes.string,
  alt: PropTypes.string,
  imageType: PropTypes.string,
  customClasses: PropTypes.string,
};

export default FetchDynamicImage;
