import { createSlice } from "@reduxjs/toolkit";
import { GET_TERM_AND_CONDITION } from "../actions/actions";
const initialState = {
  termAndConditionPageContent: [],
  loading: false,
  error: null,
};

const tearmAndConditionPageSlice = createSlice({
  name: GET_TERM_AND_CONDITION,
  initialState,
  reducers: {
    fetchtermAndConditionPageData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchtermAndConditionPageDataSuccess(state, { payload }) {
      state.loading = false;
      state.termAndConditionPageContent = payload;
    },
    fetchtermAndConditionPageDataFailure(state, { payload }) {
      state.loading = false;
      state.error = payload;
    },
  },
});

export const {
  fetchtermAndConditionPageData,
  fetchtermAndConditionPageDataSuccess,
  fetchtermAndConditionPageDataFailure,
} = tearmAndConditionPageSlice.actions;

export default tearmAndConditionPageSlice.reducer;
