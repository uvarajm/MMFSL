import PropTypes from "prop-types";

const Button = ({ name, type = "button", className, ...rest }) => {
  return (
    <button
      type={type}
      className={`w-full text-sm flex items-center justify-center rounded-[22px] p-3 disabled:bg-disable-red ${className}`}
      {...rest}
    >
      {name}
    </button>
  );
};

Button.propTypes = {
  name: PropTypes.string,
  type: PropTypes.string,
  className: PropTypes.string,
};

export default Button;
