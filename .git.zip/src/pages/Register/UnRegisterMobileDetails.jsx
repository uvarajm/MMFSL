import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { Input, Button } from "../../components";
import { Container } from "../../components";
import jsonData from "../Register/data.json";
import { useState, useEffect } from "react";
import { getForgotAction } from "../../pages/Register/registerSlice";
import { useDispatch } from "react-redux";
import { mobileNumberValidation } from "../../utils/validation";
import BackButton from "../../components/Common/BackButton";

function UnRegisterMobileDetails() {
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const [mobileData, setMobileData] = useState(null);
  // const register = useSelector((state) => state.register);

  const initialValues = {
    mobileNumber: "",
  };

  const validationSchema = Yup.object({
    mobileNumber: mobileNumberValidation("Enter mobile number"),
  });

  const onSubmit = (values, { setFieldError }) => {
    const mobileNumberString = values.mobileNumber.toString();
    const mobile = mobileData.find(
      (mobile) => mobile.mobnumber === mobileNumberString,
    );

    if (mobile) {
      dispatch(getForgotAction(true));
      navigate("/register/get-otp", {
        state: { mobileNumber: mobileNumberString },
      });
    } else {
      setFieldError("mobileNumber", "Mobile number is not registered");
    }
  };

  useEffect(() => {
    // Parse the JSON data and store it in the state
    setMobileData(jsonData.registermobdetails);
  }, []);

  return (
    <Container className="px-4">
      <div className="w-full minHeight flex justify-center items-center">
        <div className="flex flex-col justify-between w-[400px]">
          <div className="flex flex-col pb-4">
            <div className="flex items-center lg:block">
              <BackButton />
              <p className="lg:text-[32px] font-bold tracking-wide leading-10 font-quicksand text-xl lg:py-4">
                Enter Mobile Number
              </p>
            </div>
            <p className="font-karla text-sm leading-[18px] font-normal text-grey-500">
              Enter your registered mobile number to reset your password
            </p>
          </div>
          <div className="flex flex-col flex-1">
            <div className="flex-1">
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {(formik) => (
                  <Form className="flex flex-col">
                    <div className="relative">
                      <Input
                        type="number"
                        name="mobileNumber"
                        label="Mobile number"
                        inputClassName="px-3 pl-3"
                        placeholder="Mobile number"
                        formik={formik}
                      />
                      <div className="absolute left-0 top-[28px] text-grey-500 font-karla font-normal leading-[22px]">
                        +91
                      </div>
                    </div>
                    <div className="flex flex-col justify-center w-full pt-10 mt-32 lg:mt-0">
                      <Button
                        type="submit"
                        name="Continue"
                        disabled={!(formik.isValid && formik.dirty)}
                        className="hover:opacity-85 w-full rounded-lg font-bold leading-5 text-white bg-red-500 disabled:bg-disable-red disabled:text-lilac-dark"
                      />
                    </div>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </Container>
  );
}

export default UnRegisterMobileDetails;
