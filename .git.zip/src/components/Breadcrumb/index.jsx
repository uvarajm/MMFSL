import PropTypes from "prop-types";
import { Breadcrumbs } from "@mui/material";
import { Link, useLocation } from "react-router-dom";

const Breadcrumb = ({ className = "" }) => {
  const location = useLocation();
  const pathname = location.pathname.split("/").filter((item) => item);

  // Remove the last element from the pathname array
  const breadcrumbPath = pathname.slice(0, -1);

  return (
    <div className={`${className} pt-3`}>
      <Breadcrumbs aria-label="breadcrumb">
        <Link to="/" className="content content_lg content_primary">
          Home
        </Link>
        {breadcrumbPath.length > 0 &&
          breadcrumbPath.map((item, index) => (
            <Link
              to={`/${breadcrumbPath.slice(0, index + 1).join("/")}`}
              key={item}
              className="content content_lg content_primary"
            >
              {item
                .split(/[_-]/)
                .join(" ")
                .replace(/\b\w/g, (char) => char.toUpperCase())}
            </Link>
          ))}
      </Breadcrumbs>
    </div>
  );
};

Breadcrumb.propTypes = {
  className: PropTypes.string,
};

export default Breadcrumb;
