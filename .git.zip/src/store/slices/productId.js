import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  productIdDetails: {},
};

const productIdDetailsSlice = createSlice({
  name: "PRODUCT_ID_DETAILS",
  initialState,
  reducers: {
    setProductDetails: (state, action) => {
      state.productIdDetails = action.payload;
    },
  },
});

export const { setProductDetails } = productIdDetailsSlice.actions;

export default productIdDetailsSlice.reducer;
