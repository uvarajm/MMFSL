// inProgressProductsSlice.js
import { createSlice } from "@reduxjs/toolkit";
import { IN_PROGRESS_PRODUCTS } from "../actions/actions";

const initialState = {
  progressData: {},
  loading: false,
  error: null,
};

const inProgressProducts = createSlice({
  name: IN_PROGRESS_PRODUCTS,
  initialState,
  reducers: {
    fetchInProgressProductsStatusData(state) {
      state.loading = true;
      state.error = null;
    },
    fetchInProgressProductsDataSuccess(state, action) {
      state.loading = false;
      state.progressData = action.payload;
    },
    fetchInProgressProductsDataFailure(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
  },
});
export const {
  fetchInProgressProductsStatusData,
  fetchInProgressProductsDataSuccess,
  fetchInProgressProductsDataFailure,
} = inProgressProducts.actions;
export default inProgressProducts.reducer;
