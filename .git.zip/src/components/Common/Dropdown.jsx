import PropTypes from "prop-types";
import { useState, useRef, useEffect } from "react";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

const Dropdown = ({ options, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleOptionClick = (option) => {
    setSelectedOption(option);
    setIsOpen(false);
    onSelect(option);
  };

  return (
    <div className="relative inline-block w-[127px]" ref={dropdownRef}>
      <div
        className="p-2 border rounded bg-light-border-color cursor-pointer flex justify-between items-center text-sm"
        onClick={() => setIsOpen(!isOpen)}
      >
        {selectedOption ? selectedOption.label : "All Products"}
        <span
          className={`ml-2 transform ${isOpen ? "rotate-180" : "rotate-0"}`}
        >
          <KeyboardArrowDownIcon className="text-red-800" />
        </span>
      </div>
      {isOpen && (
        <ul className="absolute w-full mt-1 border  rounded bg-light-border-color max-h-60 overflow-y-auto z-10">
          {options.map((option) => (
            <li
              key={option.value}
              className="p-2 hover:bg-dark-border-color cursor-pointer text-sm"
              onClick={() => handleOptionClick(option)}
            >
              {option.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

Dropdown.propTypes = {
  options: PropTypes.array.isRequired,
  onSelect: PropTypes.func.isRequired,
};

export default Dropdown;
