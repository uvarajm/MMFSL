import PropTypes from "prop-types";

const CircularProgressBar = ({ progress, color, trackColor }) => {
  const sizeClasses = "w-28 h-28 md:w-48 md:h-48 ";
  const strokeWidth = window.innerWidth <= 768 ? 17 : 20;
  const size = window.innerWidth <= 768 ? 120 : 192;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;
  return (
    <svg
      className={`block mx-auto ${sizeClasses}`}
      viewBox={`0 0 ${size} ${size}`}
    >
      <circle
        className="text-gray-200"
        stroke={trackColor}
        strokeWidth={strokeWidth}
        fill="transparent"
        r={radius}
        style={{ strokeLinecap: "round" }}
        cx={size / 2}
        cy={size / 2}
      />
      <circle
        className="transition-all duration-300 ease-out"
        stroke={color}
        strokeWidth={strokeWidth}
        fill="transparent"
        r={radius}
        cx={size / 2}
        cy={size / 2}
        strokeDasharray={circumference}
        style={{ strokeLinecap: "round" }}
        strokeDashoffset={offset}
      />
      <text
        x="50%"
        y="50%"
        textAnchor="middle"
        dy=".3em"
        className="text-lg font-semibold text-gray-800"
      ></text>
    </svg>
  );
};

CircularProgressBar.propTypes = {
  progress: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  color: PropTypes.string,
  trackColor: PropTypes.string,
};

export default CircularProgressBar;
