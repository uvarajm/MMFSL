const SearchLoader = () => {
  return (
    <div className="flex justify-center">
      <div className="loader"></div>
    </div>
  );
};

export default SearchLoader;
