import Icon from "../../assets/Icon";
import { Button, Container } from "../../components";

const RegistrationFailed = () => {
  return (
    <Container className="px-4">
      <div className="w-full max-w-md minHeight flex justify-center items-center">
        <div className="flex flex-col justify-between gap-4 p-0">
          <Icon
            name={"Info"}
            size={44.33}
            className="fill-red-500 cursor-pointer"
          />
          <p className="text-[32px] font-medium text-red-800 font-quicksand leading-10">
            Registration has failed.
          </p>
          <div className="bg-white gap-2 rounded-lg">
            <p className="font-normal font-karla text-base p-3 text-grey-500 leading-[22px]">
              Please try again in 20 mins or visit a{" "}
              <span className="text-red-500 font-karla">nearby branch</span> for
              help.
            </p>
          </div>
          <p className="font-karla text-xs text-grey-500 font-normal max-sm:text-center">
            Redirecting
          </p>

          <div className="fixed bottom-12 left-0 right-0 max-lg:p-5 flex items-center justify-center lg:static lg:flex lg:items-end lg:pb-2">
            <Button
              name="Retry"
              className="bg-red-500 text-white rounded-lg w-full font-bold font-quicksand text-sm"
            />
          </div>
        </div>
      </div>
    </Container>
  );
};

export default RegistrationFailed;
