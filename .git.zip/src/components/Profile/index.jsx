import React from "react";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Divider from "@mui/material/Divider";
import { Box, IconButton } from "@mui/material";
import { profileItems } from "../../utils/utils";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const Profile = () => {
  const [userSettingProfile, setUserSettingProfile] = React.useState(null);
  const open = Boolean(userSettingProfile);
  const handleClick = (event) => {
    setUserSettingProfile(event.currentTarget);
  };

  const getInitials = (fullName) => {
    // Split the full name by spaces
    let nameParts = fullName.split(" ");
    // Get the first letter of the first and last name
    let initials = nameParts.map((part) => part.charAt(0)).join("");
    return initials.toUpperCase();
  };
  const { name } = useSelector((state) => state.login);

  let initials = getInitials(name);
  const handleClose = () => {
    setUserSettingProfile(null);
  };
  return (
    <>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          textAlign: "center",
          "& > button:hover": {
            background: "transparent",
          },
        }}
      >
        <IconButton
          onClick={handleClick}
          size="small"
          sx={{ ml: 2 }}
          aria-controls={open ? "account-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
          className="!ml-0"
        >
          <div className="h-[24px] w-[24px] rounded-full label label_md dark:bg-white label_primary-contrast-lilac  text-sm bg-red-800 flex justify-center items-center">
            {initials}
          </div>
        </IconButton>
      </Box>
      <Menu
        anchorEl={userSettingProfile}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&::before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "center", vertical: "top" }}
        anchorOrigin={{ horizontal: "center", vertical: "bottom" }}
      >
        {profileItems.map((profileItem, index) => (
          <div key={index}>
            <MenuItem>
              <Link to={profileItem.itemLink} className="">
                {profileItem.item}
              </Link>
            </MenuItem>
            {index < profileItems.length - 1 && <Divider />}
          </div>
        ))}
      </Menu>
    </>
  );
};
export default Profile;
