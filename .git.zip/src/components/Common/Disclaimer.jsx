import PropTypes from "prop-types";
import SvgIcon from "./SvgIcon";
import iconConfig from "../../assets/iconsConfig";
const Disclaimer = ({ text = "" }) => {
  const { Warning } = iconConfig;
  return (
    <div className="p-2 lg:p-4 flex lg:items-center">
      <SvgIcon url={Warning} colorClass={"fill-yellow-100"} />
      <p className="pl-4 content content_lg content_secondary">
        Disclaimer: {text}
      </p>
    </div>
  );
};

export default Disclaimer;

Disclaimer.propTypes = {
  text: PropTypes.string,
};
