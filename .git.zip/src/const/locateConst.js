export const CASH_COLLECTION_POINTS = {
  MAIN_PAGE_TITLE: "Locate us",
  PAGE_TITLE: "You can pay at any of the following centres",
  PAYMENT_FINO_TITLE: "Fino Payments Bank (Fino)",
  PAYMENT_CSC_TITLE:
    "Common Services Center e-Governance Services India Limited (CSC)",
  PAYMENT_POST_OFFICE_TITLE: "India Post Payments Bank (Post office)",
  PAYMENT_FINO_LINK: "https://web4.finobank.com/contact-us#parentHorizontalTab",
  PAYMENT_CSC_LINK: "https://locator.csccloud.in/",
  PAYMENT_POST_OFFICE_LINK:
    "https://www.indiapost.gov.in/VAS/Pages/LocatePostOffices.aspx?Pin=pLIcI+wd8lo=",
  OPEN_CLOSE_TIMING: "km away • Open • Closes at 6:00pm",
  GET_DIRECTIONS: "Get directions",
  TOLL_FREE_NUMBER: "1800 233 1234",
  CONNECT_US: "Connect with us at our toll-free number",
  TIMING_WEEK: "Monday - Sunday, 8 a.m. to 10 p.m. (except national holidays)",
  MAP_DOMAIN: "https://www.google.com/maps/place/",
  BRANCHES_NEAR_YOU: "branches near you",
};
