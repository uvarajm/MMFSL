import { Container, Button } from "../../components";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import BackButton from "../../components/Common/BackButton";
import { REGISTRATION } from "../../const/common";

const PanLoanRegDetails = () => {
  const navigate = useNavigate();
  const [isPan, setIsPan] = useState(false);
  const [isLoan, setIsLoan] = useState(false);
  const panClick = () => {
    setIsPan(true);
    setIsLoan(false);
  };
  const loanClick = () => {
    setIsLoan(true);
    setIsPan(false);
  };
  const continueClick = () => {
    if (isPan) {
      navigate("/register/pan-details");
    } else if (isLoan) {
      navigate("/register/loan-details");
    }
  };
  return (
    <Container>
      <div className="relative w-full max-w-md mx-auto flex flex-col p-4">
        <div className="mt-5 mb-[36px]">
          <div className="flex lg:block">
            <BackButton />
            <div className="headline headline_xl heading-primary w-176px h-72px lg:mt-7 text-xl">
              {REGISTRATION.VERIFICATION}
            </div>
          </div>
          <div className="content content_lg content_secondary mt-4 w-[323px] leading-[18px]">
            {REGISTRATION.PAN_OR_LOAN}
          </div>
          <div className="flex-1 space-y-4">
            <div
              className={`bg-white text-grey-500 hover:bg-gray-100 hover:text-gray-700
             py-2 px-4  rounded-md mt-4 cursor-pointer content content_lg dark:text-grey-500 dark:font-semibold w-full h-[62px] ${
               isPan ? "bg-gray-100" : ""
             }`}
              onClick={panClick}
            >
              <div className="flex items-center justify-between mt-3">
                <span>{REGISTRATION.PAN}</span>
              </div>
            </div>
            <div
              className={`bg-white bg-w text-grey-500 font-bold hover:bg-gray-100 hover:text-gray-700
             py-2 px-4 rounded-md  mt-4 cursor-pointer content content_lg dark:text-grey-500 dark:font-semibold w-full h-[62px] ${
               isLoan ? "bg-gray-100" : ""
             }`}
              onClick={loanClick}
            >
              <div className="flex items-center justify-between mt-3">
                <span>{REGISTRATION.LOAN}</span>
              </div>
            </div>
            <div className="lg:pt-10 pt-40">
              <Button
                className={`text-white font-bold rounded-md bg-red-500 disabled:bg-disable-red disabled:text-red-200 w-full h-[42px] ${
                  !isPan && !isLoan ? "cursor-not-allowed opacity-50" : ""
                }`}
                onClick={continueClick}
                disabled={!isPan && !isLoan}
                name="Continue"
              >
                {REGISTRATION.CONTINUE}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Container>
  );
};
export default PanLoanRegDetails;
