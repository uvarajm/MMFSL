import { takeLatest, put, call } from "redux-saga/effects";
import {
  appFaqDataFailure,
  appFaqDataSuccess,
  appFaqStatusData,
} from "../slices/appFaqSlice";
import { makeApiRequest } from "../../utils/apiUtils";
import { endpoints } from "../../utils/apiUtils";
import { CMS_TOKEN } from "../../const/common";
import { APP_FAQS } from "../actions/actions";

function* fetchAppFaqStatus() {
  try {
    yield put(appFaqStatusData());
    const response = yield call(
      makeApiRequest,
      endpoints.faq,
      CMS_TOKEN,
      "GET",
    );
    yield put(appFaqDataSuccess(response));
  } catch (error) {
    yield put(appFaqDataFailure(error.message));
  }
}

export function* watchFetchAppFaqStatus() {
  yield takeLatest(APP_FAQS, fetchAppFaqStatus);
}
