import { useState } from "react";
import { Button, Container } from "../../components";

import Modal from "../../components/Modal";
import { RxCross2 } from "react-icons/rx";

const ManageDevices = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleLogout = () => {
    setIsModalOpen(false);
  };

  return (
    <Container>
      <div className="minHeight md:border-l-[1px] md:border-r-[1px] flex">
        <div className="py-10 space-y-6">
          <h1 className="text-2xl font-normal text-center">
            Manage mobile Devices
          </h1>

          <div className="flex flex-col md:flex-row gap-6 justify-center md:px-4 py-4 border-t-[1px] border-b-[1px] ">
            <h1>1 session on Samsung Galaxy Note 7</h1>
            <div>
              <div>
                <span>Device Id:</span>
                <span>0000000</span>
              </div>
              <div>
                <span>Last active:</span>
                <span>0000000</span>
              </div>
              <div>
                <span>Location:</span>
                <span>Mumbai</span>
              </div>
              <Button
                name="Log out of device"
                className="bg-black-100 text-white py-1 px-2 text-xs mt-4"
                onClick={openModal}
              />
            </div>
          </div>
        </div>
      </div>

      {/* MODAL COMPONENT */}

      {isModalOpen && (
        <div onClick={closeModal}>
          <Modal isOpen={isModalOpen} onClose={closeModal}>
            <div>
              <div className="p-4 space-y-2">
                <div className="flex justify-between items-center ">
                  <h1 className="text-xl font-medium">Are you sure ?</h1>
                  <RxCross2 onClick={closeModal} className="cursor-pointer" />
                </div>

                <p className="text-sm">
                  By logging out of the device you consent to having your
                  account removed from this particular device.
                </p>
              </div>

              <div className="flex">
                <Button
                  name="Cancel"
                  className="flex-1 bg-gray-100 rounded-none text-xs py-6"
                  onClick={closeModal}
                />
                <Button
                  name="Log out of device"
                  className="flex-1 bg-gray-700 text-white rounded-none text-xs py-6"
                  onClick={handleLogout}
                />
              </div>
            </div>
          </Modal>
        </div>
      )}
    </Container>
  );
};

export default ManageDevices;
