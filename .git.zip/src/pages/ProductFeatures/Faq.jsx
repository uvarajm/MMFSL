import PropTypes from "prop-types";
import CustomAccordion from "../../components/Accordion";

const Faq = ({ details, title }) => {
  const { faqs } = details;
  return (
    <section className="space-y-4 mb-2">
      <h4 className="title title_xl title_primary">{title}</h4>
      <div className="bg-white rounded p-2 pb-0 lg:p-4">
        <CustomAccordion items={faqs} />
      </div>
    </section>
  );
};

Faq.propTypes = {
  title: PropTypes.string,
  details: PropTypes.shape({
    faqs: PropTypes.arrayOf(
      PropTypes.shape({
        question: PropTypes.string,
        answer: PropTypes.string,
      }),
    ),
  }),
};

export default Faq;
